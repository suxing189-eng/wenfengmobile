window.config = {
  apiUrl: 'http://192.168.1.88:8899'
  // apiUrl: 'https://api.xmfkz.com'
};

<template>
  <view style="overflow: auto;" class="mt-10">
    <!-- 写施工动态 -->
    <!--  <view class="van-contact-list__bottom"><van-button color="#666666" round icon="plus" size="normal" @click="openSheet">写施工动态</van-button></view> -->
    <!-- 施工动态列表 -->
    <van-cell v-for="item in listData" :key="item.id">
      <template #title>
        <view class="flex-between content">
          <text style="font-weight: 600;" v-if="item.trendType === 1">早会视频</text>
          <text style="font-weight: 600;" v-if="item.trendType === 2">施工日志</text>
          <text style="font-weight: 600;" v-if="item.trendType === 3">质量巡检</text>
          <text style="font-weight: 600;" v-if="item.trendType === 4">周计划</text>
          <text style="font-weight: 600;" v-if="item.trendType === 5">乐捐单</text>
          <text>{{ item.trendNode }}</text>
          <text v-if="item.trendType === 5" style="color: red;">{{ `乐捐金额: ${item.trendMoney} 元` }}</text>
          <van-icon v-if="item.trendType === 1" @click="openVideo(item)" size="26" name="play-circle-o" />
          <!-- <view v-if="item.trendType === 1" style="color: #0000ff;text-decoration: underline;" @click="openVideo(item)">播放</view> -->
        </view>
      </template>
      <template #label>
        <view class="content" v-if="item.trendType !== 1">
          <view style="font-size: 16px;" class="text-padding" v-html="item.trendContent"></view>
          <view class="image-view">
            <view @tap="tabImage" v-for="(i, index) in item.imageThumbList" :key="index" :data-url="item.images[index]" :data-imgList="item.images" class="image-item">
              <image style="width: 100%;height: 100%;" :src="i" mode=""></image>
            </view>
          </view>
          <!-- 整改图片 （只有质量巡检才有） -->
          <view v-if="item.trendType === 3 && item.trendState !== 0 && item.trendState !== 1" class="">
            <view class="text-padding">{{ item.solveContent }}</view>
            <view class="image-view">
              <view @tap="tabImage" v-for="(i, index) in item.solveThumbList" :key="index" :data-url="item.solveImages[index]" :data-imgList="item.solveImages" class="image-item">
                <image style="width: 100%;height: 100%;" :src="i" mode=""></image>
              </view>
            </view>
          </view>
          <view class="flex-between text-padding">
            <text style="font-size: 16px;">{{ `${item.trendDate}【${item.createBy}】` }}</text>
            <view v-if="item.showDeleteBtn" style="color:red;" @click="delectData(item.id)">删除</view>
          </view>
        </view>
        <!-- 早会视频 -->
        <view class="content" v-else>
          <view class="video-update"><image style="width: 100%;height: 100%;" src="@/static/trendVideo.png" mode=""></image></view>
          <view class="flex-between text-padding">
            <text style="font-size: 16px;">{{ `${item.trendDate}【${item.createBy}】` }}</text>
            <view v-if="item.showDeleteBtn" style="color:red;" @click="delectData(item.id)">删除</view>
          </view>
        </view>
      </template>
    </van-cell>
    <view v-if="listData.length > 0" style="height: 57px;"></view>
    <van-empty v-else description="暂无数据" />

    <!-- 动作面板 -->
    <van-action-sheet v-model="activeShow" close-on-click-action :actions="actions" @select="onSelect" />
  </view>
</template>

<script>
import { ProjectTrendList, ProjectTrendDelete } from '@/api/index.js';
export default {
  data() {
    return {
      // 动作面板显示
      activeShow: false,
      // 下拉选项
      actions: [{ name: '施工日志' }, { name: '早会视频' }, { name: '质量巡检' }, { name: '周计划' }, { name: '发乐捐单' }],
      // 数据
      listData: [],
      // 视频
      trailer: [],
      danmuList: [],
      projectId: undefined
    };
  },
  mounted() {},
  onLoad() {
    // uni.$on('onBackPress', this.onBackPress);
  },
  created() {
    const urlString = window.location.href;
    const urlObj = new URLSearchParams(urlString);
    const [projectId] = urlObj.values();
    this.projectId = projectId;
    this.getData();
  },
  onUnload() {
    // 移除监听
    // uni.$off('onBackPress', this.onBackPress);
  },
  onBackPress(options) {
    
  },
  methods: {
    // 获取数据
    async getData() {
      try {
        let { data } = await ProjectTrendList({ trendType: -1, projectId: this.projectId });
        this.listData = data;
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 写施工动态按钮
    openSheet() {
      this.activeShow = true;
    },
    // 动作面板改变回调
    onSelect(item) {
      if (item.name === '施工日志') {
        uni.navigateTo({ url: '/index-pkg/journalView?projectId=' + this.projectId });
      } else if (item.name === '周计划') {
        uni.navigateTo({ url: '/index-pkg/weekPlan?projectId=' + this.projectId });
      } else if (item.name === '质量巡检') {
        uni.navigateTo({ url: '/index-pkg/pollingView?projectId=' + this.projectId });
      } else if (item.name === '早会视频') {
        uni.navigateTo({ url: '/index-pkg/meetVideo?projectId=' + this.projectId });
      } else {
        uni.navigateTo({ url: '/index-pkg/donationView?projectId=' + this.projectId });
      }
    },
    // 预览图片
    tabImage(e) {
      uni.previewImage({
        urls: e.currentTarget.dataset.imglist,
        current: e.currentTarget.dataset.url
      });
    },
    // 删除数据
    async delectData(id) {
      this.Dialog.confirm({
        message: '确认删除此数据吗'
      })
        .then(() => {
          ProjectTrendDelete({ id }).then(res => {
            this.Toast.success(res.msg);
            this.getData();
          });
        })
        .catch(() => {
          // on cancel
        });
    },
    // 获取视频信息
    loadedmetadata(e) {
      this.$nextTick(() => {
        this.trailer.push(e.target.id);
      });
    },
    // 控制视频播放
    play(e) {
      setTimeout(() => {
        let createId = e.target.id;
        this.trailer.forEach(id => {
          if (id != createId) uni.createVideoContext(id + '', this).pause();
        });
      }, 500);
    },
    // 播放视频
    openVideo(item) {
      uni.navigateTo({ url: '/index-pkg/trendVideo?video=' + item.trendVideo });
    }
  }
};
</script>

<style>
.van-button {
  margin: 12rpx 20rpx;
}
.image-view {
  display: flex;
  flex-wrap: wrap;
  .image-item {
    width: 32%;
    height: 115px;
    margin: 2px;
  }
}
.van-empty {
  padding: 20px 0;
}
.video-update {
  width: 100%;
  height: 140px;
  display: flex;
  justify-content: center;
  flex-direction: column;
}
.content {
  max-width: 414px;
  margin: 0 auto;
}
</style>

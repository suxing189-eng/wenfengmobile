<template>
  <!-- 经营成本 -->
  <view class="gray-bj-color" style="height: 100%;">
    <!-- 经营成本审批信息 -->
    <cost-view :item="info"></cost-view>
    <!-- 审批意见 -->
    <examine-idea :startNode="startNode" :taskId="taskId" @handle="handle"></examine-idea>
    <!-- 审批记录 -->
    <examine-record :recordData="recordData" :flowData="flowData"></examine-record>
  </view>
</template>

<script>
import { executeHistory, manageCostGetById } from '@/api/wait.js';
import costView from '@/wait-pkg/components/costView.vue';
import examineIdea from '@/wait-pkg/components/examineIdea.vue';
import examineRecord from '@/wait-pkg/components/examineRecord.vue';
import { mapState, mapMutations } from 'vuex';
export default {
  components: {
    examineIdea,
    costView,
    examineRecord
  },
  data() {
    return {
      // 经营费用审批信息
      info: {},
      // 流程数据
      flowData: [],
      // 记录数据
      recordData: [],
      // 撤回按钮显示
      startNode: false,
      id: undefined,
      taskId: undefined
    };
  },
  onLoad(option) {
    this.id = option.id;
    this.taskId = option.taskId;
    this.getDetail();
  },
  computed: {
    ...mapState('user', ['handleList'])
  },
  methods: {
    ...mapMutations('user', ['HANDLE_LIST']),
    // 获取经营费用详情
    async getDetail() {
      try {
        let { data } = await manageCostGetById({ id: this.id });
        this.info = data;
        this.getData();
      } catch (e) {
        //TODO handle the exception
      }
    },
    async getData() {
      try {
        let { data } = await executeHistory({ instanceId: this.info.flowInstanceId });
        this.flowData = JSON.parse(data.process);
        this.recordData = data.taskLogs;
        this.startNode = data.startNode;
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 操作后改变数据
    handle() {
      let list = this.handleList;
      list.forEach((item, index) => {
        // 通过id找到当前数据
        if (item.id == this.id) {
          list.splice(index, 1);
        }
      });
      this.HANDLE_LIST(list);
    }
  }
};
</script>

<style>
.header {
  /* padding: 18rpx 32rpx; */
  display: flex;
  justify-content: space-between;
}
</style>

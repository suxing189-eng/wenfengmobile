<template>
  <view class="gray-bj-color" style="height: 100%;">
    <van-pull-refresh v-model="isLoading" @refresh="getData">
      <!-- 费用 -->
      <view class="" v-for="item in handleList" :key="item.id">
        <!-- <cost-view :item="item"></cost-view> -->
        <van-cell>
          <template #title>
            <view class="flex-between">
              <!-- <text style="font-weight: 600;width: 520rpx;overflow:hidden; text-overflow:ellipsis;white-space: nowrap;">{{ item.typeName }}</text> -->
              <view style="font-weight: 600;">{{ item.costUserName }}</view>
              <view class="">申请日期: {{ item.costDate }}</view>
              <view>
                <text style="color: #909399;" v-if="item.examineState === -1">{{ item.stateText }}</text>
                <text style="" v-else-if="item.examineState === 0">{{ item.stateText }}</text>
                <text style="color: #67C23A;" v-else-if="item.examineState === 1">{{ item.stateText }}</text>
                <text style="color: red;" v-else>{{ item.stateText }}</text>
              </view>
            </view>
          </template>
          <template #label>
            <view class="flex-between text-padding">
              <view class="">金额: {{ item.costMoney }} 元</view>
              <view class="">
                <view style="color: #67C23A;text-decoration: underline;display: inline-block;margin-right: 56rpx;" @click="agreeFlow(item)">同 意</view>
                <view style="color: #409EFF;text-decoration: underline;display: inline-block;" @click="examineStatement(item)">查看详情></view>
              </view>
            </view>
            <view class="flex-between text-padding">
              <view style="width: 520rpx;overflow:hidden; text-overflow:ellipsis;white-space: nowrap;">摘要: {{ item.costSummary }}</view>
              <view class="">{{ item.deptName }}</view>
            </view>
            <view class="text-padding">{{ item.remark }}</view>
          </template>
        </van-cell>
      </view>
      <!-- 暂无数据 -->
      <van-empty v-if="handleList.length === 0" description="暂无数据" />
    </van-pull-refresh>
  </view>
</template>

<script>
import { todoList, examineAgree } from '@/api/wait.js';
import costView from '@/wait-pkg/components/costView.vue';
import { mapMutations, mapGetters } from 'vuex';
export default {
  components: {
    costView
  },
  data() {
    return {
      list: [],
      isLoading: false
    };
  },
  onLoad() {
    this.getData();
  },
  computed: {
    ...mapGetters(['handleList'])
  },
  methods: {
    ...mapMutations('user', ['HANDLE_LIST']),
    // 获取数据
    async getData() {
      try {
        let { data } = await todoList({ bizCode: 'EX-MANAGE-COST' });
        this.isLoading = false;
        this.HANDLE_LIST(data);
        // this.list = data;
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 同意
    async agreeFlow(row) {
      try {
        this.Dialog.confirm({
          message: '确认同意此审批?'
        })
          .then(() => {
            examineAgree({ taskId: row.taskId }).then(res => {
              this.Toast(res.data);
              setTimeout(() => {
                this.handle(row);
              }, 600);
            });
          })
          .catch(() => {
            return;
            // this.Toast('接口错误');
          });
      } catch (e) {}
    },
    handle(row) {
      let list = this.handleList;
      list.forEach((item, index) => {
        // 通过id找到当前数据
        if (item.id == row.id) {
          list.splice(index, 1);
        }
      });
      this.HANDLE_LIST(list);
    },
    // 点击审批
    examineStatement(item) {
      uni.navigateTo({ url: '/wait-pkg/costDispose?id=' + item.id + '&taskId=' + item.taskId });
    }
  }
};
</script>

<style>
.van-empty {
  padding: 40rpx 0;
}
::v-deep .van-pull-refresh {
  overflow: auto;
}
</style>

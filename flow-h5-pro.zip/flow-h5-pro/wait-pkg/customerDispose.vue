<template>
  <!-- 客户审批 -->
  <view class="gray-bj-color" style="height: 100%;">
    <!-- 客户信息 -->
    <van-panel class="">
      <template #header>
        <view class="header">
          <text style="font-weight: 600;width: 520rpx;">{{ customerInfo.customerName }}</text>
          <text
            :class="
              customerInfo.examineState === -1 ? 'info-color' : customerInfo.examineState === 1 ? 'green-color' : customerInfo.examineState === 0 ? 'color-blue' : 'color-red'
            "
          >
            {{ customerInfo.stateText }}
          </text>
        </view>
      </template>
      <view style="padding: 0 32rpx;">
        <view class="text-padding">客户状态: {{ customerInfo.customerStatus }}</view>
        <view class="text-padding">客户地址: {{ customerInfo.customerAddress }}</view>
        <view class="flex-between text-padding">
          <view class="">联系人: {{ customerInfo.contactUser }}</view>
          <view class="">联系电话: {{ customerInfo.tell }}</view>
        </view>
      </view>
    </van-panel>
    <!-- 审批意见 -->
    <examine-idea :startNode="startNode" :taskId="taskId" @handle="handle"></examine-idea>
    <!-- 审批记录 -->
    <examine-record :recordData="recordData" :flowData="flowData"></examine-record>
  </view>
</template>

<script>
import { executeHistory, customerGetById } from '@/api/wait.js';
import examineIdea from '@/wait-pkg/components/examineIdea.vue';
import examineRecord from '@/wait-pkg/components/examineRecord.vue';
import { mapState, mapMutations } from 'vuex';
export default {
  components: {
    examineIdea,
    examineRecord
  },
  data() {
    return {
      // 客户信息
      customerInfo: {},
      // 流程数据
      flowData: [],
      // 记录数据
      recordData: [],
      // 撤回按钮显示
      startNode: false,
      taskId: undefined,
      id: undefined
    };
  },
  onLoad(option) {
    this.taskId = option.taskId;
    this.id = option.id;
    this.getDetail();
  },
  computed: {
    ...mapState('user', ['handleList'])
  },
  methods: {
    ...mapMutations('user', ['HANDLE_LIST']),
    // 获取客户详情数据
    async getDetail() {
      try {
        let { data } = await customerGetById({ id: this.id });
        this.customerInfo = data;
        this.getData();
      } catch (e) {
        //TODO handle the exception
      }
    },
    async getData() {
      try {
        let { data } = await executeHistory({ instanceId: this.customerInfo.flowInstanceId });
        this.flowData = JSON.parse(data.process);
        this.recordData = data.taskLogs;
        this.startNode = data.startNode;
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 操作后改变数据
    handle() {
      let list = this.handleList;
      list.forEach((item,index) => {
        // 通过id找到当前数据
        if (item.id == this.id) {
          list.splice(index, 1);
        }
      });
      this.HANDLE_LIST(list);
    }
  }
};
</script>

<style>
.header {
  /* padding: 18rpx 32rpx; */
  display: flex;
  justify-content: space-between;
}
</style>

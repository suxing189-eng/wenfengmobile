<template>
  <view class="gray-bj-color" style="height: 100%;">
    <van-pull-refresh v-model="isLoading" @refresh="getData">
      <!-- 审批供应商 -->
      <view v-for="(item, index) in handleList" :key="item.id" @click="examineSupplier(item)"><supplier-view :item="item"></supplier-view></view>
      <!-- 暂无数据 -->
      <van-empty v-if="handleList.length === 0" description="暂无数据" />
    </van-pull-refresh>
  </view>
</template>

<script>
import supplierView from '@/wait-pkg/components/supplierView.vue';
import { todoList } from '@/api/wait.js';
import { mapMutations, mapGetters } from 'vuex';
export default {
  components: {
    supplierView
  },
  data() {
    return {
      list: [],
      isLoading: false
    };
  },
  onLoad() {
    this.getData();
  },
  computed: {
    ...mapGetters(['handleList'])
  },
  onShow() {},
  methods: {
    ...mapMutations('user', ['HANDLE_LIST']),
    // 获取数据
    async getData() {
      try {
        let { data } = await todoList({ bizCode: 'EX-ADD-SUPPLIER' });
        this.isLoading = false;
        this.HANDLE_LIST(data);
        // this.list = data;
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 点击审批
    examineSupplier(item) {
      uni.navigateTo({ url: '/wait-pkg/supplierDispose?id=' + item.id + '&taskId=' + item.taskId });
    }
  }
};
</script>

<style scoped lang="scss">
@function rpx2em($rpx) {
  @return ($rpx / 16) * 1rem;
}
.van-empty {
  padding: rpx2em(20) 0;
}
::v-deep .van-pull-refresh {
  overflow: auto;
}
</style>

<template>
  <view class="gray-bj-color" style="height: 100%">
    <!-- 头像 -->
    <view class="tab"></view>
    <van-cell is-link>
      <template #title>
        <view class="custom-title">头像</view>
      </template>
      <template #right-icon>
        <image @click="openModal('头像')" class="image-item" :src="userInfo.avatar" mode=""></image>
      </template>
    </van-cell>
    <!-- 用户信息 -->
    <view class="tab"></view>
    <van-cell-group>
      <van-cell is-link title="姓名">
        <template #right-icon>
          <view @click="openModal('姓名')" class="gray-text">
            {{ userInfo.nickName }}
            <van-icon name="arrow" size="16" />
          </view>
        </template>
      </van-cell>
      <van-cell is-link title="电话">
        <template #right-icon>
          <view class="gray-text">{{ userInfo.phone }}</view>
        </template>
      </van-cell>
      <van-cell is-link title="账号">
        <template #right-icon>
          <view class="gray-text">{{ userInfo.name }}</view>
        </template>
      </van-cell>
      <van-cell is-link>
        <template #title>
          <span class="">密码</span>
        </template>
        <template #right-icon>
          <view @click="openModal('密码')" class="gray-text">
            修改密码
            <van-icon name="arrow" size="16" />
          </view>
        </template>
      </van-cell>
      <van-cell is-link>
        <template #title>
          <span class="">部门</span>
        </template>
        <template #right-icon>
          <view class="gray-text">
            {{ userInfo.deptName }}
            <!-- <van-icon name="arrow" size="16" /> -->
          </view>
        </template>
      </van-cell>
      <van-cell is-link>
        <template #title>
          <span class="">微信服务号</span>
        </template>
        <template #right-icon>
          <view class="gray-text">
            <text v-if="userInfo.bindWechat">已绑定</text>
            <text v-else>未绑定</text>
            <!-- <van-icon name="arrow" size="16" /> -->
          </view>
        </template>
      </van-cell>
    </van-cell-group>
    <!-- 密钥 -->
    <view class="tab"></view>
    <view class="account-text">
      <text class="text-height">账号密钥（有效期5分钟）</text>
      <van-button @click="copy" class="coptBtn" :data-clipboard-text="userInfo.encodingAESKey" style="float: right;" size="mini" type="primary">复制</van-button>
    </view>
    <van-cell :value="userInfo.encodingAESKey"></van-cell>

    <!-- 对话框 -->
    <van-dialog v-model="show" :title="title" @confirm="confirm" @cancel="show = false" show-cancel-button>
      <view v-if="title === '修改头像'">
        <van-field name="uploader">
          <template #input>
            <uni-file-picker
              mode="grid"
              file-mediatype="image"
              @select="selectChange"
              v-model="dataList"
              @progress="progress"
              @success="success"
              @delete="onDelete"
              limit="1"
              :list-styles="listStyles"
            ></uni-file-picker>
          </template>
        </van-field>
        <!-- 上传图片的加载弹窗 -->
        <van-dialog v-model="imageShow" style="background-color: #f7f8fa;" :showConfirmButton="false" :show-cancel-button="false">
          <view class="image-progress"><van-circle v-model="currentRate" :rate="100" :speed="0" text="上传中" /></view>
        </van-dialog>
      </view>
      <van-field v-if="title === '修改姓名'" maxlength="6" show-word-limit class="field-item name-value" v-model="nickName" label="姓名" placeholder="请输入姓名" />
      <!-- <van-field v-if="title === '修改电话'" class="field-item" v-model="phone" label="电话" placeholder="请输入电话" /> -->
      <view v-if="title === '修改密码'">
        <van-field class="field-item" v-model="oldPwd" label="旧密码" placeholder="请输入旧密码" />
        <van-field class="field-item" v-model="newPwd" label="新密码" placeholder="请输入新密码" />
        <van-field class="field-item" v-model="newPwd2" label="确认新密码" placeholder="请再次输入新密码" />
      </view>
    </van-dialog>
  </view>
</template>

<script>
import { getByCurr, updateInfo, adminPassword, updateAvatar } from '@/api/login.js';
import { mapMutations } from 'vuex';
import ClipboardJS from 'clipboard';
export default {
  data() {
    return {
      // 对话框显示
      show: false,
      // 对话框标题
      title: '',
      nickName: '',
      phone: '',
      // 用户信息
      userInfo: {},
      // 密码
      oldPwd: '',
      newPwd: '',
      newPwd2: '',
      // 上传的数据
      uploadData: [],
      // 线条样式
      listStyles: {
        // 是否显示边框
        border: true,
        // 是否显示分隔线
        dividline: true,
        // 线条样式
        borderStyle: {
          width: 1,
          color: 'blue',
          radius: 2
        }
      },
      // 图片上传对话框显示
      imageShow: false,
      // 上传进度条
      currentRate: 0,
      dataList: []
    };
  },
  onLoad() {
    this.getData();
  },
  methods: {
    ...mapMutations('user', ['USER_INFO']),
    // 获取用户信息
    async getData() {
      try {
        let { data } = await getByCurr();
        this.userInfo = data;
        await this.USER_INFO(this.userInfo);
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 打开修改信息对话框
    openModal(name) {
      this.title = '修改' + name;
      this.show = true;
      if (this.title === '修改姓名') {
        this.nickName = this.userInfo.nickName;
      } else if (this.title === '修改密码') {
        this.oldPwd = '';
        this.newPwd = '';
        this.newPwd2 = '';
        return;
      }
    },
    success(e) {
      console.log('上传成功：', e);
    },
    // 获取上传进度
    progress(e) {
      console.log('上传进度：', e);
    },
    // 移除图片
    onDelete(e) {
      let fileData = [];
      fileData = this.uploadData.filter(item => {
        return item.reqId != e.tempFile.uuid;
      });
      this.uploadData = fileData;
      console.log(this.uploadData, '============>上传内容');
      // this.$emit('update:fileValue', fileData);
    },
    // 复制方案URL
    copy() {
      var clipboard = new ClipboardJS('.coptBtn');
      clipboard.on('success', () => {
        this.Toast.success('复制成功');
        clipboard.destroy();
      });
      clipboard.on('error', () => {
        this.Toast.fail('复制失败');
        clipboard.destroy();
      });
    },
    // 对话框关闭确认按钮
    async confirm() {
      if (this.title === '修改姓名') {
        let { msg } = await updateInfo({ id: this.userInfo.id, nickName: this.nickName });
        this.Toast.success('修改成功');
      } else if (this.title === '修改密码') {
        //判断密码输入
        if (this.newPwd !== this.newPwd2) {
          this.Toast.fail('新密码两次输入不一致');
          return;
        }
        let form = {
          oldPwd: this.oldPwd,
          newPwd: this.newPwd,
          newPwd2: this.newPwd2,
          id: this.userInfo.id
        };
        let { msg } = await adminPassword(form);
        this.Toast.success('修改成功');
      } else {
        let { msg } = await updateAvatar({ id: this.userInfo.id, avatar: this.uploadData[0].url });
        this.Toast.success('修改成功');
      }
      setTimeout(() => {
        this.getData();
      }, 800);
    },
    selectChange(e) {
      let tempFilePaths = e.tempFilePaths;
      let upUrl;
      upUrl = window.config.apiUrl + '/upload/image/async?reqId=' + e.tempFiles[0].uuid;
      tempFilePaths.forEach((item, index) => {
        this.imageShow = true;
        let progress = 0;
        let uploadTask = uni.uploadFile({
          url: upUrl,
          fileType: 'image',
          filePath: item,
          name: 'file',
          header: {
            token: sessionStorage.getItem('satoken')
          },
          success: uploadFileRes => {
            let result = JSON.parse(uploadFileRes.data);
            let fileData = [...this.uploadData, { url: result.data.url, name: result.data.originalFilename, extname: result.data.ext, reqId: result.data.reqId }];
            this.uploadData = fileData;
            // this.$emit('update:fileValue', fileData);
            // console.log(this.dataList, '上传的数据！！！！！');
            // console.log(this.uploadData, '上传');
          },
          fail: result => {}
        });

        uploadTask.onProgressUpdate(res => {
          this.currentRate = res.progress;
          if (res.progress === 100) {
            setTimeout(() => {
              this.imageShow = false;
            }, 1300);
          }
        });
      });
    }
  }
};
</script>

<style scoped lang="scss">
@function rpx2em($rpx) {
  @return ($rpx / 16) * 1rem;
}
.custom-title {
  line-height: rpx2em(64);
}
.image-item {
  width: rpx2em(64);
  height: rpx2em(64);
}
.gray-text {
  color: #969799;
}
.account-text {
  font-size: rpx2em(14);
  padding: rpx2em(8);
  color: #323233;
  .text-height {
    line-height: rpx2em(20);
  }
}
.field-item {
  padding: rpx2em(12) rpx2em(16);
}
::v-deep .file-picker__box {
  width: 200rpx !important;
  height: 200rpx !important;
  margin: 0 auto;
}
.image-progress {
  width: 200rpx;
  margin: 40rpx auto;
}
::v-deep .uni-progress-bar {
  display: none;
}
.name-value ::v-deep .van-field__value {
  display: flex;
}
::v-deep .van-button--mini {
  padding: rpx2em(0) rpx2em(14);
}
</style>

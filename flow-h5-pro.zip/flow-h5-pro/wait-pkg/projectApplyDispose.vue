<template>
  <!-- 工程请款审批 -->
  <view class="gray-bj-color" style="height: 100%;">
    <!-- 工程请款审批信息 -->
    <van-cell>
      <template #title>
        <view class="flex-between">
          <text style="font-weight: 600;width: 450rpx;overflow:hidden; text-overflow:ellipsis;white-space: nowrap;">{{ info.useTypeName }}</text>
          <view>
            <text style="color: #909399;" v-if="info.examineState === -1">{{ info.stateText }}</text>
            <text style="color: #409EFF;" v-else-if="info.examineState === 0">{{ info.stateText }}</text>
            <text style="color: #67C23A;" v-else-if="info.examineState === 1">{{ info.stateText }}</text>
            <text style="color: red;" v-else>{{ info.stateText }}</text>
          </view>
        </view>
      </template>
      <template #label>
        <view class="flex-between text-padding">
          <view class="">申请日期: {{ info.requestDate }}</view>
          <view class="un_blue" @click="editMoney(info)">请款金额: {{ info.requestMoney }}</view>
        </view>
        <view class="flex-between text-padding">
          <view style="width: 330rpx;" class="text-nowrap">收款人: {{ info.payeeUser }}</view>
          <view style="width: 320rpx;word-break: break-all;text-align: right;">卡号:{{ info.payeeAccount }}</view>
        </view>
        <view class="text-padding">{{ info.remark }}</view>
      </template>
    </van-cell>
    <!-- 审批意见 -->
    <examine-idea :startNode="startNode" :taskId="taskId" @handle="handle"></examine-idea>
    <!-- 审批记录 -->
    <examine-record :recordData="recordData" :flowData="flowData"></examine-record>
    <!-- 修改审批金额 -->
    <van-dialog v-model="showMoney" @confirm="confirm" title="修改审批金额" show-cancel-button>
      <van-form class="money-form">
        <van-field v-model="examineMoney" type="number" name="审批金额" label="审批金额" placeholder="审批金额" :rules="[{ required: true, message: '请输入审批金额' }]" />
      </van-form>
    </van-dialog>
  </view>
</template>

<script>
import { executeHistory, applyBillGetById, applyBillMoney } from '@/api/wait.js';
import examineIdea from '@/wait-pkg/components/examineIdea.vue';
import examineRecord from '@/wait-pkg/components/examineRecord.vue';
import { mapState, mapMutations } from 'vuex';
export default {
  components: {
    examineIdea,
    examineRecord
  },
  data() {
    return {
      // 提成支付审批信息
      info: {},
      // 流程数据
      flowData: [],
      // 记录数据
      recordData: [],
      // 审批金额弹窗显示
      showMoney: false,
      // 审批金额
      examineMoney: 0,
      billsId: 0,
      processId: 0,
      // 撤回按钮显示
      startNode: false,
      taskId: 0,
      itemId: undefined
    };
  },
  computed: {
    ...mapState('user', ['handleList'])
  },
  onLoad(option) {
    this.billsId = option.id;
    this.taskId = option.taskId;
    this.processId = option.processId;
    this.itemId = option.itemId;
    this.getDetail();
    this.getData();
  },
  methods: {
    ...mapMutations('user', ['HANDLE_LIST']),
    // 获取列表详情数据
    async getDetail() {
      try {
        let { data } = await applyBillGetById({ id: this.billsId });
        this.info = data;
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 获取流程记录数据
    async getData() {
      try {
        let { data } = await executeHistory({ instanceId: this.processId });
        this.flowData = JSON.parse(data.process);
        this.recordData = data.taskLogs;
        this.startNode = data.startNode;
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 修改金额
    editMoney(item) {
      this.examineMoney = JSON.parse(JSON.stringify(item.requestMoney));
      this.showMoney = true;
    },
    // 保存金额按钮
    confirm() {
      try {
        applyBillMoney({ id: this.billsId, examineMoney: this.examineMoney }).then(res => {
          if (res.code === 200) {
            this.Toast.success('修改成功');
            this.getDetail();
          } else {
            this.Toast.error(res.msg);
          }
        });
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 操作后改变数据
    handle() {
      let list = this.handleList;
      list.forEach((item, index) => {
        // 通过id找到当前工程 再通过当前行数据的id找到请款单 移除掉已操作的数据
        if (item.id == this.itemId) {
          item.billList.forEach((element, elementIndex) => {
            if (element.taskId == this.taskId) {
              // 移除当前审批的数据
              item.billList.splice(elementIndex, 1);
            }
            // 如果全部审批了 就把上一级也移除
            if (item.billList.length === 0) {
              list.splice(index, 1);
            }
          });
        }
      });
      this.HANDLE_LIST(list);
    }
  }
};
</script>

<style>
.un_blue {
  text-decoration: underline;
  color: #409eff;
}
.money-form ::v-deep .van-cell {
  padding: 32rpx 32rpx;
}
.header {
  padding: 18rpx 32rpx;
  display: flex;
  justify-content: space-between;
}
</style>

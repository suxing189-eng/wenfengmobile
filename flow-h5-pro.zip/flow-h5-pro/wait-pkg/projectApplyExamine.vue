<template>
  <view class="gray-bj-color" style="height: 100%;">
    <van-pull-refresh v-model="isLoading" @refresh="getData">
      <van-collapse v-model="activeNames" accordion>
        <van-collapse-item v-for="(item, index) in handleList" :name="index" :key="item.id" style="margin-bottom: 10rpx;">
          <template #title>
            <div>
              <view class="text-padding" style="font-weight: 600;color: #323233;" v-html="item.projectName"></view>
              <view class="flex-between text-padding">
                <view>项目经理:{{ item.dutyUserName }}</view>
                <view>请款单据:{{ item.billCount }} 张</view>
              </view>
              <view class="flex-between text-padding">
                <view>合同总额: {{ item.contractMoney }} 元</view>
                <view>单据合计:{{ item.totalRequestMoney }} 元</view>
              </view>
              <view class="flex-between text-padding">
                <view>
                  <text v-if="item.explainState" class="text-green">已交底</text>
                  <text v-else class="text-info">未交底</text>
                </view>
                <view>
                  <text v-if="item.doneWorkState" class="text-green">已完工</text>
                  <text v-else class="text-info">未完工</text>
                </view>
                <view>
                  <text v-if="item.closeState" class="text-green">已关单</text>
                  <text v-else class="text-info">未关单</text>
                </view>
                <view>
                  <text v-if="item.statement" class="text-green">已结算</text>
                  <text v-else class="text-info">未结算</text>
                </view>
              </view>
            </div>
          </template>
          <!-- 请款单 -->
          <view class="content-cell">
            <van-cell class="cell-name mb-5" v-for="items in item.billList" :key="items.id">
              <template #title>
                <view class="flex-between">
                  <text style="font-weight: 600;width: 450rpx;overflow:hidden; text-overflow:ellipsis;white-space: nowrap;color: #666666;">{{ items.useTypeName }}</text>
                  <view>
                    <text style="color: #909399;" v-if="items.examineState === -1">{{ items.stateText }}</text>
                    <text v-else-if="items.examineState === 0">{{ items.stateText }}</text>
                    <text style="color: #67C23A;" v-else-if="items.examineState === 1">{{ items.stateText }}</text>
                    <text style="color: red;" v-else>{{ items.stateText }}</text>
                  </view>
                </view>
              </template>
              <template #label>
                <view class="flex-between text-padding">
                  <view class="">日期: {{ items.requestDate }}</view>
                  <view class="">
                    <view style="color: #67C23A;text-decoration: underline;display: inline-block;margin-right: 56rpx;" @click="agreeFlow(item, items)">同 意</view>
                    <view style="color: #409EFF;text-decoration: underline;display: inline-block;" @click="examineApply(item, items)">查看详情></view>
                  </view>
                </view>
                <view class="flex-between text-padding">
                  <view style="width: 330rpx;" class="text-nowrap">收款人: {{ items.payeeUser }}</view>
                  <view class="">请款金额: {{ items.requestMoney }}</view>
                  <!-- <text style="width: 320rpx;overflow:hidden; text-overflow:ellipsis;white-space: nowrap;text-align: right;">卡号: {{ items.payeeAccount }}</text> -->
                </view>
                <view class="text-padding">{{ items.remark }}</view>
              </template>
            </van-cell>
            <!--  <van-empty v-if="item.billList && item.billList.length === 0" description="已全部审批" /> -->
          </view>
        </van-collapse-item>
        <van-empty v-if="handleList && handleList.length === 0" description="暂无数据" />
      </van-collapse>
    </van-pull-refresh>
  </view>
</template>

<script>
import { todoList, examineAgree } from '@/api/wait.js';
import { mapMutations, mapGetters } from 'vuex';
export default {
  data() {
    return {
      activeNames: '1',
      // 工程数据
      list: [],
      isLoading: false
    };
  },
  onLoad() {
    this.getData();
  },
  computed: {
    ...mapGetters(['handleList'])
  },
  methods: {
    ...mapMutations('user', ['HANDLE_LIST']),
    // 获取数据
    async getData() {
      try {
        let { data } = await todoList({ bizCode: 'EX-PROJECT-APPLY' });
        this.isLoading = false;
        this.HANDLE_LIST(data);
        // this.list = data;
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 同意
    async agreeFlow(row, rows) {
      try {
        this.Dialog.confirm({
          message: '确认同意此审批?'
        })
          .then(() => {
            examineAgree({ taskId: rows.taskId }).then(res => {
              this.Toast(res.data);
              setTimeout(() => {
                // this.$emit('handle');
                this.handle(row, rows);
                // uni.navigateBack();
              }, 600);
            });
          })
          .catch(() => {
            return;
            // this.Toast('接口错误');
          });
      } catch (e) {}
    },
    handle(row, rows) {
      let list = this.handleList;
      console.log(111);
      list.forEach((item, index) => {
        // 通过id找到当前工程 再通过当前行数据的id找到请款单 移除掉已操作的数据
        if (item.id == row.id) {
          item.billList.forEach((element, elementIndex) => {
            if (element.taskId == rows.taskId) {
              console.log(item, 77);
              // 移除当前审批的数据
              item.billList.splice(elementIndex, 1);
            }
            // 如果全部审批了 就把上一级也移除
            if (item.billList.length === 0) {
              list.splice(index, 1);
            }
          });
        }
      });
      this.HANDLE_LIST(list);
    },
    // 点击审批
    examineApply(item, items) {
      uni.navigateTo({
        url: '/wait-pkg/projectApplyDispose?id=' + items.id + '&taskId=' + items.taskId + '&processId=' + items.processId + '&itemId=' + item.id
        // events: {
        //   acceptDataFromOpenedPage: function(data) {
        //     console.log(data, 9666);
        //   }
        // }
      });
    }
  }
};
</script>

<style scoped lang="scss">
.content-cell ::v-deep .van-cell {
  padding: 0rpx;
}
::v-deep .van-pull-refresh {
  overflow: auto;
}
</style>

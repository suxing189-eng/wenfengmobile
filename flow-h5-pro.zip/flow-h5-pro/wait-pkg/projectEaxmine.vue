<template>
  <view class="gray-bj-color" style="height: 100%;">
    <van-pull-refresh v-model="isLoading" @refresh="getData">
      <!-- 审批通知签单 -->
      <view class="" v-for="item in handleList" :key="item.id" @click="examineSupplier(item)"><project-examine-view :item="item"></project-examine-view></view>
      <!-- 暂无数据 -->
      <van-empty v-if="handleList && handleList.length === 0" description="暂无数据" />
    </van-pull-refresh>
  </view>
</template>

<script>
import { todoList } from '@/api/wait.js';
import projectExamineView from '@/wait-pkg/components/projectExamineView.vue';
import { mapMutations, mapGetters } from 'vuex';
export default {
  components: {
    projectExamineView
  },
  data() {
    return {
      list: [],
      isLoading: false
    };
  },
  computed: {
    ...mapGetters(['handleList'])
  },
  onLoad() {
     this.getData();
  },
  methods: {
    ...mapMutations('user', ['HANDLE_LIST']),
    // 获取数据
    async getData() {
      try {
        let { data } = await todoList({ bizCode: 'EX-ADD-PROJECT' });
        this.isLoading = false;
        this.HANDLE_LIST(data);
        // this.list = data;
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 点击审批
    examineSupplier(item) {
      uni.navigateTo({ url: '/wait-pkg/projectDispose?key=' + encodeURIComponent(JSON.stringify(item)) });
    }
  }
};
</script>

<style>
.van-empty {
  padding: 40rpx 0;
}
::v-deep .van-pull-refresh {
  overflow: auto;
}
</style>

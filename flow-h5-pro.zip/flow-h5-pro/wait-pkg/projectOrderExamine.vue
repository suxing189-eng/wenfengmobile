<template>
  <view class="gray-bj-color" style="height: 100%;overflow-y: auto;">
    <van-tabs v-model="active" sticky offset-top="45px" @change="tabsChange" title-inactive-color="#666666" title-active-color="#000">
      <van-tab title="按月份">
        <van-pull-refresh v-model="isLoading" @refresh="getData">
          <!-- 按月份 外层 -->
          <van-collapse v-model="activeNames" accordion>
            <van-collapse-item v-for="(item, index) in handleList" :name="index" :key="item.groupId" style="margin-bottom: 10rpx;">
              <template #title>
                <div>
                  <view class="text-padding" style="font-weight: 600;color: #323233;">{{ item.monthValue }}</view>
                  <view class="flex-between text-padding">
                    <view>单据合计: {{ item.totalRequestMoney }}</view>
                    <view>请款单据:{{ item.orderCount }}张</view>
                  </view>
                </div>
              </template>
              <!-- 请款单 -->
              <view v-for="items in item.orderList" :key="items.id" class="content-cell"><examine-order :items="items" :item="item"></examine-order></view>
            </van-collapse-item>
            <van-empty v-if="handleList && handleList.length === 0" description="暂无数据" />
          </van-collapse>
        </van-pull-refresh>
      </van-tab>
      <van-tab title="按项目">
        <van-pull-refresh v-model="isLoading" @refresh="getData">
          <!-- 按项目 外层 -->
          <van-collapse v-model="activeNames" accordion>
            <van-collapse-item v-for="(item, index) in handleList" :name="index" :key="item.id" style="margin-bottom: 10rpx;">
              <template #title>
                <div style="width: 100%;">
                  <view class="text-padding" style="font-weight: 600;color: #323233;overflow: hidden;text-overflow: ellipsis;white-space: nowrap;width: 100%;">
                    {{ item.projectName }}
                  </view>
                  <view class="flex-between text-padding">
                    <view>回款总额:{{ item.totalRefundMoney }}</view>
                    <view>请款单据:{{ item.orderCount }} 张</view>
                  </view>
                  <view class="text-padding flex-between">
                    <view>已用总额:{{ item.totalUsedMoney }}</view>
                    <view>单据合计: {{ item.totalRequestMoney }}</view>
                  </view>
                </div>
              </template>
              <!-- 单据 -->
              <view v-for="items in item.orderList" :key="items.id" class="content-cell"><examine-order :item="item" :items="items"></examine-order></view>
            </van-collapse-item>
            <van-empty v-if="handleList && handleList.length === 0" description="暂无数据" />
          </van-collapse>
        </van-pull-refresh>
      </van-tab>
      <van-tab title="按供应商">
        <van-pull-refresh v-model="isLoading" @refresh="getData">
          <!-- 按项目 外层 -->
          <van-collapse v-model="activeNames" accordion>
            <van-collapse-item v-for="(item, index) in handleList" :name="index" :key="item.id" style="margin-bottom: 10rpx;">
              <template #title>
                <div style="width: 100%;">
                  <view class="text-padding" style="font-weight: 600;color: #323233;overflow: hidden;text-overflow: ellipsis;white-space: nowrap;width: 100%;">
                    {{ item.supplierName }}
                  </view>
                  <view class="flex-between text-padding">
                    <view>单据合计: {{ item.totalRequestMoney }}</view>
                    <view>请款单据:{{ item.orderCount }} 张</view>
                  </view>
                </div>
              </template>
              <!-- 单据 -->
              <view v-for="items in item.orderList" :key="items.id" class="content-cell"><examine-order :item="item" :items="items"></examine-order></view>
            </van-collapse-item>
            <van-empty v-if="handleList && handleList.length === 0" description="暂无数据" />
          </van-collapse>
        </van-pull-refresh>
      </van-tab>
    </van-tabs>
  </view>
</template>

<script>
import { todoList } from '@/api/wait.js';
import examineOrder from '@/wait-pkg/components/examineOrder.vue';
import { mapMutations, mapGetters } from 'vuex';
export default {
  components: {
    examineOrder
  },
  data() {
    return {
      activeNames: '1',
      // 工程数据
      list: [],
      isLoading: false,
      active: 0,
      // tab类型
      groupBy: 'month'
    };
  },
  onLoad() {
    this.getData();
  },
  computed: {
    ...mapGetters(['handleList'])
  },
  methods: {
    ...mapMutations('user', ['HANDLE_LIST']),
    // 获取数据
    async getData() {
      try {
        let { data } = await todoList({ bizCode: 'EX-PROJECT-ORDER', groupBy: this.groupBy });
        this.isLoading = false;
        this.HANDLE_LIST(data);
      } catch (e) {
        //TODO handle the exception
      }
    },
    // tab切换回调
    tabsChange(value) {
      if (value === 0) {
        this.groupBy = 'month';
      } else if (value === 1) {
        this.groupBy = 'project';
      } else {
        this.groupBy = 'supplier';
      }
      this.getData();
    },
  }
};
</script>

<style scoped lang="scss">
.content-cell ::v-deep .van-cell {
  padding: 0rpx;
  border-bottom: 2rpx solid #f7f8fa;
}
::v-deep .van-pull-refresh {
  overflow: auto;
}
::v-deep .van-pull-refresh__track {
  height: calc(100% - 44px);
}
::v-deep .van-cell__title {
  width: 94%;
}
</style>

<template>
  <view class="gray-bj-color">
    <van-dropdown-menu>
      <van-dropdown-item :title="monthData" ref="item">
        <van-datetime-picker
          v-model="nowDate"
          @confirm="confirmDate"
          @cancel="cancel"
          type="year-month"
          title="选择年月"
          :min-date="minDate"
          :max-date="maxDate"
          :formatter="formatter"
        />
      </van-dropdown-item>
      <van-dropdown-item :title="statusText" v-model="queryParams.businessState" :options="examineOption" @change="dropownChange"></van-dropdown-item>
    </van-dropdown-menu>
    <!-- 列表 -->
    <view class="mt-5" style="height: calc(100vh - 176rpx);overflow: auto;">
      <view v-for="item in userData" :key="item.id"><business-view :item="item"></business-view></view>
      <van-empty v-if="userData.length === 0" description="暂无数据" />
    </view>
  </view>
</template>

<script>
import { getUserStats } from '@/api/wait.js';
import businessView from '../wait-pkg/components/businessView.vue';
export default {
  components: {
    businessView
  },
  data() {
    return {
      // 请求数据参数
      queryParams: {
        userId: undefined,
        queryMonth: '',
        businessState: ''
      },
      // 页面显示时间
      monthData: '',
      statusText: '全部',
      // 选择的日期（用来对应时间选择器的时间）
      nowDate: '',
      // 状态集合
      examineOption: [
        { text: '全部', value: '' },
        { text: '未开始', value: '未开始 ' },
        { text: '跟进中', value: '跟进中' },
        { text: '已成交', value: '已成交' },
        { text: '已暂停', value: '已暂停' },
        { text: '已取消', value: '已取消' }
      ],
      minDate: new Date(2021, 0, 1),
      maxDate: new Date(),
      // 人员统计数据
      userData: []
    };
  },
  onLoad(option) {
    this.queryParams.userId = option.userId;
    let month = new Date().getMonth() + 1 < 10 ? '0' + (new Date().getMonth() + 1) : new Date().getMonth() + 1;
    // 查询参数
    // this.queryParams.queryMonth = new Date().getFullYear() + '-' + month;
    // 显示的标题 年月
    // this.monthData = new Date().getFullYear() + '-' + month;
    this.monthData = '全部';
    // 对应时间选择器
    this.nowDate = new Date();
    this.getData();
  },
  methods: {
    // 获取数据
    async getData() {
      try {
        let { data } = await getUserStats(this.queryParams);
        this.userData = data;
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 选择时间确定按钮
    confirmDate(value) {
      this.nowDate = value;
      this.monthData = this.util.dateFormat('yyyy-mm', new Date(value));
      this.queryParams.queryMonth = this.util.dateFormat('yyyy-mm', new Date(value));
      this.getData();
      this.$refs.item.toggle();
    },
    // 选择时间取消按钮
    cancel() {
      this.queryParams.queryMonth = '';
      this.monthData = '全部';
      this.getData();
      this.$refs.item.toggle();
    },
    // 下拉回调
    dropownChange(value) {
      let examine = this.examineOption.filter(item => {
        return item.value === value;
      });
      this.statusText = examine[0].text;
      this.queryParams.businessState = value;
      this.getData();
    },
    // 时间选择器
    formatter(type, val) {
      if (type === 'year') {
        return `${val}年`;
      } else if (type === 'month') {
        return `${val}月`;
      }
      return val;
    }
  }
};
</script>

<style></style>

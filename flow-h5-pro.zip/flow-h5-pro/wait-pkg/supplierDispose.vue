<template>
  <view class="gray-bj-color" style="height: 100%;">
    <!-- 供应商信息 -->
    <van-panel class="">
      <template #header>
        <view class="header">
          <text class="text-title">{{ supplierInfo.supplierName }}</text>
          <text
            :class="
              supplierInfo.examineState === -1 ? 'info-color' : supplierInfo.examineState === 1 ? 'green-color' : supplierInfo.examineState === 0 ? 'color-blue' : 'color-red'
            "
          >
            {{ supplierInfo.stateText }}
          </text>
        </view>
      </template>
      <view class="box-padding">
        <view class="flex-between text-padding">
          <view>供应商类别: {{ supplierInfo.supplierType | typeFilter }}</view>
          <view>
            <van-tag type="success" size="medium" v-if="supplierInfo.status">已启用</van-tag>
            <van-tag v-else size="medium" type="danger">已停用</van-tag>
          </view>
        </view>
        <view class="text-padding">主营类别: {{ supplierInfo.catalog }}</view>
        <view class="text-padding">地址: {{ supplierInfo.address }}</view>
        <view class="text-padding" v-html="supplierInfo.remark"></view>
      </view>
    </van-panel>
    <!-- 审批意见 -->
    <examine-idea :startNode="startNode" :taskId="taskId" @handle="handle"></examine-idea>
    <!-- 审批记录 -->
    <examine-record :recordData="recordData" :flowData="flowData"></examine-record>
  </view>
</template>

<script>
import { executeHistory, supplierGetById } from '@/api/wait.js';
import examineIdea from '@/wait-pkg/components/examineIdea.vue';
import examineRecord from '@/wait-pkg/components/examineRecord.vue';
import { mapState, mapMutations } from 'vuex';
export default {
  components: {
    examineIdea,
    examineRecord
  },
  data() {
    return {
      supplierInfo: {},
      // 流程数据
      flowData: [],
      // 记录数据
      recordData: [],
      // 撤回按钮显示
      startNode: false,
      id: undefined,
      taskId: undefined
    };
  },
  onLoad(option) {
    this.id = option.id;
    this.taskId = option.taskId;
    this.getDetail();
  },
  filters: {
    // 类别过滤器
    typeFilter(value) {
      let values = {
        '1': '订单供应商',
        '2': '合同供应商',
        '3': '临时供应商'
      };
      return values[value];
    }
  },
  computed: {
    ...mapState('user', ['handleList'])
  },
  methods: {
    ...mapMutations('user', ['HANDLE_LIST']),
    // 获取客户详情数据
    async getDetail() {
      try {
        let { data } = await supplierGetById({ id: this.id });
        this.supplierInfo = data;
        this.getData();
      } catch (e) {
        //TODO handle the exception
      }
    },
    async getData() {
      try {
        let { data } = await executeHistory({ instanceId: this.supplierInfo.flowInstanceId });
        this.flowData = JSON.parse(data.process);
        this.recordData = data.taskLogs;
        this.startNode = data.startNode;
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 操作后改变数据
    handle() {
      let list = this.handleList;
      list.forEach((item, index) => {
        // 通过id找到当前数据
        if (item.id == this.id) {
          list.splice(index, 1);
        }
      });
      this.HANDLE_LIST(list);
    }
  }
};
</script>

<style scoped lang="scss">
@function rpx2em($rpx) {
  @return ($rpx / 16) * 1rem;
}
.text-title {
  font-weight: 600;
  width: 80%;
}
.header {
  padding: rpx2em(8) rpx2em(16);
  display: flex;
  justify-content: space-between;
}
</style>

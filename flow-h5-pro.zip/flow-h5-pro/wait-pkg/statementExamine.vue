<template>
  <view class="gray-bj-color" style="height: 100%;">
    <van-pull-refresh v-model="isLoading" @refresh="getData">
      <!-- 审批结算单 -->
      <view class="" v-for="item in handleList" :key="item.id" @click="examineStatement(item)"><statement-view :item="item"></statement-view></view>
      <!-- 暂无数据 -->
      <van-empty v-if="handleList.length === 0" description="暂无数据" />
    </van-pull-refresh>
  </view>
</template>

<script>
import { todoList } from '@/api/wait.js';
import statementView from '@/wait-pkg/components/statementView.vue';
import { mapMutations, mapGetters } from 'vuex';
export default {
  components: {
    statementView
  },
  data() {
    return {
      list: [],
      isLoading: false
    };
  },
  onLoad() {
    this.getData();
  },
  computed: {
    ...mapGetters(['handleList'])
  },
  methods: {
    ...mapMutations('user', ['HANDLE_LIST']),
    // 获取数据
    async getData() {
      try {
        let { data } = await todoList({ bizCode: 'EX-PROJECT-STATEMENT' });
        this.isLoading = false;
        this.HANDLE_LIST(data);
        // this.list = data;
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 点击审批
    examineStatement(item) {
      delete item.statementData;
      uni.navigateTo({ url: '/wait-pkg/statementDispose?id=' + item.id + '&taskId=' + item.taskId });
    }
  }
};
</script>

<style>
.van-empty {
  padding: 40rpx 0;
}
::v-deep .van-pull-refresh {
  overflow: auto;
}
</style>

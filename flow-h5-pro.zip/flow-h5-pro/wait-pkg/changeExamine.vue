<template>
  <view class="gray-bj-color" style="height: 100%;">
    <van-pull-refresh v-model="isLoading" @refresh="getData">
      <!-- 变更清单 -->
      <view class="" v-for="item in handleList" :key="item.id" @click="examinechange(item)"><change-view :item="item"></change-view></view>
      <!-- 暂无数据 -->
      <van-empty v-if="handleList.length === 0" description="暂无数据" />
    </van-pull-refresh>
  </view>
</template>

<script>
import { todoList } from '@/api/wait.js';
import changeView from '@/wait-pkg/components/changeView.vue';
import { mapMutations, mapGetters } from 'vuex';
export default {
  components: {
    changeView
  },
  data() {
    return {
      list: [],
      isLoading: false
    };
  },
  computed: {
    ...mapGetters(['handleList'])
  },
  onLoad() {
    this.getData();
  },
  methods: {
    ...mapMutations('user', ['HANDLE_LIST']),
    // 获取数据
    async getData() {
      try {
        let { data } = await todoList({ bizCode: 'EX-CHANGE-LIST' });
        this.isLoading = false;
        this.HANDLE_LIST(data);
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 点击审批
    examinechange(item) {
      uni.navigateTo({ url: '/wait-pkg/changeDispose?id=' + item.id + '&taskId=' + item.taskId });
    }
  }
};
</script>

<style>
.van-empty {
  padding: 40rpx 0;
}
::v-deep .van-pull-refresh {
  overflow: auto;
}
</style>

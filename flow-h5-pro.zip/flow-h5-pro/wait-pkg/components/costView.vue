<template>
  <view style="overflow: auto;">
    <van-cell class="mb-5">
      <template #title>
        <view class="flex-between">
          <view style="font-weight: 600;">{{ item.costUserName }}</view>
          <view class="">申请日期: {{ item.costDate }}</view>
          <view>
            <text style="color: #909399;" v-if="item.examineState === -1">{{ item.stateText }}</text>
            <text style="" v-else-if="item.examineState === 0">{{ item.stateText }}</text>
            <text style="color: #67C23A;" v-else-if="item.examineState === 1">{{ item.stateText }}</text>
            <text style="color: red;" v-else>{{ item.stateText }}</text>
          </view>
        </view>
      </template>
      <template #label>
        <view class="flex-between text-padding">
          <view class="">费用金额: {{ item.costMoney }} 元</view>
          <view class="">{{ item.deptName }}</view>
        </view>
        <view class="text-padding">摘要：{{ item.costSummary }}</view>
        <view class="text-padding">{{ item.remark }}</view>
      </template>
    </van-cell>
    <!-- 详情列表 -->
    <view>
      <uni-table class="mb-5" border emptyText="暂无更多数据">
        <!-- 表头行 -->
        <uni-tr>
          <uni-th width="60" align="center">类型</uni-th>
          <uni-th width="110" align="left">名称</uni-th>
          <uni-th width="60" align="center">金额</uni-th>
        </uni-tr>
        <!-- 表格数据行 -->
        <uni-tr v-for="row in item.itemList" :key="row.id">
          <uni-td align="center">{{ row.typeName }}</uni-td>
          <uni-td align="left">{{ row.itemName }}</uni-td>
          <uni-td align="center">{{ row.itemMoney }}</uni-td>
        </uni-tr>
      </uni-table>
    </view>
  </view>
</template>

<script>
export default {
  props: {
    item: {}
  },
  data() {
    return {};
  },
  created() {},
  methods: {}
};
</script>

<style scoped lang="less">
::v-deep .uni-table-td {
  padding: 10rpx 16rpx;
}
::v-deep .uni-table-th {
  padding: 12rpx 16rpx;
}
::v-deep .uni-table {
  border-radius: 0;
  border: none;
}
</style>

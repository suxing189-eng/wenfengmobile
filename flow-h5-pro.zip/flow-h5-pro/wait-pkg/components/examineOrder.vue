<template>
  <view>
    <van-cell class="cell-name mb-5">
      <template #title>
        <view class="flex-between">
          <text style="font-weight: 600;width: 450rpx;overflow:hidden; text-overflow:ellipsis;white-space: nowrap;color: #666666;">{{ items.supplierName }}</text>
          <view>
            <text style="color: #909399;" v-if="items.examineState === -1">{{ items.stateText }}</text>
            <text v-else-if="items.examineState === 0">{{ items.stateText }}</text>
            <text style="color: #67C23A;" v-else-if="items.examineState === 1">{{ items.stateText }}</text>
            <text style="color: red;" v-else>{{ items.stateText }}</text>
          </view>
        </view>
      </template>
      <template #label>
        <view class="text-padding text-hide">{{ items.projectName }}</view>
        <view class="flex-between text-padding">
          <view class="">送货日期: {{ items.sendDate }}</view>
          <view class="">
            <view style="color: #67C23A;text-decoration: underline;display: inline-block;margin-right: 56rpx;" @click="agreeFlow(item, items)">同 意</view>
            <view style="color: #409EFF;text-decoration: underline;display: inline-block;" @click="examineOrder(item, items)">查看详情></view>
          </view>
        </view>
        <view class="flex-between text-padding">
          <view class="">请款金额: {{ items.totalMoney }} 元</view>
          <view class="">审批金额: {{ items.checkMoney }} 元</view>
        </view>
        <!-- <view class="text-padding">单据号：{{ items.paperNo }}</view> -->
        <view class="text-padding">{{ items.remark }}</view>
      </template>
    </van-cell>
  </view>
</template>

<script>
import { mapState, mapMutations } from 'vuex';
import { examineAgree } from '@/api/wait.js';
export default {
  props: {
    item: {},
    items: {}
  },
  data() {
    return {};
  },
  computed: {
    ...mapState('user', ['handleList'])
  },
  methods: {
    ...mapMutations('user', ['HANDLE_LIST']),
    // 点击审批
    examineOrder(item, items) {
      uni.navigateTo({
        url: '/wait-pkg/orderDispose?id=' + items.id + '&taskId=' + items.taskId + '&instanceId=' + items.instanceId + '&groupId=' + item.groupId + '&rejectBtn=' + 1
      });
    },
    // 同意
    async agreeFlow(row, rows) {
      try {
        this.Dialog.confirm({
          message: '确认同意此审批?'
        })
          .then(() => {
            examineAgree({ taskId: rows.taskId }).then(res => {
              this.Toast(res.data);
              setTimeout(() => {
                this.handle(row, rows);
              }, 600);
            });
          })
          .catch(() => {
            return;
            // this.Toast('接口错误');
          });
      } catch (e) {}
    },
    // 操作后改变数据
    handle(row, rows) {
      let list = this.handleList;
      list.forEach((item, index) => {
        // 通过id找到当前工程 再通过当前行数据的id找到请款单 移除掉已操作的数据
        if (item.groupId == row.groupId) {
          item.orderList.forEach((element, elementIndex) => {
            if (element.taskId == rows.taskId) {
              // 移除当前审批过的数据
              item.orderList.splice(elementIndex, 1);
            }
            // 如果全部审批了 就把上一级也移除
            if (item.orderList.length === 0) {
              list.splice(index, 1);
            }
          });
        }
      });
      this.HANDLE_LIST(list);
    }
  }
};
</script>

<style lang="scss" scoped>
.text-hide {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
::v-deep .van-cell__title,
.van-cell__value {
  overflow: auto;
}
</style>

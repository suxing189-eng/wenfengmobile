<template>
  <view class="mt-5" style="background-color: #fff;">
    <van-field v-model="reason" rows="2" autosize type="textarea" placeholder="请输入审批意见" />
    <view class="but-verify">
      <van-button @click="agreeFlow" class="btn" size="small" hairline type="primary">同意</van-button>
      <!-- <van-button v-if="rejectBtn" @click="rejectFlow" class="btn" size="small" hairline type="warning">驳回</van-button> -->
      <!-- <van-button v-if="startNode" @click="revokeFlow" class="btn" size="small" hairline type="">撤回</van-button> -->
      <van-button @click="terminateFlow" class="btn" size="small" hairline type="danger">终止</van-button>
    </view>
    <!-- 说明 -->
    <view class="remark-text">
      <view>同意：同意后，流程进入到下一个审批人。</view>
      <!-- <view>驳回：驳回后，流程进入到上一个审批人，一级一级往前驳回，直到发起人主动撤回。</view> -->
      <view>终止：终止后，流程直接结束，发起人可以重新提交单据。</view>
    </view>
    <view style="height: 6rpx;"></view>
  </view>
</template>

<script>
import { examineAgree, examineTerminate, examinerReject, examinerRevoke } from '@/api/wait.js';
import { mapState } from 'vuex';
export default {
  props: {
    taskId: {},
    startNode: {
      type: Boolean,
      default: true
    },
    rejectBtn: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      // 审批意见
      reason: ''
    };
  },
  onLoad(option) {},
  computed: {
    ...mapState('user', ['perList', 'handleList'])
  },
  methods: {
    // 同意
    async agreeFlow() {
      try {
        this.Dialog.confirm({
          message: '确认同意此审批?'
        })
          .then(() => {
            examineAgree({ taskId: this.taskId, reason: this.reason }).then(res => {
              this.Toast(res.data);
              setTimeout(() => {
                this.$emit('handle');
                uni.navigateBack();
              }, 600);
            });
          })
          .catch(() => {
            // this.Toast('接口错误');
            return;
          });
      } catch (e) {}
    },
    // 驳回
    rejectFlow() {
      try {
        this.Dialog.confirm({
          message: '确认驳回此审批?'
        })
          .then(() => {
            examinerReject({ taskId: this.taskId, reason: this.reason }).then(res => {
              this.Toast(res.data);
              setTimeout(() => {
                this.$emit('handle');
                uni.navigateBack();
              }, 600);
            });
          })
          .catch(() => {
            // this.Toast('接口错误');
            return;
          });
      } catch (e) {}
    },
    // 撤回
    revokeFlow() {
      try {
        this.Dialog.confirm({
          message: '确认撤回此审批?'
        })
          .then(() => {
            examinerRevoke({ taskId: this.taskId }).then(res => {
              this.Toast(res.data);
              setTimeout(() => {
                this.$emit('handle');
                uni.navigateBack();
              }, 600);
            });
          })
          .catch(() => {
            // this.Toast('接口错误');
            return;
          });
      } catch (e) {}
    },
    // 终止
    terminateFlow() {
      try {
        this.Dialog.confirm({
          message: '确认终止此审批?'
        })
          .then(() => {
            examineTerminate({ taskId: this.taskId, reason: this.reason }).then(res => {
              this.Toast(res.data);
              setTimeout(() => {
                this.$emit('handle');
                uni.navigateBack();
              }, 600);
            });
          })
          .catch(() => {
            // this.Toast('接口错误');
            return;
          });
      } catch (e) {}
    }
  }
};
</script>

<style lang="scss" scoped>
@function rpx2em($rpx) {
  @return ($rpx / 16) * 1rem;
}
.but-verify {
  display: flex;
  padding: rpx2em(5) rpx2em(10);
  justify-content: space-between;
  & > .btn {
    width: 25%;
    margin: 0 10rpx;
  }
}
::v-deep .van-button {
  border-radius: 0 !important;
}
.remark-text {
  margin: rpx2em(4) rpx2em(8);
  font-size: rpx2em(12);
  color: #666666;
  padding-left: rpx2em(4);
  border-left: rpx2em(6) solid #6666665c;
}
::v-deep .van-cell::after {
  border-bottom: 1px solid #ebedf0 !important;
}
</style>

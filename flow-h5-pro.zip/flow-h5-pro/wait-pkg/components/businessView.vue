<template>
  <view class="" @click="openDetail(item.id)">
    <van-panel class="cell-name">
      <template #header>
        <view class="header">
          <text style="font-weight: 600;width: 520rpx;" class="text-nowrap">{{ item.businessName }}</text>
          <text style="color: #666666;">{{ item.businessStateName }}</text>
        </view>
      </template>
      <view style="padding: 0 32rpx;">
        <view class="flex-between text-padding">
          <view>状态: {{ item.businessState }}</view>
          <view>上次跟进: {{ item.followDate }}</view>
        </view>
        <view class="text-padding">地址: {{ item.businessAddress }}</view>
        <view class="flex-between text-padding">
          <view>登记人: {{ item.createBy }}</view>
          <view>登记时间：{{ item.businessDate }}</view>
        </view>
        <view class="flex-between text-padding">
          <view>联系人: {{ item.contactUser }}</view>
          <view>联系电话：{{ item.contactPhone }}</view>
        </view>
      </view>
    </van-panel>
  </view>
</template>

<script>
export default {
  props: {
    item: {}
  },
  methods: {
    // 打开详情
    openDetail(id) {
      uni.navigateTo({ url: '/index-pkg/businessDetail?id=' + id });
    }
  },
};
</script>

<style>
.header {
  padding: 18rpx 32rpx;
  display: flex;
  justify-content: space-between;
}
</style>

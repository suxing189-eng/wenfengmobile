<template>
  <view style="overflow: auto;">
    <van-cell>
      <template #title>
        <view class="flex-between">
          <text style="font-weight: 600;width: 520rpx;overflow:hidden; text-overflow:ellipsis;white-space: nowrap;">{{ item.projectName }}</text>
          <view>
            <text style="color: #909399;" v-if="item.examineState === -1">{{ item.stateText }}</text>
            <text style="color: #409EFF;" v-else-if="item.examineState === 0">{{ item.stateText }}</text>
            <text style="color: #67C23A;" v-else-if="item.examineState === 1">{{ item.stateText }}</text>
            <text style="color: red;" v-else>{{ item.stateText }}</text>
          </view>
        </view>
      </template>
      <template #label>
        <view class="flex-between text-padding">
          <view class="">合同总额: {{ item.contractMoney }} 元</view>
          <view class="">完工后验收总额: {{ item.finishAuditMoney }} 元</view>
        </view>
        <view class="flex-between text-padding">
          <view class="">工程利润总额: {{ item.profitMoney }} 元</view>
          <view class="">工程利润率: {{ item.profitRate }}%</view>
        </view>
        <view class="text-padding">应结算项目经理工程款: {{ item.needPayMoney }} 元</view>
        <view class="text-padding">{{ item.remark }}</view>
      </template>
    </van-cell>
  </view>
</template>

<script>
export default {
  props: {
    item: {}
  },
  data() {
    return {};
  },
  created() {},
  methods: {}
};
</script>

<style scoped lang="less"></style>

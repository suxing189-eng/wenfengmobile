<template>
  <view>
    <!-- 列表内容 -->
    <van-panel class="">
      <template #header>
        <view class="header">
          <text style="font-weight: 600;width: 520rpx;">{{ item.approveName }}</text>
          <text :class="item.examineState === -1 ? 'info-color' : item.examineState === 1 ? 'green-color' : item.examineState === 0 ? 'color-blue' : 'color-red'">
            {{ item.stateText }}
          </text>
        </view>
      </template>
      <view v-if="!show" style="padding: 0 32rpx;">
        <view class="text-padding">申请日期: {{ item.approveDate }}</view>
        <view class="text-padding">申请人员: {{ `${item.approveUserName} / ${item.approveDeptName}` }}</view>
      </view>
      <view v-else style="padding: 0 32rpx;">
        <view class="flex-between text-padding">
          <view class="">申请日期</view>
          <view class="">{{ item.approveDate }}</view>
        </view>
        <view class="flex-between text-padding">
          <view class="">申请人员</view>
          <view class="">{{ `${item.approveUserName} / ${item.approveDeptName}` }}</view>
        </view>
        <!-- 自定义表单数据 -->
        <view v-for="(child, index) in item.fieldData" :key="index">
          <view v-if="child.type !== 'textarea'" class="flex-between text-padding">
            <view class="">{{ child.name }}:</view>
            <view class="">{{ child.value }}</view>
          </view>
          <view v-else class="text-padding">
            <view style="margin-bottom: 6rpx;">{{ child.name }}:</view>
            <view style="color: #909399;font-size: 24rpx;">{{ child.value }}</view>
          </view>
        </view>
      </view>
    </van-panel>
  </view>
</template>

<script>
export default {
  props: {
    item: {},
    show: {}
  },
  data() {
    return {};
  },
  methods: {}
};
</script>

<style scoped lang="less">
.header {
  padding: 18rpx 32rpx;
  display: flex;
  justify-content: space-between;
}
.info-color {
  color: #666666;
}
.green-color {
  color: #00cc00;
}
.red-color {
  color: red;
}
</style>

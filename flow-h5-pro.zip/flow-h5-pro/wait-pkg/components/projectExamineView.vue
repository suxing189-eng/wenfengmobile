<template>
  <view class="">
    <van-panel>
      <template #header>
        <view class="header">
          <text style="font-weight: 600;width: 520rpx;" class="text-nowrap">{{ item.projectName }}</text>
          <text :class="item.examineState === -1 ? 'info-color' : item.examineState === 1 ? 'green-color' : item.examineState === 0 ? 'color-blue' : 'color-red'">
            {{ item.stateText }}
          </text>
        </view>
      </template>
      <view style="padding: 0 32rpx;">
        <view class="text-padding">工程类型: {{ item.projectType | projectTypeFilter }}</view>
        <view class="text-padding">工程地址: {{ item.address }}</view>
        <view class="text-padding">客户名称: {{ item.customerName }}</view>
        <view class="flex-between text-padding">
          <view>创建人: {{ item.createBy }}</view>
          <view>创建时间：{{ item.createTime }}</view>
        </view>
      </view>
    </van-panel>
  </view>
</template>

<script>
export default {
  props: {
    item: {}
  },
  filters: {
    // 工程类型
    projectTypeFilter(value) {
      let values = {
        '1': '施工单',
        '2': '设计单',
        '3': '联营单'
      };
      return values[value];
    }
  }
};
</script>

<style>
.header {
  padding: 18rpx 32rpx;
  display: flex;
  justify-content: space-between;
}
</style>

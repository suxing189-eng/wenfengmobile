<template>
  <view class="">
    <van-panel>
      <template #header>
        <view class="header">
          <text style="font-weight: 600;width: 520rpx;" class="text-nowrap">{{ item.projectName }}</text>
          <text :class="item.examineState === -1 ? 'info-color' : item.examineState === 1 ? 'green-color' : item.examineState === 0 ? 'color-blue' : 'red-color'">
            {{ item.stateText }}
          </text>
        </view>
      </template>
      <view style="padding: 0 32rpx;">
        <view class="flex-between text-padding">
          <view class="text-nowrap">收款人: {{ item.payeeUser }}</view>
          <view>提成日期：{{ item.comDate }}</view>
        </view>
        <view class="text-padding">提成金额: {{item.requestMoney}} 元</view>
        <view class="text-padding">{{ item.remark }}</view>
      </view>
    </van-panel>
  </view>
</template>

<script>
export default {
  props: {
    item: {}
  },
};
</script>

<style>
.header {
  padding: 18rpx 32rpx;
  display: flex;
  justify-content: space-between;
}
</style>

<template>
  <view class="mt-10">
    <van-tabs v-model="active" offset-top="44px" @change="tabChange" title-inactive-color="#666666" title-active-color="#000">
      <van-tab title="审批记录">
        <van-steps style="margin-top: 10rpx;" direction="vertical" :active="recordData.length - 1">
          <van-step
            v-for="item in recordData"
            :key="item.id"
            :class="item.taskState === 2 || item.taskState == 8 || item.taskState == 10 ? 'green-text' : item.taskState == 3 || item.taskState == 6 ? 'red-color' : 'info-text'"
          >
            <view class="flex-between">
              <view style="font-weight: 600;">{{ item.taskName }}</view>
              <view v-if="item.finishTime">{{ `${item.finishTime} 耗时：${item.duration}` }}</view>
            </view>
            <view class="flex-between" style="padding:10rpx 0;">
              <p style="width: 280rpx;">{{ item.actorName }} <text v-if="item.taskState && item.taskState !== 0">({{ item.taskState | taskStateFilter }})</text></p>
              <view>{{ item.execContent }}</view>
            </view>
          </van-step>
        </van-steps>
      </van-tab>
      <van-tab title="审批流程">
        <van-steps style="margin-top: 10rpx;" direction="vertical" :active="examineData.length - 1" active-color="#a8adaf">
          <van-step v-for="item in examineData" :key="item.id">
            <view class="flex-between">
              <view style="font-weight: 600;width: 128rpx;">{{ item.title }}</view>
              <view class="">
                <text v-for="i in item.users" :key="i.id">{{ i.name }},</text>
              </view>
            </view>
            <p style="padding:10rpx 0;color: #a8adaf;">{{ item.desc }}</p>
          </van-step>
        </van-steps>
      </van-tab>
    </van-tabs>
  </view>
</template>

<script>
export default {
  props: {
    // 审批过程记录
    recordData: {},
    // 审批流程
    flowData: {}
  },
  data() {
    return {
      active: 0,
      // 审批流程转换后的数据
      examineData: [],
      activities: []
    };
  },
  filters: {
    taskStateFilter(value) {
      let values = {
        0: '活动',
        1: '跳转',
        2: '已审批',
        3: '被驳回',
        4: '撤销审批',
        5: '超时',
        6: '终止'
      };
      return values[value];
    }
  },
  onLoad() {},
  methods: {
    // tab页回调
    tabChange() {
      this.startProcess();
    },
    // 格式转换
    startProcess() {
      this.examineData = [];
      this.getProcess(this.flowData.nodeConfig, this.activities, this.examineData);

      this.examineData.push({
        title: '结束',
        name: 'END',
        icon: 'el-icon-success',
        isEdit: false
      });
    },
    // 渲染节点
    getProcess(process, data, cc) {
      if (null != process && undefined != process) {
        if (0 === process.type) {
          //发起人节点
          this.getRootNode(cc, process);
        } else if (1 === process.type) {
          //审批节点
          this.getApprovalNode(cc, process);
        } else if (2 === process.type) {
          this.getCcNode(cc, process);
        } else if ('CONDITIONS' === process.type) {
          //判断是否符合条件符合走条件分支,否则继续递归子分支
          if (null != process.branchs && undefined != process.branchs) {
            console.log('进入了分支');
            // this.getConditionNode(cc, process);
          }
        } else if ('CONCURRENTS' === process.type) {
          console.log('进入了分支');
          // this.getConcurrentNode(cc, process);
        }
        if (null != process.childNode && undefined != process.childNode) {
          this.getProcess(process.childNode, data, cc);
        }
      }
    },
    //封装开始节点
    getRootNode(cc, process) {
      cc.push({
        id: process.id,
        title: process.nodeName,
        name: '发起人',
        icon: 'el-icon-user-solid',
        isEdit: false,
        users: []
      });
    },
    //封装审批节点
    getApprovalNode(cc, process) {
      var data = {
        id: process.id,
        title: process.nodeName,
        name: '审批人',
        icon: 'el-icon-s-check',
        isEdit: false,
        multiple: false,
        users: [],
        desc: ''
      };
      //判断审批人类型
      switch (process.setType) {
        case 1:
          data.users = process.nodeAssigneeList && JSON.parse(JSON.stringify(process.nodeAssigneeList));
          data.desc = '指定成员';
          break;
        case 2:
          data.desc = '主管';
          break;
        case 4:
          data.isEdit = true;
          data.multiple = process.termAuto || false;
          data.desc = '发起人自选';
          break;
        case 7:
          data.desc = '连续多级主管';
          break;
        case 3:
          data.desc = '由角色['.concat(
            (process.nodeAssigneeList || []).map(function(e) {
              return e.name;
            }),
            ']审批'
          );
          break;
        case 'REFUSE':
          data.desc = '流程此处将被自动驳回';
          break;
      }
      cc.push(data);
    },
    getCcNode(cc, process) {
      var data = {
        id: process.id,
        title: process.nodeName,
        icon: 'el-icon-s-promotion',
        name: '抄送人',
        type: 'org',
        multiple: true,
        users: JSON.parse(JSON.stringify(process.nodeAssigneeList))
      };
      cc.push(data);
    }
  }
};
</script>

<style lang="scss" scoped>
.green-text {
  color: #07c160;
}
::v-deep .van-tabs--line .van-tabs__wrap {
  height: 32px;
}
.info-text ::v-deep .van-step__circle {
  background-color: #a8adaf !important;
}
.info-text ::v-deep .van-step__icon--active {
  color: #a8adaf !important;
}
.info-text ::v-deep .van-step__title--active {
  color: #a8adaf !important;
}

::v-deep .van-step--finish .van-step__line {
  background-color: #eee !important;
}

.red-color ::v-deep .van-step__circle {
  background-color: red !important;
}
.red-color ::v-deep .van-step__icon--active {
  color: red !important;
}
</style>

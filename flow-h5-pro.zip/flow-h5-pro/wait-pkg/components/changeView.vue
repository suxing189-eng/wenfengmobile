<template>
  <view class="">
    <van-panel class="cell-name">
      <template #header>
        <view class="header">
          <text style="font-weight: 600;width: 520rpx;" class="text-nowrap">{{ item.projectName }}</text>
          <text :class="item.examineState === -1 ? 'info-color' : item.examineState === 1 ? 'green-color' : item.examineState === 0 ? 'color-blue' : 'red-color'">
            {{ item.stateText }}
          </text>
        </view>
      </template>
      <view style="padding: 0 32rpx;">
        <view class="flex-between text-padding">
          <view class="text-nowrap">变更编号: {{ item.changeNo }}</view>
          <view>变更日期: {{ item.changeDate }}</view>
        </view>
        <view class="flex-between text-padding">
          <view class="text-nowrap">变更金额: {{ item.changeMoney }}</view>
          <view v-if="item.changeType === 1">变更类型: 增项单</view>
          <view v-else>变更类型:减项单</view>
        </view>
        <view class="text-padding" v-if="item.signState === 0">{{ item.signStateText }}</view>
        <view class="text-padding" style="color: #13ce66;" v-if="item.signState === 1">{{ item.signStateText }}</view>
        <view class="text-padding" style="color: #f00;" v-if="item.signState === 2">{{ item.signStateText }}</view>
      </view>
    </van-panel>
  </view>
</template>

<script>
export default {
  props: {
    item: {}
  }
};
</script>

<style>
.header {
  padding: 18rpx 32rpx;
  display: flex;
  justify-content: space-between;
}
</style>

<template>
  <view class="">
    <van-cell v-for="item in detailData" :key="item.id">
      <template #title>
        <view class="flex-between">
          <text class="text-nowrap" style="font-weight: 600;width: 500rpx;">{{ item.itemName }}</text>
          <view>单位: {{ item.itemUnit }}</view>
        </view>
      </template>
      <template #label>
        <view class="flex-between text-padding">
          <view>
            <view style="padding-bottom: 14rpx;">单价</view>
            <view>{{ item.itemPrice }}</view>
          </view>
          <view>
            <view style="padding-bottom: 14rpx;">数量</view>
            <view>{{ item.itemAmount }}</view>
          </view>
          <view>
            <view style="padding-bottom: 14rpx;">总额</view>
            <view>{{ item.itemMoney }}</view>
          </view>
        </view>
      </template>
    </van-cell>
    <van-empty v-if="detailData.length === 0" description="当前单据没有材料明细" />
  </view>
</template>

<script>
export default {
  props: {
    detailData: {
      type: Array,
      default: () => {
        return [];
      }
    }
  }
};
</script>

<style></style>

<template>
  <!-- 通知签单审批 -->
  <view class="gray-bj-color" style="height: 100%;">
    <!-- 通知签单信息 -->
    <project-examine-view :item="projectInfo"></project-examine-view>
    <!-- 审批意见 -->
    <examine-idea :taskId="projectInfo.taskId" @handle="handle"></examine-idea>
    <!-- 审批记录 -->
    <examine-record :recordData="recordData" :flowData="flowData"></examine-record>
  </view>
</template>

<script>
import { executeHistory } from '@/api/wait.js';
import projectExamineView from '@/wait-pkg/components/projectExamineView.vue';
import examineIdea from '@/wait-pkg/components/examineIdea.vue';
import examineRecord from '@/wait-pkg/components/examineRecord.vue';
import { mapState, mapMutations } from 'vuex';
export default {
  components: {
    examineIdea,
    projectExamineView,
    examineRecord
  },
  data() {
    return {
      // 客户信息
      projectInfo: {},
      // 流程数据
      flowData: [],
      // 记录数据
      recordData: []
    };
  },

  onLoad(option) {
    this.projectInfo = JSON.parse(decodeURIComponent(option.key));
    this.getData();
  },
  computed: {
    ...mapState('user', ['handleList'])
  },
  methods: {
    ...mapMutations('user', ['HANDLE_LIST']),
    async getData() {
      try {
        let { data } = await executeHistory({ instanceId: this.projectInfo.instanceId });
        this.flowData = JSON.parse(data.process);
        this.recordData = data.taskLogs;
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 操作后改变数据
    handle() {
      let list = this.handleList;
      list.forEach((item, index) => {
        // 通过id找到当前数据
        if (item.id == this.projectInfo.id) {
          list.splice(index, 1);
        }
      });
      this.HANDLE_LIST(list);
    }
  }
};
</script>

<style>
.header {
  padding: 18rpx 32rpx;
  display: flex;
  justify-content: space-between;
}
</style>

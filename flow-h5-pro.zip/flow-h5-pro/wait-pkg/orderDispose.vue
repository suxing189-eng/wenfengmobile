<template>
  <!-- 订货单审批 -->
  <view class="gray-bj-color" style="height: 100%;">
    <!-- 订货单审批信息 -->
    <van-cell>
      <template #title>
        <view class="flex-between">
          <text style="font-weight: 600;width: 95%;overflow:hidden; text-overflow:ellipsis;white-space: nowrap;color: #666666;">{{ info.supplierName }}</text>
        </view>
      </template>
      <template #label>
        <view class="flex-between text-padding">
          <view class="">项目经理: {{ info.dutyUserName }}</view>
          <view>
            <text>
              审批节点：
              <text v-if="info.examineState === -1" style="color: #909399;">{{ info.stateText }}</text>
              <text v-else-if="info.examineState === 0" style="color: #409EFF;">{{ info.stateText }}</text>
              <text v-else-if="info.examineState === 1" style="color: #67C23A;">{{ info.stateText }}</text>
              <text v-else style="color: red;">{{ info.stateText }}</text>
            </text>
            <!-- <text style="color: #409EFF;" v-else-if="info.examineState === 0">审批节点： {{ info.stateText }}</text>
            <text style="color: #67C23A;" v-else-if="info.examineState === 1">审批节点： {{ info.stateText }}</text> -->
          </view>
        </view>
        <view class="flex-between text-padding">
          <view class="">送货日期: {{ info.sendDate }}</view>
          <view>订单金额: {{ info.totalMoney }} 元</view>
        </view>
        <view class="flex-between text-padding">
          <view class="un_blue" @click="openDetail(info)">单据号：{{ info.paperNo }}</view>
          <view class="un_blue" @click="editMoney(info)">审批金额: {{ info.checkMoney }} 元</view>
        </view>
        <!-- <view class="text-padding">单据号：{{ info.paperNo }}</view> -->
        <view class="text-padding">{{ info.remark }}</view>
      </template>
    </van-cell>
    <!-- 表格详情 -->
    <view class="">
      <uni-table class="" style="max-height: 300px !important;" border emptyText="暂无更多数据">
        <!-- 表头行 -->
        <uni-tr class="table-header">
          <uni-th min-width="110" align="left">名称</uni-th>
          <uni-th width="60" align="center">单位</uni-th>
          <uni-th width="60" align="center">数量</uni-th>
          <uni-th width="80" align="center">单价</uni-th>
        </uni-tr>
        <!-- 表格数据行 -->
        <uni-tr v-for="row in info.itemList" :key="row.id">
          <uni-td align="left">{{ row.itemName }}</uni-td>
          <uni-td align="center">{{ row.itemUnit }}</uni-td>
          <uni-td align="center">{{ row.itemAmount }}</uni-td>
          <uni-td align="center">{{ row.itemPrice }}</uni-td>
        </uni-tr>
      </uni-table>
    </view>
    <!-- 审批意见 -->
    <examine-idea :startNode="startNode" :rejectBtn="rejectBtn" :taskId="taskId" @handle="handle"></examine-idea>
    <!-- 审批记录 -->
    <examine-record :recordData="recordData" :flowData="flowData"></examine-record>
    <!-- 修改审批金额 -->
    <van-dialog v-model="showMoney" @confirm="confirm" title="修改审批金额" show-cancel-button>
      <van-form class="money-form">
        <van-field v-model="examineMoney" type="number" name="审批金额" label="审批金额" placeholder="审批金额" :rules="[{ required: true, message: '请输入审批金额' }]" />
      </van-form>
    </van-dialog>
  </view>
</template>

<script>
import { executeHistory, supplierOrderGetById, supplierOrderMoney } from '@/api/wait.js';
import examineIdea from '@/wait-pkg/components/examineIdea.vue';
import examineOrder from '@/wait-pkg/components/examineOrder.vue';
import examineRecord from '@/wait-pkg/components/examineRecord.vue';
import { mapState, mapMutations } from 'vuex';
export default {
  components: {
    examineIdea,
    examineOrder,
    examineRecord
  },
  data() {
    return {
      // 提成支付审批信息
      info: {},
      // 流程数据
      flowData: [],
      // 记录数据
      recordData: [],
      // 审批金额弹窗显示
      showMoney: false,
      // 审批金额
      examineMoney: 0,
      billsId: 0,
      processId: 0,
      // 撤回按钮显示
      startNode: false,
      taskId: 0,
      groupId: '',
      rejectBtn: false
    };
  },
  onLoad(option) {
    this.taskId = option.taskId;
    this.billsId = option.id;
    this.processId = option.instanceId;
    this.groupId = option.groupId;
    this.rejectBtn = option.rejectBtn == 1 ? false : true;
    this.getData();
    this.getDetail();
  },
  computed: {
    ...mapState('user', ['handleList'])
  },
  methods: {
    ...mapMutations('user', ['HANDLE_LIST']),
    // 获取列表详情数据
    async getDetail() {
      try {
        let { data } = await supplierOrderGetById({ id: this.billsId });
        this.info = data;
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 获取流程记录数据
    async getData() {
      try {
        let { data } = await executeHistory({ instanceId: this.processId });
        this.flowData = JSON.parse(data.process);
        this.recordData = data.taskLogs;
        this.startNode = data.startNode;
      } catch (e) {}
    },
    // 修改金额
    editMoney(item) {
      this.examineMoney = JSON.parse(JSON.stringify(item.checkMoney));
      this.showMoney = true;
    },
    // 跳转详情
    openDetail(item) {
      uni.navigateTo({ url: '/index-pkg/materialsView?id=' + item.id });
    },
    // 保存金额按钮
    confirm() {
      try {
        supplierOrderMoney({ id: this.billsId, examineMoney: this.examineMoney }).then(res => {
          if (res.code === 200) {
            this.Toast.success('修改成功');
            this.getDetail();
          } else {
            this.Toast.error(res.msg);
          }
        });
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 操作后改变数据
    handle() {
      let list = this.handleList;
      list.forEach((item, index) => {
        // 通过id找到当前工程 再通过当前行数据的id找到请款单 移除掉已操作的数据
        if (item.groupId == this.groupId) {
          item.orderList.forEach((element, elementIndex) => {
            if (element.taskId == this.taskId) {
              // 移除当前审批过的数据
              item.orderList.splice(elementIndex, 1);
            }
            // 如果全部审批了 就把上一级也移除
            if (item.orderList.length === 0) {
              list.splice(index, 1);
            }
          });
        }
      });
      this.HANDLE_LIST(list);
    }
  }
};
</script>

<style scoped lang="scss">
@function rpx2em($rpx) {
  @return ($rpx / 16) * 1rem;
}
.text-padding {
  padding: rpx2em(2) 0;
}
.header {
  padding: rpx2em(8) rpx2em(16);
  display: flex;
  justify-content: space-between;
}
.un_blue {
  text-decoration: underline;
  color: #409eff;
}
.money-form ::v-deep .van-cell {
  padding: rpx2em(16) rpx2em(16);
}

::v-deep .uni-table-td {
  font-size: rpx2em(13);
  padding: rpx2em(4);
}
::v-deep .uni-table-th {
  padding: rpx2em(8);
}
.uni-table-th {
  position: sticky;
  top: 0;
  background-color: #f8f8f8;
  z-index: 10;
}
::v-deep .table--border {
  border-top: none;
}
::v-deep .van-cell::after {
  border-bottom: none;
}
</style>

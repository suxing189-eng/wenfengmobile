<template>
  <!-- 提成支付审批 -->
  <view class="gray-bj-color" style="height: 100%;">
    <!-- 提成支付审批信息 -->
    <commission-view :item="info"></commission-view>
    <!-- 审批意见 -->
    <examine-idea :startNode="startNode" :taskId="taskId" @handle="handle"></examine-idea>
    <!-- 审批记录 -->
    <examine-record :recordData="recordData" :flowData="flowData"></examine-record>
  </view>
</template>

<script>
import { executeHistory, commissionGetById } from '@/api/wait.js';
import commissionView from '@/wait-pkg/components/commissionView.vue';
import examineIdea from '@/wait-pkg/components/examineIdea.vue';
import examineRecord from '@/wait-pkg/components/examineRecord.vue';
import { mapState, mapMutations } from 'vuex';
export default {
  components: {
    examineIdea,
    commissionView,
    examineRecord
  },
  data() {
    return {
      // 提成支付审批信息
      info: {},
      // 流程数据
      flowData: [],
      // 记录数据
      recordData: [],
      // 撤回按钮显示
      startNode: false,
      id: undefined,
      taskId: undefined
    };
  },
  computed: {
    ...mapState('user', ['handleList'])
  },
  onLoad(option) {
    this.id = option.id;
    this.taskId = option.taskId;
    this.getDetail();
  },
  methods: {
    ...mapMutations('user', ['HANDLE_LIST']),
    // 获取提成数据详情
    async getDetail() {
      try {
        let { data } = await commissionGetById({ id: this.id });
        this.info = data;
        this.getData();
      } catch (e) {
        //TODO handle the exception
      }
    },
    async getData() {
      try {
        let { data } = await executeHistory({ instanceId: this.info.flowInstanceId });
        this.flowData = JSON.parse(data.process);
        this.recordData = data.taskLogs;
        this.startNode = data.startNode;
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 操作后改变数据
    handle() {
      let list = this.handleList;
      list.forEach((item, index) => {
        // 通过id找到当前数据
        if (item.id == this.id) {
          list.splice(index, 1);
        }
      });
      this.HANDLE_LIST(list);
    }
  }
};
</script>

<style>
.header {
  /* padding: 18rpx 32rpx; */
  display: flex;
  justify-content: space-between;
}
</style>

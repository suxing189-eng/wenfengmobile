<template>
  <view class="gray-bj-color">
    <!-- 列表内容 -->
    <van-panel>
      <template #header>
        <view class="header">
          <text style="font-weight: 600;width: 380rpx;">{{ info.eventName }}</text>
          <text>{{ info.createTime }}</text>
        </view>
      </template>
      <view style="padding: 0 32rpx 14rpx 32rpx;">
        <view class="flex-between text-padding">
          <view class="">{{ info.msgTitle }}</view>
          <view>
            <text v-if="!info.msgState">未读</text>
            <text v-else>已读</text>
          </view>
        </view>
        <view class="mt-10">
          <text style="color:#666666;" v-html="info.msgContent"></text>
        </view>
      </view>
    </van-panel>
  </view>
</template>

<script>
import { messageDetail } from '@/api/wait.js';
export default {
  data() {
    return {
      id: undefined,
      info: {}
    };
  },
  onLoad(option) {
    this.id = option.id;
    this.getData();
  },
  methods: {
    async getData() {
      try {
        let { data } = await messageDetail({ id: this.id });
        this.info = data;
      } catch (e) {
        //TODO handle the exception
      }
    }
  }
};
</script>

<style scoped lang="scss">
.header {
  padding: 18rpx 32rpx;
  display: flex;
  justify-content: space-between;
}
::v-deep a {
  text-decoration: underline;
}
</style>

<template>
  <view class="gray-bj-color-44">
    <van-tabs v-model="active" sticky offset-top="44px" @change="tabChange" title-inactive-color="#666666" title-active-color="#000">
      <van-tab v-for="item in tabList" :key="item.value" :title="item.label">
        <!-- 下拉刷新 -->
        <van-pull-refresh v-model="isLoading" @refresh="onRefresh">
          <!-- 列表 上拉加载 -->
          <van-list v-model="loading" :finished="finished" :finished-text="finishedText" @load="upwardPull">
            <view class="pt-5"><message-view v-for="(item, index) in massageData" :key="item.id" :item="item"></message-view></view>
            <!-- 暂无数据 -->
            <van-empty v-if="massageData.length === 0" description="暂无数据" />
          </van-list>
        </van-pull-refresh>
      </van-tab>
    </van-tabs>
  </view>
</template>

<script>
import { massageList } from '@/api/wait.js';
import messageView from '../index-pkg/components/messageView.vue';
export default {
  components: {
    messageView
  },
  data() {
    return {
      tabList: [{ value: '0', label: '未读' }, { value: '1', label: '已读' }, { value: '2', label: '全部' }],
      active: 0,
      queryParams: {
        msgState: '0',
        pageNo: 0,
        pageSize: 10
      },
      // 列表数据
      massageData: [],
      // 下拉状态
      loading: false,
      // 是否已加载完成
      finished: false,
      // 加载完成文字
      finishedText: '没有更多了',
      isLoading: false
    };
  },
  onLoad() {},
  methods: {
    // 获取我的消息数据
    async getData() {
      try {
        if (this.active === 0) {
          this.queryParams.msgState = '0';
          let { data, dataCount } = await massageList(this.queryParams);
          this.massageData = this.massageData.concat(data);
          this.loading = false;
          this.isLoading = false;
          // 判断是否已经全部加载完成
          this.allLoading(dataCount);
        } else if (this.active === 1) {
          this.queryParams.msgState = '1';
          let { data, dataCount } = await massageList(this.queryParams);
          this.massageData = this.massageData.concat(data);
          this.loading = false;
          this.isLoading = false;
          // 判断是否已经全部加载完成
          this.allLoading(dataCount);
        } else {
          this.queryParams.msgState = '';
          let { data, dataCount } = await massageList(this.queryParams);
          this.massageData = this.massageData.concat(data);
          this.loading = false;
          this.isLoading = false;
          // 判断是否已经全部加载完成
          this.allLoading(dataCount);
        }
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 判断是否已经全部加载完成
    allLoading(dataCount) {
      if (this.queryParams.pageNo * this.queryParams.pageSize > dataCount) {
        this.finished = true;
      }
      if (dataCount === 0) {
        this.finishedText = '';
      } else {
        this.finishedText = '没有更多了...';
      }
    },
    // 上拉回调
    upwardPull() {
      this.queryParams.pageNo += 1;
      this.getData();
    },
    // tab回调函数
    tabChange() {
      this.queryParams.pageNo = 1;
      this.massageData = [];
      this.getData();
    },
    // 下拉刷新
    onRefresh() {
      this.queryParams.pageNo = 1;
      this.massageData = [];
      this.getData();
    }
  }
};
</script>

<style scoped lang="scss">
@function rpx2em($rpx) {
  @return ($rpx / 16) * 1rem;
}
.van-empty {
  padding: rpx2em(20) 0;
}
::v-deep .van-pull-refresh {
  height: calc(100vh - 5.4rem);
  overflow: auto;
}
</style>

<template>
  <view class="gray-bj-color">
    <van-pull-refresh v-model="isLoading" @refresh="getData">
      <view class="tab"></view>
      <van-grid clickable :column-num="2">
        <van-grid-item v-for="item in examineData" :key="item.bizCode" @click="tabDetail(item.bizCode)">
          <view class="">
            <view style="font-size: 36rpx;" class="content-text">{{ item.count }}</view>
            <view class="content-text">{{ item.bizName }}</view>
          </view>
        </van-grid-item>
      </van-grid>
    </van-pull-refresh>
  </view>
</template>

<script>
import { todoCount } from '@/api/wait.js';
export default {
  data() {
    return {
      // 审批数据
      examineData: [],
      isLoading: false
    };
  },
  onLoad() {
    this.getData();
  },
  methods: {
    // 获取数据
    async getData() {
      try {
        let { data } = await todoCount({
          bizCodeList: 'EX-ADD-CUSTOMER,EX-ADD-SUPPLIER,EX-ADD-PROJECT,EX-PROJECT-APPLY,EX-PROJECT-ORDER,EX-PROJECT-COMMISSION,EX-PROJECT-STATEMENT,EX-MANAGE-COST'
        });
        this.examineData = data;
        this.isLoading = false;
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 进入宫格详情
    tabDetail(value) {
      if (value === 'EX-ADD-CUSTOMER') {
        // 客户
        uni.navigateTo({ url: '/wait-pkg/customerExamine' });
      } else if (value === 'EX-ADD-SUPPLIER') {
        // 供应商
        uni.navigateTo({ url: '/wait-pkg/supplierExamine' });
      } else if (value === 'EX-ADD-PROJECT') {
        // 通知签单
        uni.navigateTo({ url: '/wait-pkg/projectEaxmine' });
      } else if (value === 'EX-PROJECT-APPLY') {
        // 工程请款
        uni.navigateTo({ url: '/wait-pkg/projectApplyExamine' });
      } else if (value === 'EX-PROJECT-ORDER') {
        // 材料单
        uni.navigateTo({ url: '/wait-pkg/projectOrderExamine' });
      } else if (value === 'EX-PROJECT-COMMISSION') {
        // 提成支付
        uni.navigateTo({ url: '/wait-pkg/commissionExamine' });
      } else if (value === 'EX-PROJECT-STATEMENT') {
        // 结算单
        uni.navigateTo({ url: '/wait-pkg/statementExamine' });
      } else if (value === 'EX-MANAGE-COST') {
        // 经营成本
        uni.navigateTo({ url: '/wait-pkg/costExamine' });
      } else if (value === 'EX-OA-APPROVAL') {
        // 行政审批
        uni.navigateTo({ url: '/wait-pkg/oaExamine' });
      } else if (value === 'EX-CHANGE-LIST') {
        // 变更清单
        uni.navigateTo({ url: '/wait-pkg/changeExamine' });
      } else {
        return;
      }
    }
  }
};
</script>

<style scoped lang="scss">
.content-text {
  color: #646566;
  text-align: center;
}
::v-deep .van-pull-refresh {
  overflow: auto;
}
</style>

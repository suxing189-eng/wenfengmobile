export default {

  // 本地服务器
  DEV_API: 'http://192.168.1.88:8899',
  // DEV_API: 'https://api.xmfkz.com',

  // 测试服务器
  // DEV_API: 'http://47.106.78.10:8081',	 
}

import axios from 'axios';
import {
  Toast
} from "vant"
import API from '@/apiBase.js';

axios.defaults.headers['Content-Type'] = 'application/x-www-form-urlencoded;charset=utf-8';
// 创建axios实例
const service = axios.create({
  // axios中请求配置有baseURL选项，表示请求URL公共部分
  // baseURL: API.DEV_API,
  baseURL: window.config.apiUrl,
  // 超时
  timeout: 90000,
})

// request拦截器
service.interceptors.request.use(function(config) {
  // 登录接口不需要token
  let whiteApi = ['AccAdmin/doLogin','SpCfg/getCfg','/ProjectTrend/getList']
  let checkApi = whiteApi.some(item => item === config.url);
  let token = sessionStorage.getItem('satoken');
  if (checkApi) {
    return config
  } else {
    if (token) {
      config.headers['token'] = token;
      Toast.loading({
        message: "加载中...",
        forbidClick: true,
        duration: 300
      });
      return config;
    } else {
      // 没有token 回登录页
      uni.reLaunch({
        url: "/pages/login/index"
      })
      return false;
    }
  }
  return config;
}, function(error) {
  // 对请求错误做些什么
  return Promise.reject(error);
});

// 响应拦截器
service.interceptors.response.use(res => {
  // console.log('登录返回的数据======================>', res);
  if (res.data.code === 200) {
    return res.data;
  } else if (res.data.code === 401) {
    uni.reLaunch({
      url: "/pages/login/index"
    })
  } else if (res.data.code === 500) {
    Toast.fail(res.data.msg);
  } else {
    Toast.fail('未知错误！');
  }
  // return res.data;
}, error => {})

export default service

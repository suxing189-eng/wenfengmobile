<template>
  <view>
    <video
      style="width: 100%;height: 100%;"
      @play="play"
      @loadedmetadata="loadedmetadata"
      :custom-cache="false"
      class="video-body"
      :danmu-list="danmuList"
      :src="video"
      controls
      object-fit="fill"
    />
  </view>
</template>

<script>
export default {
  data() {
    return {
      // 视频
      trailer: [],
      danmuList: [],
      video: ""
    };
  },
  onLoad(option) {
    this.video = option.video;
  },
  methods: {
    // 获取视频信息
    loadedmetadata(e) {
      this.$nextTick(() => {
        this.trailer.push(e.target.id);
      });
    },
    // 控制视频播放
    play(e) {
      setTimeout(() => {
        let createId = e.target.id;
        this.trailer.forEach(id => {
          if (id != createId) uni.createVideoContext(id + '', this).pause();
        });
      }, 500);
    }
  }
};
</script>

<style></style>

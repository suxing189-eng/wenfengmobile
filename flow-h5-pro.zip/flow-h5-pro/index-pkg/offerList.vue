<template>
  <view class="gray-bj-color" style="height: 100%">
    <view class="tab"></view>
    <van-search v-model="queryParams.searchValue" @search="changeSearch" :clearable="false" placeholder="请输入搜索关键词" />
    <van-panel class="cell-name" v-for="(item) in offerData" :key="item.id">
      <template #header>
        <view style="padding: 14rpx 24rpx;"><view class="text-line2">{{item.itemName}}</view></view>
      </template>
      <view style="padding: 0 24rpx;">
        <view class="text-padding text-line">{{item.standard}}</view>
        <view class="flex-between text-padding">
          <view class="">单位: {{item.itemUnit}}</view>
          <view class="">单价: {{item.itemPrice}}</view>
        </view>
      </view>
    </van-panel>
  </view>
</template>

<script>
import { offerBomList } from '@/api/index.js';
export default {
  data() {
    return {
      // 查询参数
      queryParams: {
        searchValue: ''
      },
      // 列表数据
      offerData: []
    };
  },
  onLoad() {
    this.getData();
  },
  methods: {
    // 获取列表数据
    async getData() {
      try{
        let { data } = await offerBomList(this.queryParams);
        this.offerData = data;
      }catch(e){
        //TODO handle the exception
      }
    },
    // 查询回调
    changeSearch() {
      this.getData();
    }
  }
};
</script>

<style></style>

<template>
  <view class="gray-bj-color" style="height: 100%;">
    <view class="tab"></view>
    <van-cell>
      <template #title>
        <view class="flex-between text-padding">
          <view>{{ realName }}的打卡明细，合计打卡数：{{ totalClockDays }}天</view>
          <van-button round type="info" size="mini">加班记工</van-button>
        </view>
      </template>
    </van-cell>
    <!-- 列表 -->
    <uni-table class="" border stripe emptyText="暂无更多数据">
      <!-- 表头行 -->
      <uni-tr>
        <uni-th width="100" align="center">日期</uni-th>
        <uni-th width="100" align="center">上班</uni-th>
        <uni-th width="100" align="center">下班</uni-th>
        <uni-th width="90" align="center">工日(天)</uni-th>
        <uni-th width="60" align="center">加班</uni-th>
      </uni-tr>
      <!-- 表格数据行 -->
      <uni-tr v-for="(item, index) in followData" :key="index">
        <uni-td align="center">{{ item.dateStr }}</uni-td>
        <uni-td align="center">
          <text v-if="item.amTimeRepair" @click="reissueCard('AM', item.dateStr)" class="text-blue">{{ item.amTime }}</text>
          <text v-else>{{ item.amTime }}</text>
        </uni-td>
        <uni-td align="center">
          <text v-if="item.pmTimeRepair" @click="reissueCard('PM', item.dateStr)" class="text-blue">{{ item.pmTime }}</text>
          <text v-else>{{ item.pmTime }}</text>
        </uni-td>
        <uni-td align="center">{{ item.clockDay }}</uni-td>
        <uni-td align="center">{{ item.nmTime }}</uni-td>
      </uni-tr>
    </uni-table>

    <!-- 对话框 -->
    <van-dialog v-model="show" title="补卡" @confirm="confirm" @cancel="show = false" show-cancel-button>
      <van-field
        readonly
        clickable
        name="device"
        v-model="reissueForm.deviceSn"
        label="考勤机"
        placeholder="点击选择考勤机"
        :rules="[{ required: true, message: '请选择考勤机' }]"
        @click="devicePicker = true"
      />
      <van-field class="field-item" readonly v-model="mendCard" label="补卡" placeholder="" />
    </van-dialog>
    <van-popup v-model="devicePicker" position="bottom"><van-picker show-toolbar :columns="deviceOptions" @confirm="typeConfirm" @cancel="devicePicker = false" /></van-popup>
  </view>
</template>

<script>
import { getClockRecord, repairClock } from '@/api/index.js';
export default {
  data() {
    return {
      // 工人打卡id
      dingUserId: undefined,
      projectId: undefined,
      // 打卡记录数据
      followData: [],
      realName: '',
      totalClockDays: 0,
      // 补卡对话框显示
      show: false,
      // 考勤机显示
      devicePicker: false,
      // 选择考勤机
      deviceOptions: [],
      // 补卡
      mendCard: '',
      // 表单
      reissueForm: {
        deviceSn: ''
      }
    };
  },
  onLoad(option) {
    this.dingUserId = option.id;
    this.projectId = option.projectId;
    this.getData();
  },
  methods: {
    // 获取工人打卡详情
    async getData() {
      try {
        this.deviceOptions = [];
        let { data, realName, totalClockDays, deviceList, dingUserId } = await getClockRecord({ dingUserId: this.dingUserId, projectId: this.projectId });
        this.followData = data;
        this.realName = realName;
        this.dingUserId = dingUserId;
        this.totalClockDays = totalClockDays;
        deviceList.forEach(item => {
          this.deviceOptions.push({ text: item.deviceName, value: item.clockDeviceSn });
        });
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 打开补卡对话框
    reissueCard(type, date) {
      this.reissueForm.clockDate = '';
      this.reissueForm.realName = this.realName;
      this.reissueForm.projectId = this.projectId;
      this.reissueForm.dingUserId = this.dingUserId;
      // 当考勤机只有一个的时候 默认选择
      if (this.deviceOptions.length === 1) {
        this.reissueForm.deviceSn = this.deviceOptions[0].value;
      }
      // 从列表点击补卡 自动填入是上班还是下班补卡
      if (type) {
        this.reissueForm.clockTime = type;
        this.reissueForm.clockDate = date;
      }
      // 页面显示判断
      if (type === 'AM') {
        this.mendCard = '上班卡';
      } else {
        this.mendCard = '下班卡';
      }
      this.show = true;
    },
    //选择节点
    typeConfirm(value) {
      this.reissueForm.deviceSn = value.value;
      this.devicePicker = false;
    },
    // 补卡对话框确定按钮
    async confirm() {
      try {
        let { msg } = await repairClock(this.reissueForm);
        this.Toast.success(msg);
        this.show = false;
        this.getData();
      } catch (e) {
        //TODO handle the exception
      }
    }
  }
};
</script>

<style>
.tab {
  height: 20rpx;
  background-color: #f2f2f2;
}
.text-blue {
  text-decoration: underline;
  color: #1989fa;
}
</style>

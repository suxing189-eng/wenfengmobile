<template>
  <view class="gray-bj-color" style="height: calc(100vh - 88rpx);">
    <view class="tab"></view>
    <van-dropdown-menu>
      <van-dropdown-item :title="statusText" v-model="queryParams.rosterType" :options="rosterTypeOption" @change="dropownChange"></van-dropdown-item>
    </van-dropdown-menu>
    <!-- 下拉刷新 -->
    <van-pull-refresh v-model="isLoading" @refresh="onRefresh">
      <van-search v-model="queryParams.searchValue" @search="changeSearch" :clearable="false" placeholder="请输入搜索关键词" />
      <!-- 列表 上拉加载 -->
      <van-list v-model="loading" :finished="finished" :finished-text="finishedText" @load="upwardPull">
        <view v-for="(item, index) in list" :key="item.id"><roster-view :item="item"></roster-view></view>
        <!-- 暂无数据 -->
        <van-empty v-if="list.length === 0" description="暂无数据" />
      </van-list>
    </van-pull-refresh>
    <view class="van-contact-list__bottom">
      <!-- <van-button type="primary" class="state" size="normal">{{ `总人数: ${dataCount} 人` }}</van-button> -->
      <view class="state">{{ `总人数: ${dataCount} 人` }}</view>
      <van-button type="info" icon="plus" class="share" size="normal" @click="addRoster">新增花名册人员</van-button>
    </view>
  </view>
</template>

<script>
import rosterView from './components/rosterView.vue';
import { workerRosterList } from '@/api/index.js';
export default {
  components: {
    rosterView
  },
  data() {
    return {
      // 参数
      queryParams: {
        pageNo: 0,
        pageSize: 10,
        searchValue: '',
        rosterType: -1
      },
      // 下拉状态
      loading: false,
      dataCount: 0,
      // 是否已加载完成
      finished: false,
      // 加载完成文字
      finishedText: '没有更多了',
      list: [],
      isLoading: false,
      statusText: '全部',
      rosterTypeOption: [{ value: -1, text: '全部' }, { value: 1, text: '工人' }, { value: 2, text: '供应商' }, { value: 3, text: '员工' }, { value: 4, text: '其他' }]
    };
  },
  onLoad() {
    // this.getData();
  },
  methods: {
    // 获取数据
    async getData() {
      try {
        let { data, dataCount } = await workerRosterList(this.queryParams);
        this.list = this.list.concat(data);
        this.loading = false;
        this.isLoading = false;
        this.dataCount = dataCount;
        // 判断是否已经全部加载完成
        this.allLoading(dataCount);
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 判断是否已经全部加载完成
    allLoading(dataCount) {
      if (this.queryParams.pageNo * this.queryParams.pageSize > dataCount) {
        this.finished = true;
      } else {
        this.finished = false;
      }
      if (dataCount === 0) {
        this.finishedText = '';
      } else {
        this.finishedText = '没有更多了...';
      }
    },
    // 下拉刷新
    onRefresh() {
      this.queryParams.pageNo = 1;
      this.list = [];
      this.getData();
    },
    // 查询回调
    changeSearch() {
      this.queryParams.pageNo = 1;
      this.list = [];
      this.getData();
    },
    // 上拉回调
    upwardPull() {
      this.queryParams.pageNo += 1;
      this.getData();
    },
    // 下拉回调
    dropownChange(value) {
      let state = this.rosterTypeOption.filter(item => {
        return item.value === value;
      });
      this.statusText = state[0].text;
      this.queryParams.rosterType = value;
      this.refresh();
    },
    // 刷新
    refresh() {
      this.list = [];
      this.queryParams.pageNo = 1;
      this.getData();
    },
    // 新增花名册
    addRoster() {
      uni.navigateTo({ url: '/index-pkg/addRoster' }); //业务登记
    }
  }
};
</script>
<style scoped lang="scss">
@function rpx2em($rpx) {
  @return ($rpx / 16) * 1rem;
}
::v-deep .van-list__finished-text {
  background-color: #f2f2f2 !important;
}
::v-deep .van-pull-refresh {
  height: calc(100vh - 9.18rem);
  overflow: auto;
}
.van-contact-list__bottom {
  display: flex;
  & > .state {
    width: 35%;
    line-height: rpx2em(51);
    text-align: center;
    color: #666666;
  }
  & > .share {
    flex: 1;
  }
}
::v-deep .van-contact-list__bottom {
  padding: 0;
}
::v-deep .van-button {
  border-radius: 0;
  margin: rpx2em(4);
}
</style>

<template>
  <view class="gray-bj-color" style="height: calc(100vh - 88rpx);">
    <van-tabs v-model="active" sticky offset-top="44px" @change="tabChange" title-inactive-color="#666666" title-active-color="#000">
      <van-tab title="基本信息"><business-info class="mt-10" :businessInfo="businessInfo"></business-info></van-tab>
      <van-tab title="跟进过程">
        <view class="mt-10">
          <business-follow-view :followData="followData" :businessId="id" @changeList="changeList"></business-follow-view>
        </view>
      </van-tab>
    </van-tabs>
  </view>
</template>

<script>
import businessInfo from '@/index-pkg/components/businessInfo.vue';
import businessFollowView from '@/index-pkg/components/businessFollowView.vue';
import { businessGetById, followRecordList } from '@/api/index.js';
export default {
  components: {
    businessInfo,
    businessFollowView
  },
  data() {
    return {
      // id
      id: undefined,
      active: 0,
      // 基本信息
      businessInfo: {},
      // 跟进列表
      followData: []
    };
  },
  onLoad(option) {
    this.id = option.id;
    this.getInfo();
  },
  onShow() {
    this.getFollowList();
  },
  methods: {
    // tab回调函数
    tabChange(value) {
      if (value === 0) {
        this.getInfo();
      } else {
        this.getFollowList();
      }
    },
    // 获取基本信息
    async getInfo() {
      try {
        let { data } = await businessGetById({ id: this.id });
        this.businessInfo = data;
      } catch (e) {
        //TODO handle the exception
      }
    },
    changeList() {
      this.getFollowList();
    },
    // 获取跟进列表
    async getFollowList() {
      try {
        let { data } = await followRecordList({ businessId: this.id });
        this.followData = data;
      } catch (e) {
        //TODO handle the exception
      }
    }
  }
};
</script>

<style>
.van-empty {
  padding: 40rpx 0;
}
</style>

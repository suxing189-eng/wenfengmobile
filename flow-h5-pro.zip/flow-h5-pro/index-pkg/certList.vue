<template>
  <view class="gray-bj-color" style="height: 100%;overflow: auto;">
    <!-- 下拉框 -->
    <!-- <van-dropdown-menu class="">
      <van-dropdown-item :title="statusText" v-model="queryParams.certType" :options="certOption" @change="dropdownChnage"></van-dropdown-item>
    </van-dropdown-menu> -->
    <van-grid clickable :column-num="3">
      <van-grid-item v-for="(item, index) in certOption" :class="selectIndex === index ? 'grid-orange' : ''" :key="item.value" @click="dropdownChnage(item.value, index)">
        <view class="count-text">{{ item.text }}</view>
      </van-grid-item>
    </van-grid>
    <!-- 卡片内容 -->
    <view><cert-view class="mt-5" v-for="item in certData" :key="item.id" :item="item"></cert-view></view>
  </view>
</template>

<script>
import { getTypeListCert, getListCert } from '@/api/index.js';
import certView from './components/certView.vue';
export default {
  components: {
    certView
  },
  data() {
    return {
      // 下拉框数据
      statusText: '',
      certOption: [],
      queryParams: {
        certType: ''
      },
      // 选择的节点
      selectIndex: 0,
      // 证书数据
      certData: []
    };
  },
  onLoad() {
    this.initData();
  },
  methods: {
    // 获取下拉框数据
    async initData() {
      try {
        this.certOption = [];
        let { data } = await getTypeListCert();
        this.certOption = data.map(item => ({ value: item.dictValue, text: `[${item.certCount}]${item.dictLabel}` }));
        this.statusText = this.certOption[0].text;
        this.getData();
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 获取证书数据
    async getData() {
      try {
        let { data } = await getListCert(this.queryParams);
        this.certData = data;
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 下拉框回调函数
    dropdownChnage(value, index) {
      this.selectIndex = index;
      let examine = this.certOption.filter(item => {
        return item.value === value;
      });
      this.statusText = examine[0].text;
      this.queryParams.certType = value;
      this.getData();
    }
  }
};
</script>

<style scoped lang="scss">
@function rpx2em($rpx) {
  @return ($rpx / 16) * 1rem;
}
.count-text {
  text-align: center;
  font-size: rpx2em(14);
  display: block;
  overflow: hidden;
  white-space: nowrap;
  width: 100%;
}
::v-deep .van-grid-item {
  overflow: hidden;
}
.grid-orange ::v-deep .van-grid-item__content--clickable {
  background-color: #e35f24;
  color: #fff;
}
</style>

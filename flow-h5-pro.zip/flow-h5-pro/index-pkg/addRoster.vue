<template>
  <view>
    <van-form label-align="">
      <van-field readonly clickable name="人员类型" required v-model="rosterType" label="人员类型" placeholder="请点击选择人员类型" @click="rosterTypePicker = true" />
      <van-field v-model="form.realName" name="姓名" required label="姓名" placeholder="请填写姓名" />
      <van-field readonly clickable required name="工种" v-model="workerType" label="选择工种" placeholder="请点击选择工种" @click="workerTypePicker = true" />
      <van-field v-model="form.idCardNo" required name="身份证号" label="身份证号" placeholder="请填写身份证号" />
      <van-field v-model="form.tell" type="digit" required name="手机号" label="手机号" placeholder="请填写手机号" />
      <van-field v-model="form.payeeUser" required name="收款户名" label="收款户名" placeholder="请填写收款户名" />
      <van-field v-model="form.payeeBank" required name="收款银行" label="收款银行" placeholder="请填写收款银行" />
      <van-field v-model="form.payeeAccount" type="digit" required name="收款卡号" label="收款卡号" placeholder="请输入收款卡号" />
    </van-form>
    <!-- 保存按钮 -->
    <view class="van-contact-list__bottom"><van-button color="#1989fa" round size="normal" @click="onSubmit">保存</van-button></view>

    <!-- 选择人员类型 -->
    <van-popup v-model="rosterTypePicker" position="bottom">
      <van-picker show-toolbar :columns="rosterTypeOption" @confirm="onRosterTypeConfirm" @cancel="rosterTypePicker = false" />
    </van-popup>

    <!-- 选择工种 -->
    <van-popup v-model="workerTypePicker" position="bottom">
      <van-picker show-toolbar :columns="workerTypeOption" @confirm="workerTypeConfirm" @cancel="workerTypePicker = false" />
    </van-popup>
  </view>
</template>

<script>
import { dictList, workerRosterAdd,workerRosterUpdate } from '@/api/index.js';
export default {
  data() {
    return {
      form: {
        realName: '',
        rosterType: 1,
        workerType: '',
        idCardNo: '',
        tell: '',
        payeeUser: '',
        payeeBank: '',
        payeeAccount: ''
      },
      // 人员类型显示
      rosterTypePicker: false,
      rosterType: '',
      rosterTypeOption: [{ value: 1, text: '工人' }, { value: 2, text: '供应商' }, { value: 3, text: '员工' }, { value: 4, text: '其他' }],
      // 工种显示
      workerTypePicker: false,
      workerType: '',
      workerTypeOption: []
    };
  },
  onLoad() {
    this.initData();
  },
  methods: {
    // 初始化
    async initData() {
      try {
        this.workerTypeOption = [];
        let { data } = await dictList({ dictType: 'worker_type' });
        data.forEach(item => {
          this.workerTypeOption.push({ text: item.dictLabel, value: item.dictValue });
        });
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 选择人员类型回调
    onRosterTypeConfirm(item) {
      this.rosterType = item.text;
      this.form.rosterType = item.value;
      this.rosterTypePicker = false;
    },
    // 选择工种回调
    workerTypeConfirm(item) {
      this.workerType = item.text;
      this.form.workerType = item.value;
      this.workerTypePicker = false;
    },
    // 保存数据
    async onSubmit() {
      if (!this.form.id) {
        let { msg } = await workerRosterAdd(this.form);
        this.Toast.success(msg);
        this.reset();
      } else {
        let { msg } = await workerRosterUpdate(this.form);
        this.Toast.success(msg);
        uni.navigateBack();
      }
    },
    // 重置表单
    reset() {
      this.form = {
        realName: '',
        rosterType: 1,
        workerType: '',
        idCardNo: '',
        tell: '',
        payeeUser: '',
        payeeBank: '',
        payeeAccount: ''
      };
      this.rosterType = '';
      this.workerType = '';
    },
  }
};
</script>

<style lang="scss" scoped>
.van-button--normal {
  width: 95%;
}
.van-button {
  margin: 12rpx 20rpx;
}
</style>

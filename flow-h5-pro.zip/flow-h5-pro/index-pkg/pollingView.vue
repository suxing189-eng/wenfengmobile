<template>
  <view class="gray-bj-color-44">
    <!-- tab页 -->
    <!--  <van-tabs v-model="active" sticky offset-top="44px" @change="tabChange" title-inactive-color="#666666" title-active-color="#000">
      <van-tab title="正常巡检"></van-tab>
      <van-tab title="发起整改"></van-tab>
    </van-tabs> -->
    <!-- 内容 -->
    <van-form class="">
      <van-field class="project-name" v-model="form.projectName" center readonly clearable label="巡检工程" placeholder="请选择工程">
        <template #extra>
          <van-button class="ml-5" size="small" @click="openProject" color="#e35f24">选择工程</van-button>
        </template>
      </van-field>
      <van-field
        v-model="form.trendDate"
        @click="calendarShow = true"
        name="trendDate"
        label="巡检日期"
        placeholder="请选择巡检日期"
        :rules="[{ required: true, message: '请选择巡检日期' }]"
      />
      <!-- <van-field
        readonly
        clickable
        v-if="userShow"
        name="solveUserId"
        v-model="solveUserName"
        label="整改人"
        placeholder="点击选择整改人"
        :rules="[{ required: true, message: '请选择整改人' }]"
        @click="followPicker = true"
      /> -->
      <!--  <wf-editor :trendContent.sync="form.trendContent"></wf-editor> -->
      <QuillEditor ref="quill" :value.sync="form.trendContent" height="300px" :options="editorOptions" />
      <image-picker :fileValue.sync="fileValue" labelName="巡检图片"></image-picker>
      <div style="margin: 16px;">
        <van-button round block type="info" @click="onSubmit" native-type="submit">{{ textBtn }}</van-button>
      </div>
    </van-form>

    <!-- 选择日历 -->
    <van-calendar v-model="calendarShow" :min-date="minDate" :max-date="maxDate" @confirm="dateConfirm" />
    <!-- 选择巡检人 -->
    <!-- <van-popup v-model="followPicker" position="bottom"><van-picker show-toolbar :columns="userColumns" @confirm="typeConfirm" @cancel="followPicker = false" /></van-popup> -->
    <!-- 侧边栏 -->
    <popup-project ref="popup" @selectChange="selectChange"></popup-project>
  </view>
</template>

<script>
import { ProjectUserList, projectTrendAdd, getCfg } from '@/api/index.js';
import imagePicker from '@/components/imagePicker.vue';
import QuillEditor from '@/components/quillEditor.vue';
import popupProject from '@/index-pkg/components/popupProject.vue';
export default {
  components: {
    imagePicker,
    QuillEditor,
    popupProject
  },
  data() {
    return {
      active: 0,
      // 工程id
      // projectId: 0,
      // 表单
      form: {
        trendState: 0,
        trendContent: '',
        projectName: '',
        projectId: undefined
      },
      editorOptions: {
        modules: {
          toolbar: [
            // 可以覆盖默认工具栏配置
            ['bold', 'italic'],
            ['link', 'image']
          ]
        }
      },
      // 日历显示
      calendarShow: false,
      // 整改人选择显示
      // followPicker: false,
      // 整改人显示
      // userShow: false,
      // userColumns: [],
      fileValue: [],
      // 整改人
      solveUserName: '',
      minDate: new Date(2000, 0, 1),
      maxDate: new Date(),
      trendContent: '',
      // 提交按钮文本
      textBtn: '提交我的巡检'
      // 侧边栏
      // popupShow: false
    };
  },
  onLoad(option) {
    this.form.trendDate = this.formatDate(new Date());
    // this.projectId = option.projectId;
    this.initData();
  },
  methods: {
    // tab回调函数
    // tabChange() {
    //   this.userShow = this.active === 0 ? false : true;
    //   this.form.trendState = this.active === 0 ? 0 : 1;
    //   if (this.active === 0) {
    //     setTimeout(item => {
    //       this.textBtn = '提交我的巡检';
    //       this.form.trendContent = this.trendContent;
    //       this.$refs.quill.initData();
    //     }, 100);
    //   } else {
    //     setTimeout(item => {
    //       this.textBtn = '提交整改单';
    //       this.form.trendContent = '<p style="line-height: 1;">[整改原因]</p>';
    //       this.$refs.quill.initData();
    //     }, 100);
    //   }
    // },
    // 获取字典数据
    async initData() {
      try {
        let { data: cfgData } = await getCfg({ cfgName: 'patrol_tpl' });
        this.trendContent = cfgData;
        this.form.trendContent = cfgData;
        this.$refs.quill.initData();
        // this.userColumns = [];
        // let { data } = await ProjectUserList({ projectId: this.projectId });
        // data.forEach(item => {
        //   this.userColumns.push({ text: item.userName, value: item.userId });
        // });
      } catch (e) {}
    },
    // 选择工程
    openProject() {
      this.$refs.popup.popupShow = true;
    },
    // 工程回调
    selectChange(value) {
      this.form.projectId = value.id;
      this.form.projectName = value.projectName;
    },
    // 选择日历
    formatDate(date) {
      return `${date.getFullYear()}/${date.getMonth() + 1}/${date.getDate()}`;
    },
    // 选择日期
    dateConfirm(date) {
      this.calendarShow = false;
      this.form.trendDate = this.formatDate(date);
    },
    //选择整改人
    typeConfirm(value) {
      this.form.solveUserId = value.value;
      this.solveUserName = value.text;
      this.followPicker = false;
    },
    // 表单提交按钮
    async onSubmit() {
      try {
        this.form.trendType = 3;
        // this.form.projectId = this.projectId;
        this.form.images = [];
        this.fileValue.forEach(item => {
          this.form.images.push(item.url);
        });
        this.form.images = this.form.images.join(',');
        let { msg } = await projectTrendAdd(this.form);
        this.Toast.success('操作成功');
        uni.navigateBack();
      } catch (e) {}
    }
  }
};
</script>

<style scoped lang="scss">
.project-name ::v-deep .van-field__control {
  width: 95%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
</style>

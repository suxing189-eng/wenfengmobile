<template>
  <view>
    <!-- 回款总览 -->
    <van-cell class="mt-10">
      <template #title>
        <view style="font-weight: 600;text-align: center;background-color: ;">回款总览</view>
      </template>
      <template #label>
        <view class="flex-between text-padding">
          <view class="">回款合同: {{info.totalContractMoney}}</view>
          <view class="">计划回款: {{info.totalPlanMoney}}</view>
        </view>
        <view class="flex-between text-padding">
          <view class="">实际回款: {{info.receivedMoney}}</view>
          <view class="">回款进度: {{info.progress}}</view>
        </view>
      </template>
    </van-cell>
    <!-- 合同列表 -->
    <returned-view :projectId="projectId" :returnedData="returnedData"></returned-view>
  </view>
</template>

<script>
import returnedView from '@/index-pkg/components/returnedView.vue';
import { plansList } from '@/api/index.js';
export default {
  props: {
    projectId: {}
  },
  components: {
    returnedView
  },
  data() {
    return {
      // 概览数据
      info: {
        progress: '0%',
        receivedMoney: 0,
        totalContractMoney: 0,
        totalPlanMoney: 0
      },
      // 回款数据
      returnedData: []
    };
  },
  created() {
    this.getData();
  },
  methods: {
    // 获取回款信息数据
    async getData() {
      try {
        let { data, progress, receivedMoney, totalContractMoney, totalPlanMoney } = await plansList({ projectId: this.projectId });
        this.info = {
          progress: progress,
          receivedMoney: receivedMoney,
          totalContractMoney: totalContractMoney,
          totalPlanMoney: totalPlanMoney
        };
        this.returnedData = data;
      } catch (e) {
      }
    }
  }
};
</script>

<style></style>

<template>
  <view style="overflow: auto;" class="mt-10">
    <!-- 写施工动态 -->
    <view class="">
      <van-radio-group style="margin: 20rpx 20rpx 10rpx 20rpx;" v-model="trendType" @change="radioChange" direction="horizontal">
        <van-radio :name="-1" icon-size="18px">全部</van-radio>
        <van-radio :name="1" icon-size="18px">早会</van-radio>
        <van-radio :name="2" icon-size="18px">日志</van-radio>
        <van-radio :name="3" icon-size="18px">巡检</van-radio>
        <van-radio :name="4" icon-size="18px">周计划</van-radio>
        <van-radio :name="5" icon-size="18px">乐捐单</van-radio>
      </van-radio-group>
    </view>
    <view class="van-contact-list__bottom">
      <van-button type="info" class="state" icon="plus" size="normal" @click="openSheet">写施工动态</van-button>
      <van-button type="primary" class="share" size="normal" @click="openShare">分享动态</van-button>
    </view>
    <!-- 分享面板 -->
    <van-dialog v-model="showShare" title="分享动态" class="coptBtn" :data-clipboard-text="urlText" confirmButtonText="复制" @confirm="shareConfirm" show-cancel-button>
      <view class="url-text">{{ urlText }}</view>
    </van-dialog>
    <!-- 施工动态列表 -->
    <van-cell class="cell-name" v-for="item in listData" :key="item.id">
      <template #title>
        <view class="flex-between">
          <text style="font-weight: 600;" v-if="item.trendType === 1">早会视频</text>
          <text style="font-weight: 600;" v-if="item.trendType === 2">施工日志</text>
          <text style="font-weight: 600;" v-if="item.trendType === 3">质量巡检</text>
          <text style="font-weight: 600;" v-if="item.trendType === 4">周计划</text>
          <text style="font-weight: 600;" v-if="item.trendType === 5">乐捐单</text>
          <text>{{ item.trendNode }}</text>
          <text v-if="item.trendType === 5" style="color: red;">{{ `乐捐金额: ${item.trendMoney} 元` }}</text>
          <van-icon v-if="item.trendType === 1" @click="openVideo(item)" size="26" name="play-circle-o" />
          <!-- <view v-if="item.trendType === 1" style="color: #0000ff;text-decoration: underline;" @click="openVideo(item)">播放</view> -->
        </view>
      </template>
      <template #label>
        <view v-if="item.trendType !== 1">
          <view class="text-padding" v-html="item.trendContent"></view>
          <view class="image-view">
            <view @tap="tabImage" v-for="(i, index) in item.imageThumbList" :key="index" :data-url="item.images[index]" :data-imgList="item.images" class="image-item">
              <image style="width: 100%;height: 100%;" :src="i" mode=""></image>
            </view>
          </view>
          <!-- 整改图片 （只有质量巡检才有） -->
          <view v-if="item.trendType === 3 && item.trendState !== 0 && item.trendState !== 1" class="">
            <view class="text-padding">{{ item.solveContent }}</view>
            <view class="image-view">
              <view @tap="tabImage" v-for="(i, index) in item.solveThumbList" :key="index" :data-url="item.solveImages[index]" :data-imgList="item.solveImages" class="image-item">
                <image style="width: 100%;height: 100%;" :src="i" mode=""></image>
              </view>
            </view>
          </view>
          <view class="flex-between text-padding">
            <text>{{ `${item.trendDate}【${item.createBy}】` }}</text>
            <view v-if="item.showDeleteBtn" style="color:red;" @click="delectData(item.id)">删除</view>
          </view>
        </view>
        <!-- 早会视频 -->
        <view v-else>
          <view class="video-update"><image style="width: 100%;height: 100%;" src="@/static/trendVideo.png" mode=""></image></view>
          <view class="flex-between text-padding">
            <text>{{ `${item.trendDate}【${item.createBy}】` }}</text>
            <view v-if="item.showDeleteBtn" style="color:red;" @click="delectData(item.id)">删除</view>
          </view>
        </view>
      </template>
    </van-cell>
    <view v-if="listData.length > 0" style="height: 114rpx;"></view>
    <van-empty v-else description="暂无数据" />

    <!-- 动作面板 -->
    <van-action-sheet v-model="activeShow" close-on-click-action :actions="actions" @select="onSelect" />
  </view>
</template>

<script>
import { ProjectTrendList, ProjectTrendDelete, getShareUrl } from '@/api/index.js';
import ClipboardJS from 'clipboard';
export default {
  props: {
    projectId: {}
  },
  data() {
    return {
      // 动作面板显示
      activeShow: false,
      // 下拉选项
      actions: [{ name: '施工日志' }, { name: '早会视频' }, { name: '周计划' }],
      // 数据
      listData: [],
      // 视频
      trailer: [],
      danmuList: [],
      showShare: false,
      options: [{ name: '复制链接', icon: 'link' }],
      urlText: '',
      // 施工动态
      trendType: -1
    };
  },
  mounted() {},
  created() {
    this.getData();
  },
  methods: {
    // 获取数据
    async getData() {
      try {
        let { data } = await ProjectTrendList({ trendType: this.trendType, projectId: this.projectId });
        this.listData = data;
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 单选框回调
    radioChange() {
      this.getData();
    },
    // 写施工动态按钮
    openSheet() {
      this.activeShow = true;
    },
    // 点击分享按钮
    async openShare() {
      this.showShare = true;
      let { data } = await getShareUrl({ projectId: this.projectId });
      this.urlText = data;
    },
    // 弹窗确认按钮
    shareConfirm() {
      var clipboard = new ClipboardJS('.coptBtn');
      clipboard.on('success', () => {
        this.Toast.success('复制成功');
        clipboard.destroy();
      });
      clipboard.on('error', () => {
        this.Toast.fail('复制失败');
        clipboard.destroy();
      });
    },
    // 动作面板改变回调
    onSelect(item) {
      if (item.name === '施工日志') {
        uni.navigateTo({ url: '/index-pkg/journalView?projectId=' + this.projectId });
      } else if (item.name === '周计划') {
        uni.navigateTo({ url: '/index-pkg/weekPlan?projectId=' + this.projectId });
      } else if (item.name === '早会视频') {
        uni.navigateTo({ url: '/index-pkg/meetVideo?projectId=' + this.projectId });
      } else {
        return;
      }
    },
    // 预览图片
    tabImage(e) {
      uni.previewImage({
        urls: e.currentTarget.dataset.imglist,
        current: e.currentTarget.dataset.url
      });
    },
    // 删除数据
    async delectData(id) {
      this.Dialog.confirm({
        message: '确认删除此数据吗'
      })
        .then(() => {
          ProjectTrendDelete({ id }).then(res => {
            this.Toast.success(res.msg);
            this.getData();
          });
        })
        .catch(() => {
          // on cancel
        });
    },
    // 获取视频信息
    loadedmetadata(e) {
      this.$nextTick(() => {
        this.trailer.push(e.target.id);
      });
    },
    // 控制视频播放
    play(e) {
      setTimeout(() => {
        let createId = e.target.id;
        this.trailer.forEach(id => {
          if (id != createId) uni.createVideoContext(id + '', this).pause();
        });
      }, 500);
    },
    // 播放视频
    openVideo(item) {
      uni.navigateTo({ url: '/index-pkg/trendVideo?video=' + item.trendVideo });
    }
  }
};
</script>

<style lang="scss" scoped>
.van-contact-list__bottom {
  display: flex;
  & > .state {
    width: 60%;
  }
  & > .share {
    flex: 1;
  }
}
.van-button--normal {
  /* width: 95%; */
}
.van-button {
  margin: 0rpx;
}
.image-view {
  display: flex;
  flex-wrap: wrap;
  .image-item {
    width: 32%;
    height: 230rpx;
    margin: 4rpx;
  }
}
.van-empty {
  padding: 40rpx 0;
}
.video-update {
  width: 100%;
  height: 280rpx;
  display: flex;
  justify-content: center;
  flex-direction: column;
}
::v-deep .van-button {
  border-radius: 0;
  margin: 8rpx;
}
::v-deep .van-contact-list__bottom {
  padding: 0;
}
.url-text {
  margin: 14rpx;
  color: #666666;
  word-wrap: break-word;
}
::v-deep .van-radio--horizontal {
  margin-right: 12rpx;
}
::v-deep .van-radio__label {
  margin-left: 8rpx;
  text-wrap: nowrap;
}
::v-deep .van-radio-group--horizontal {
  flex-wrap: nowrap;
  overflow: auto;
  margin: 0 !important;
  padding: 16rpx 12rpx !important;
}

::v-deep .van-radio {
  overflow: initial;
}
</style>

<template>
  <view>
    <!-- 文档目录 -->
    <van-tree-select class="mt-5" height="" :items="treeData" :main-active-index.sync="active">
      <template #content>
        <view class="content">
          <van-cell v-for="item in treeData[active] && treeData[active].children" :key="item.id" :title="item.displayName" @click="selectFile(item.id)" is-link>
            <template #right-icon>
              <text class="right-text">{{ `${item.fileCount}` }}</text>
              <van-icon name="arrow" class="arrow" size="14px" color="#969799" />
            </template>
          </van-cell>
        </view>
      </template>
    </van-tree-select>
    <!-- 文档 -->
    <view class="mt-5 view-box" v-if="fileData.length > 0">
      <view class="view-item" v-for="(item, index) in fileData" :key="item.id">
        <view class="dflex">
          <view class="box-left"><image class="left-image" src="../../static/file.png" /></view>
          <view class="box-right">
            <view class="text-name">{{ item.fileName }}</view>
            <view class="text-content">
              <text>{{ `上传人： ${item.createBy} 上传时间：${item.createTime}` }}</text>
            </view>
          </view>
        </view>
        <view class="van-contact mt-5">
          <van-button class="check mr-5" type="default" size="small">预览</van-button>
          <van-button class="download" type="default" size="small" @click="downLoad">下载</van-button>
        </view>
        <van-divider v-if="index !== fileData.length - 1" />
      </view>
    </view>
  </view>
</template>

<script>
import { projectFolder, getListFile } from '@/api/index.js';
export default {
  props: {
    projectId: {}
  },
  data() {
    return {
      active: 0,
      treeData: [],
      // 文件数据
      fileData: []
    };
  },
  created() {
    this.initData();
  },
  methods: {
    // 获取侧边栏数据
    async initData() {
      try {
        let { data } = await projectFolder({ projectId: this.projectId });
        this.treeData = data.map(item => {
          return {
            ...item,
            text: item.displayName
          };
        });
      } catch (e) {}
    },
    // 获取文件数据
    async selectFile(id) {
      let { data } = await getListFile({ folderId: id, projectId: this.projectId });
      this.fileData = data;
    },
    // 下载文件
    downLoad() {}
  }
};
</script>

<style lang="scss" scoped>
@function rpx2em($rpx) {
  @return ($rpx / 16) * 1rem;
}
::v-deep .van-tree-select__content {
  max-height: rpx2em(300);
}

::v-deep .van-sidebar-item__text {
  width: rpx2em(114);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.arrow {
  line-height: rpx2em(24);
}

.right-text {
  font-size: rpx2em(11);
  color: #969799;
}

// 底部文件
.view-box {
  background-color: #fff;
  padding: rpx2em(8);
  .view-item {
    .box-left {
      flex: 0 0 rpx2em(40);
      padding-right: rpx2em(6);
      width: rpx2em(40);
      height: rpx2em(40);
      .left-image {
        width: 100%;
        height: 100%;
      }
    }
    .box-right {
      flex: 1;
      .text-name {
        font-weight: 600;
        font-size: rpx2em(16);
        width: 65%;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .text-content {
        color: #969799;
        font-size: rpx2em(14);
      }
    }
  }
}
// 按钮
.van-contact {
  display: flex;
  justify-content: space-between;
  .check {
    flex: 0 0 50%;
  }
  .download {
    flex: 0 0 50%;
  }
}

@media (min-width: 768px) {
  ::v-deep .van-tree-select__content {
    max-height: rpx2em(300);
  }
  ::v-deep .van-tree-select__nav-item {
    padding: rpx2em(16) rpx2em(10);
  }
  .content ::v-deep .van-cell {
    padding: rpx2em(12);
  }
  .arrow {
    font-size: rpx2em(16) !important;
    line-height: rpx2em(19);
  }
  .right-text {
    font-size: rpx2em(14);
  }
  ::v-deep .van-sidebar-item__text {
    width: rpx2em(160);
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .box-right {
    .text-name {
      width: 92% !important;
    }
  }
}
</style>

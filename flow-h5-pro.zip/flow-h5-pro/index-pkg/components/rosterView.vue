<template>
  <view class="view-cell" style="overflow: auto;">
    <van-cell>
      <template #title>
        <view class="flex-between">
          <text style="font-weight: 600;width: 450rpx;overflow:hidden; text-overflow:ellipsis;white-space: nowrap;">{{ item.realName }}</text>
          <view>{{ item.rosterTypeText }}</view>
        </view>
      </template>
      <template #label>
        <view class="text-padding">收款人: {{ item.payeeUser }}</view>
        <view class="text-padding">卡号: {{ item.payeeAccount }}</view>
        <view class="text-padding">收款银行: {{ item.payeeBank }}</view>
      </template>
    </van-cell>
  </view>
</template>

<script>
export default {
  props: {
    item: {}
  },
  data() {
    return {};
  },
  created() {},
  methods: {}
};
</script>

<style scoped lang="less">
.view-cell ::v-deep .van-cell {
  border-bottom: 3rpx solid #f2f2f2;
  padding: 4rpx 30rpx;
}
</style>

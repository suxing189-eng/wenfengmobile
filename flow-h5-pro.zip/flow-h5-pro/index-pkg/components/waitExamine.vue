<template>
  <view class="mt-5 white-bg-color">
    <!-- 待我审批 -->
    <view class="header-title">
      待我审批
      <text style="margin-left: 5px;">(下拉可以刷新待我审批数量)</text>
    </view>
    <van-grid clickable :column-num="4">
      <van-grid-item v-for="item in examineData" :key="item.bizCode" @click="tabDetail(item.bizCode)">
        <view>
          <view class="count-text">{{ item.count }}</view>
          <view class="content-text">{{ item.bizName }}</view>
        </view>
      </van-grid-item>
    </van-grid>
    <view class="no-data" v-if="examineData.length === 0">暂无审批数据</view>
  </view>
</template>

<script>
import { todoCount } from '@/api/wait.js';
import { mapState } from 'vuex';
export default {
  props: {
    isLoading: {}
  },
  data() {
    return {
      // 审批数据
      examineData: []
    };
  },
  onLoad() {},
  created() {
    this.getExamine();
  },
  computed: {
    ...mapState('user', ['perList'])
  },
  methods: {
    // 获取数据
    async getExamine() {
      try {
        let { data } = await todoCount({
          bizCodeList: 'EX-ADD-CUSTOMER,EX-ADD-SUPPLIER,EX-ADD-PROJECT,EX-PROJECT-APPLY,EX-PROJECT-ORDER,EX-PROJECT-COMMISSION,EX-PROJECT-STATEMENT,EX-MANAGE-COST'
        });
        this.$emit('update:isLoading', false);
        let dataList = data;
        if (!this.perList.includes('examine:order:app')) {
          dataList = dataList.filter(item => item.bizCode !== 'EX-PROJECT-ORDER');
        }
        this.examineData = dataList.filter(item => {
          return item.count > 0;
        });
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 进入宫格详情
    tabDetail(value) {
      if (value === 'EX-ADD-CUSTOMER') {
        // 客户
        uni.navigateTo({ url: '/wait-pkg/customerExamine' });
      } else if (value === 'EX-ADD-SUPPLIER') {
        // 供应商
        uni.navigateTo({ url: '/wait-pkg/supplierExamine' });
      } else if (value === 'EX-ADD-PROJECT') {
        // 通知签单
        uni.navigateTo({ url: '/wait-pkg/projectEaxmine' });
      } else if (value === 'EX-PROJECT-APPLY') {
        // 工程请款
        uni.navigateTo({ url: '/wait-pkg/projectApplyExamine' });
      } else if (value === 'EX-PROJECT-ORDER') {
        // 材料单
        uni.navigateTo({ url: '/wait-pkg/projectOrderExamine' });
      } else if (value === 'EX-PROJECT-COMMISSION') {
        // 提成支付
        uni.navigateTo({ url: '/wait-pkg/commissionExamine' });
      } else if (value === 'EX-PROJECT-STATEMENT') {
        // 结算单
        uni.navigateTo({ url: '/wait-pkg/statementExamine' });
      } else if (value === 'EX-MANAGE-COST') {
        // 经营成本
        uni.navigateTo({ url: '/wait-pkg/costExamine' });
      } else if (value === 'EX-OA-APPROVAL') {
        // 行政审批
        uni.navigateTo({ url: '/wait-pkg/oaExamine' });
      } else if (value === 'EX-CHANGE-LIST') {
        // 变更清单
        uni.navigateTo({ url: '/wait-pkg/changeExamine' });
      } else {
        return;
      }
    }
  }
};
</script>

<style scoped lang="scss">
@function rpx2em($rpx) {
  @return ($rpx / 16) * 1rem;
}
.header-title {
  padding: rpx2em(10);
  font-size: 0.8em;
  color: #000;
  font-weight: bolder;
}
.content-text {
  color: #646566;
  text-align: center;
  font-size: rpx2em(14);
  margin-top: rpx2em(8);
}

.count-text {
  color: #646566;
  text-align: center;
  font-size: rpx2em(16);
  font-weight: bold;
}

::v-deep .van-grid-item__content {
  padding: rpx2em(8);
}
.no-data {
  height: rpx2em(38);
  line-height: rpx2em(38);
  text-align: center;
  color: #646566;
  font-size: rpx2em(12);
}
</style>

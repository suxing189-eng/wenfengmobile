<template>
  <view class="mt-5 white-bg-color">
    <!-- 项目经理 -->

    <view v-if="projectInfo.showCard !== 0 && projectInfo.cardType === 1" class="" style="background-color: #fff;">
      <view class="header-title">我的巡检</view>
      <van-panel class="">
        <template #header>
          <view class="header">
            <view class="flex-between">
              <view class="" style="color: red;">{{ `${projectInfo.waitUpgradeCount}个待整改` }}</view>
              <view v-if="projectInfo.orderStatus === '1'" style="color: #00cc00;">可接小单</view>
              <view v-if="projectInfo.orderStatus === '0'" style="color: red;">不可接单</view>
              <view v-if="projectInfo.orderStatus === '2'" style="color: #00cc00;">可接单</view>
            </view>
            <view class="flex-between text-header">
              <view class="" style="color: #666666;">{{ projectInfo.starLevel }}</view>
              <view class="" style="color: #666666;">{{ projectInfo.socialStatus }}</view>
              <view v-if="projectInfo.signStatus === '1'" style="color: #00cc00;">已签约</view>
              <view v-if="projectInfo.signStatus === '0'" style="color: red;">未签约</view>
            </view>
          </view>
        </template>
        <view class="content-box">
          <view class="flex-between text-center">
            <view class="flex-between flex-width-left">
              <view>在建工程数</view>
              <view>{{ `${projectInfo.buildingProjectCount}个` }}</view>
            </view>
            <view class="flex-between flex-width-right">
              <view class="">应收进度款</view>
              <view>{{ projectInfo.totalRemainBackMoney }}</view>
            </view>
          </view>
          <view class="flex-between text-center">
            <view class="flex-between flex-width-left">
              <view>验收单未回</view>
              <view>{{ `${projectInfo.waitingDoneWorkImageCount}个` }}</view>
            </view>
            <view class="flex-between flex-width-right">
              <view class="">物业押金</view>
              <view>{{ projectInfo.totalDepositMoney }}</view>
            </view>
          </view>
          <view class="flex-between text-center">
            <view class="flex-between flex-width-left">
              <view>今年接单数</view>
              <view>{{ `${projectInfo.yearProjectCount || 0}个` }}</view>
            </view>
            <view class="flex-between flex-width-right">
              <view class="">今年接单总额</view>
              <view>{{ projectInfo.yearProjectMoney }}</view>
            </view>
          </view>
          <view class="flex-between text-center">
            <view class="flex-between flex-width-left">
              <view>质量保证金</view>
              <view>{{ projectInfo.bondMoney }}</view>
            </view>
            <view class="flex-between flex-width-right">
              <view class="">累计接单总额</view>
              <view>{{ projectInfo.totalProjectMoney }}</view>
            </view>
          </view>
        </view>
      </van-panel>
    </view>
    <!-- 工程经理 -->
    <view v-if="projectInfo.showCard !== 0 && projectInfo.cardType === 2" class="" style="background-color: #fff;">
      <view class="header-title">我的巡检</view>
      <van-panel class="">
        <template #header>
          <view class="header">
            <view class="flex-between text-header" style="color: #666">
              <view class="">
                本月巡检:
                <text>{{ `${projectInfo.patrolCount}次` }}</text>
              </view>
              <view class="">
                发起整改:
                <text>{{ `${projectInfo.upgradeCount}次` }}</text>
              </view>
              <view class="">
                待我验证:
                <text>{{ `${projectInfo.waitCloseCount}次` }}</text>
              </view>
            </view>
          </view>
        </template>
        <view class="content-box">
          <view class="flex-between text-center">
            <view class="flex-between flex-width-left">
              <view>在建工程数</view>
              <view>{{ `${projectInfo.buildingProjectCount}个` }}</view>
            </view>
            <view class="flex-between flex-width-right">
              <view class="">应收进度款</view>
              <view>{{ projectInfo.totalRemainBackMoney }}</view>
            </view>
          </view>
          <view class="flex-between text-center">
            <view class="flex-between flex-width-left">
              <view>验收单未回</view>
              <view>{{ `${projectInfo.waitingDoneWorkImageCount}个` }}</view>
            </view>
            <view class="flex-between flex-width-right">
              <view class="">物业押金</view>
              <view>{{ projectInfo.totalDepositMoney }}</view>
            </view>
          </view>
        </view>
      </van-panel>
    </view>
  </view>
</template>

<script>
import { cardInfo } from '@/api/login.js';
export default {
  data() {
    return {
      // 项目经理用户信息
      projectInfo: {
        showCard: 0
      }
    };
  },
  created() {
    this.initData();
  },
  methods: {
    async initData() {
      let { data } = await cardInfo();
      this.projectInfo = data;
    }
  }
};
</script>

<style scoped lang="scss">
@function rpx2em($rpx) {
  @return ($rpx / 16) * 1rem;
}
::v-deep .van-button--normal {
  width: 100%;
}
.header-title {
  padding: rpx2em(10);
  font-size: 0.8em;
  color: #000;
  font-weight: bolder;
}
.header {
  padding: rpx2em(9) rpx2em(12) rpx2em(0) rpx2em(12);
}
.text-header {
  font-size: rpx2em(12);
}

.content-box {
  padding: rpx2em(8);
  color: #000000;
}

.name-text {
  font-weight: 600;
  font-size: rpx2em(16);
  margin-right: rpx2em(10);
}

.text-center {
  padding: rpx2em(8) 0;
  font-size: rpx2em(12);
}
.flex-width-left {
  flex: 0 0 calc(50% - 1rem);
  margin: 0 8rpx;
  padding: 8rpx;
  background-color: #eeeeee;
}
.flex-width-right {
  flex: 0 0 calc(50% - 1rem);
  margin: 0 rpx2em(4);
  padding: rpx2em(4);
  line-height: rpx2em(20);

  background-color: #eeeeee;
}
.text-center {
  padding: rpx2em(4) rpx2em(0);
}
</style>

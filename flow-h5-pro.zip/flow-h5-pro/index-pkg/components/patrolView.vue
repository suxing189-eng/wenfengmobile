<template>
  <view class="">
    <van-cell v-for="item in trendData" :key="item.id">
      <template #title>
        <view class="project-title">{{ item.projectName }}</view>
        <view class="text-padding">{{ item.solveUserName }}</view>
        <view class="">
          <text>{{ item.trendNode }}</text>
        </view>
      </template>
      <template #label>
        <view>
          <view class="text-padding" v-if="item.remark" style="color: red;">{{ item.remark }}</view>
          <view class="text-padding" v-html="item.trendContent"></view>
          <view class="image-view">
            <view @tap="tabImage" v-for="(i, index) in item.imageThumbList" :key="index" :data-url="item.images[index]" :data-imgList="item.images" class="image-item">
              <image style="width: 100%;height: 100%;" :src="i" mode=""></image>
            </view>
          </view>
          <!-- 整改图片 -->
          <view class="">
            <view class="text-padding" v-html="item.solveContent"></view>
            <view class="image-view">
              <view @tap="tabImage" v-for="(i, index) in item.solveThumbList" :key="index" :data-url="item.solveImages[index]" :data-imgList="item.solveImages" class="image-item">
                <image style="width: 100%;height: 100%;" :src="i" mode=""></image>
              </view>
            </view>
          </view>
          <view class="flex-between text-padding">
            <text>{{ `${util.dateFormat('yyyy-mm-dd', new Date(item.trendDate))}【${item.createBy}】` }}</text>
            <text class="text-patrol" @click="openPatrol(item.id)" v-if="item.showSolveBtn && type !== 'sponsor'">去整改</text>
            <text style="color: #00CC00;" @click="submit(item.id)" v-if="item.showCloseBtn && type !== 'sponsor'">提交验证</text>
          </view>
        </view>
      </template>
    </van-cell>
    <!-- <view style="height: 92rpx;width: 100%;"></view> -->
    <van-empty v-if="trendData.length === 0" description="暂无数据" />

    <!-- 弹出验证 -->
    <van-dialog
      v-model="trendShow"
      title="请输入不合格的说明"
      @confirm="confirm"
      @cancel="cancel"
      confirmButtonText="合格"
      confirmButtonColor="#07c160"
      cancelButtonText="不合格"
      cancelButtonColor="#ee0a24"
      show-cancel-button
      close-on-click-overlay
    >
      <van-field v-model="remark" rows="5" autosize label="说明" type="textarea" placeholder="请输入说明" />
      <!-- <van-radio-group class="trend-radio" v-model="trendState">
        <van-radio :name="1">整改已完成</van-radio>
        <van-radio :name="0">整改不合格</van-radio>
      </van-radio-group> -->
    </van-dialog>
  </view>
</template>

<script>
import { trendSlose } from '@/api/trend.js';
export default {
  props: {
    trendData: {
      type: Array,
      default: () => {
        return [];
      }
    },
    type: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      // 整改单id
      trendId: undefined,
      // 验证提交对话框显示
      trendShow: false,
      trendState: 1,
      remark: ''
    };
  },
  methods: {
    // 预览图片
    tabImage(e) {
      uni.previewImage({
        urls: e.currentTarget.dataset.imglist,
        current: e.currentTarget.dataset.url
      });
    },
    // 去整改
    openPatrol(id) {
      uni.navigateTo({ url: '/index-pkg/amendProject?id=' + id });
    },
    // 整改已确认
    async submit(id) {
      try {
        this.trendId = id;
        this.remark = '';
        this.trendShow = true;
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 确认按钮
    async confirm() {
      try {
        let { msg } = await trendSlose({ id: this.trendId, trendState: 1 });
        this.Toast.success(res.msg);
        this.$emit('initData');
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 取消按钮
    async cancel() {
      let { msg } = await trendSlose({ id: this.trendId, trendState: 0, remark: this.remark });
      this.Toast.success(res.msg);
      this.$emit('initData');
    }
  }
};
</script>

<style scoped lang="scss">
@function rpx2em($rpx) {
  @return ($rpx / 16) * 1rem;
}
.image-view {
  display: flex;
  flex-wrap: wrap;
  .image-item {
    width: 32%;
    height: 230rpx;
    margin: 4rpx;
  }
}
.van-empty {
  padding: rpx2em(40) 0;
}
.text-patrol {
  color: red;
}
.trend-radio {
  margin: rpx2em(10) rpx2em(16);
}
::v-deep .van-radio {
  padding: rpx2em(12) 0;
}
</style>

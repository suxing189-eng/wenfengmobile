<template>
  <view style="overflow: auto;" class="mt-10">
    <van-cell class="cell-name" v-for="item in returnedData" :key="item.id">
      <template #title>
        <view class="flex-between">
          <text class="text-nowrap" style="font-weight: 600;width: 490rpx;">{{ item.contractName }}</text>
          <view>
            <text style="font-weight: 600;">{{ `${item.planNo}期 ` }}</text>
            <text v-if="item.planStatus === 0">(未到期)</text>
            <text v-if="item.planStatus === 1" style="color:#39d67f;">(已回款)</text>
            <text v-if="item.planStatus === 2" style="color: red;"> (逾期中)</text>
          </view>
        </view>
      </template>
      <template #label>
        <view class="flex-between text-padding">
          <view class="">{{ item.planType | planTypeFilter }}[{{item.planDate}}]</view>
          <view class="">应回金额: {{ item.planMoney }}</view>
        </view>
        <view class="flex-between text-padding">
          <view style="width: 500rpx;" class="">回款节点: {{ item.planNode }}</view>
          <view class="">实回金额: {{ item.realBackMoney }}</view>
        </view>
        <view class="text-padding">{{ item.remark }}</view>
      </template>
    </van-cell>
    <van-empty v-if="returnedData.length === 0" description="暂无数据" />
  </view>
</template>

<script>
export default {
  props: {
    projectId: {},
    returnedData: {}
  },
  data() {
    return {
      // 合同详情
      info: {}
    };
  },
  filters: {
    planTypeFilter(value) {
      let values = {
        1: '进度回款',
        2: '竣工验收回款',
        3: '质保金回款'
      };
      return values[value];
    }
  },
  methods: {}
};
</script>

<style scoped lang="less">
.van-empty {
  padding: 40rpx 0;
}
</style>

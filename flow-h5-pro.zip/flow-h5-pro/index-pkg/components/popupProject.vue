<template>
  <!-- 右侧弹出筛选 -->
  <van-popup v-model="popupShow" :overlay-style="{ zIndex: '9999' }" v-if="popupShow" position="right" :close-on-click-overlay="false" @click-overlay="handleClose">
    <view class="popup-box">
      <view style="height: calc(100% - 3rem);overflow: scroll;">
        <!-- 工程 -->
        <van-search v-model="searchValue" show-action @search="changeSearch" :clearable="false" placeholder="请输入搜索关键词">
          <template #action>
            <div @click="changeSearch">搜索</div>
          </template>
        </van-search>
        <van-cell
          class="cell-name"
          @click="selectProject(index, item)"
          :class="selectIndex === index ? 'click-background' : ''"
          v-for="(item, index) in projectData"
          :key="item.id"
          title=""
        >
          <template #label>
            <view class="name-box">
              <van-tag class="mr-5" style="white-space: nowrap;" type="primary">{{ item.projectLabel }}</van-tag>
              <van-tag class="mr-5" style="white-space: nowrap;" type="primary">{{ item.dutyUserName }}</van-tag>
              <view class="item-project-name">{{ item.projectName }}</view>
            </view>
          </template>
        </van-cell>
      </view>
      <!-- 按钮 -->
      <view class="van-contact-list__bottom">
        <van-button type="default" class="state" size="normal" @click="popupShow = false">关闭</van-button>
        <van-button type="info" class="share" size="normal" @click="handle">确定</van-button>
      </view>
    </view>
  </van-popup>
</template>

<script>
import { chooseProject } from '@/api/index.js';
export default {
  props: {
    // popupShow: {
    //   type: Boolean,
    //   default: false
    // }
  },
  components: {},
  data() {
    return {
      popupShow: false,
      // 选择的工程
      selectIndex: undefined,
      // 工程数据
      projectData: [],
      // 选择的数据
      currentRow: {},
      searchValue: ''
    };
  },
  created() {
    this.getData();
  },
  methods: {
    // 获取工程数据
    async getData() {
      try {
        let { data } = await chooseProject({ searchValue: this.searchValue, projectType: 1, closeState: 0, dataScope: 1, pageNo: 1, pageSize: 500 });
        this.projectData = data;
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 查询
    changeSearch() {
      this.selectIndex = undefined;
      this.currentRow = {};
      this.getData();
    },
    // 选择的工程
    selectProject(index, row) {
      this.selectIndex = index;
      this.currentRow = row;
    },
    // 确认工程
    handle() {
      if (this.selectIndex === undefined) {
        this.Toast.fail('请先选择工程再点确定！');
        return;
      }
      this.$emit('selectChange', this.currentRow);
      this.popupShow = false;
    },
    // 关闭侧边栏回调
    handleClose() {
      this.popupShow = false;
    }
  }
};
</script>

<style scoped lang="scss">
@function rpx2em($rpx) {
  @return ($rpx / 16) * 1rem;
}

.popup-box {
  width: calc(100vw - 2.5rem);
  height: 100vh;
  background: #f2f2f2;
  // overflow: scroll;
}
::v-deep .van-contact-list__bottom {
  padding: 0;
}
.name-box {
  display: flex;
  width: 91vw;
  .item-project-name {
    flex: 1; /* 占据剩余空间 */
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    min-width: 0;
    color: #000;
  }
}
.van-contact-list__bottom {
  display: flex;
  & > .state {
    flex: 0 0 20%;
  }
  & > .share {
    flex: 1;
  }
}
.popup-box ::v-deep .van-cell {
  padding: rpx2em(10) rpx2em(5);
}
.click-background {
  background-color: #e35f24;
}
::v-deep .van-popup__close-icon {
  color: #000;
}
.van-search {
  padding: rpx2em(5) rpx2em(12);
}
.van-popup--right {
  z-index: 9999 !important;
}
</style>

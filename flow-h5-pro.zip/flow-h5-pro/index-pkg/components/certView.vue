<template>
  <view>
    <van-cell class="cell-name">
      <template #title></template>
      <template #label>
        <view class="text-padding">
          <view class="">类型：{{ item.certType }}</view>
        </view>
        <view class="text-padding">
          <view class="">名称：{{ item.certName }}</view>
        </view>
        <view class="text-padding">
          <view class="">签发机构：{{ item.issueName }}</view>
        </view>
        <view class="text-padding">
          <view class="">持有人：{{ item.ownerName }}</view>
        </view>
      </template>
    </van-cell>
  </view>
</template>

<script>
export default {
  props: {
    item: {}
  },
  data() {
    return {};
  }
};
</script>

<style></style>

<template>
  <view>
    <van-cell style="margin-bottom: 10rpx;">
      <template #title>
        <div>
          <view class="text-padding" style="font-weight: 600;color: #323233;">{{ item.contractName }}</view>
          <view class="flex-between text-padding">
            <view>合同金额:{{ item.contractMoney }} 元</view>
            <view>计划付款:{{ item.totalPlanPayMoney }} 元</view>
          </view>
          <view class="flex-between text-padding">
            <view>合同税金: {{ item.taxesMoney }} 元</view>
            <view>已付金额:{{ item.totalPayMoney }} 元</view>
          </view>
          <view class="text-padding">{{ item.remark }}</view>
        </div>
      </template>
    </van-cell>
  </view>
</template>

<script>
import { contractsDetail } from '@/api/index.js';
export default {
  props: {
    item: {}
  },
  data() {
    return {};
  },
  onLoad(option) {},
  methods: {}
};
</script>

<style scoped lang="scss"></style>

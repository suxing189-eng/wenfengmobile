<template>
  <view style="overflow: auto;" class="mt-10">
    <van-cell class="cell-name" v-for="item in contractData" :key="item.id">
      <template #title>
        <view class="flex-between">
          <text style="font-weight: 600;width: 560rpx;">{{ item.contractName }}</text>
          <view>{{ item.contractType }}</view>
        </view>
      </template>
      <template #label>
        <view class="flex-between text-padding">
          <view class="">合同总额: {{ item.contractMoney }}</view>
          <view class="">合同税金: {{ item.taxesMoney }}</view>
        </view>
        <view class="flex-between text-padding">
          <view class="">签订日期: {{ item.contractDate }}</view>
          <view class="">
            纸质合同:
            <text v-if="item.contractState === 1">已签回</text>
            <text v-else>未签回</text>
          </view>
        </view>
      </template>
    </van-cell>
    <van-empty v-if="contractData.length === 0" description="暂无数据" />
  </view>
</template>

<script>
export default {
  props: {
    contractData: {}
  },
  data() {
    return {
      // 合同详情
      info: {}
    };
  },
  methods: {}
};
</script>

<style scoped lang="less">
.van-empty {
  padding: 40rpx 0;
}
</style>

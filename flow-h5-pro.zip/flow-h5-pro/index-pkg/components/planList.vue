<template>
  <van-panel class="cell-name">
    <template #header>
      <view class="header" @click="openProject(item)">{{ item.projectName }}</view>
    </template>
    <view class="content-box">
      <view class="flex-between text-padding">
        <!-- <view>计划回款: {{ item.planMoney }}</view> -->
        <view>{{ `第${item.planNo}期` }}</view>
        <view>{{ `应回日期：${item.planDate}` }}</view>
        <view>{{ item.planTypeName }}</view>
      </view>
      <view class="flex-between text-padding">
        <view>
          <view class="pb-7">应回金额</view>
          <view>{{ item.planMoney }}</view>
        </view>
        <view>
          <view class="pb-7">实回金额</view>
          <view>{{ item.realBackMoney }}</view>
        </view>
        <view>
          <view class="pb-7">到期未回</view>
          <view style="color: red;font-weight: 600;">{{ item.remainBackMoney }}</view>
        </view>
      </view>
    </view>
  </van-panel>
</template>

<script>
export default {
  props: {
    item: {}
  },
  data() {
    return {
      // 跳转工程详情
      openProject(item) {
        uni.navigateTo({ url: '/index-pkg/projectDetail?id=' + item.projectId });
      }
    };
  }
};
</script>

<style scoped lang="scss">
@function rpx2em($rpx) {
  @return ($rpx / 16) * 1rem;
}
.header {
  font-weight: 600;
  color: #0000ff;
  text-decoration: underline;
  /* padding: 18rpx 32rpx; */
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.pb-7 {
  padding-bottom: rpx2em(7);
}
</style>

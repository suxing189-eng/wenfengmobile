<template>
  <view>
    <!-- 列表内容 -->
    <van-panel class="" @click="openDetail(item.id)">
      <template #header>
        <view class="header">
          <text style="font-weight: 600;width: 380rpx;">{{ item.eventName }}</text>
          <text>{{ item.createTime }}</text>
        </view>
      </template>
      <view style="padding: 0 32rpx 14rpx 32rpx;">
        <view class="flex-between text-padding">
          <view class="">{{ item.msgTitle }}</view>
          <view>
            <text v-if="!item.msgState">未读</text>
            <text v-else>已读</text>
          </view>
        </view>
      </view>
    </van-panel>
  </view>
</template>

<script>
export default {
  props: {
    item: {}
  },
  data() {
    return {};
  },
  methods: {
    // 进入详情页面
    openDetail(id) {
      uni.navigateTo({ url: '/wait-pkg/messageDetail?id=' + id });
    }
  }
};
</script>

<style scoped lang="less">
.header {
  // padding: 18rpx 32rpx;
  display: flex;
  justify-content: space-between;
}
</style>

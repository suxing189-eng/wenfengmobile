<template>
  <view>
    <!-- 列表内容 -->
    <van-panel class="cell-name" v-for="(item, index) in list" :key="item.id" @click="openDetail(item.id)">
      <template #header>
        <view class="header">
          <view class="text-nowrap">
            <van-tag type="primary" class="mr-5" style="display: inline;">{{ item.deptName }}</van-tag>
            <view style="display: inline;font-weight: 600;" v-html="item.projectName"></view>
          </view>
          <view class="flex-between mt-5">
            <view>
              <van-tag type="primary" class="mr-5" style="display: inline;">{{ item.projectLabel }}</van-tag>
              <van-tag v-if="item.explainState" type="success" class="mr-5">已交底</van-tag>
              <van-tag v-else color="#e5e5e5" class="mr-5">未交底</van-tag>
              <van-tag v-if="item.doneWorkState" type="success" class="mr-5">已完工</van-tag>
              <van-tag v-else color="#e5e5e5" class="mr-5">未完工</van-tag>
              <van-tag v-if="item.closeState" type="success" class="mr-5">已关单</van-tag>
              <van-tag v-else color="#e5e5e5" class="mr-5">未关单</van-tag>
              <van-tag v-if="item.statement" type="success" class="mr-5">已结算</van-tag>
              <van-tag v-else color="#e5e5e5" class="mr-5">未结算</van-tag>
            </view>
            <view>
              <text v-if="item.projectState === 0" class="text-info">待开工</text>
              <text v-if="item.projectState === 1" class="primary">施工中</text>
              <text v-if="item.projectState === 2" class="warning">待验收</text>
              <text v-if="item.projectState === 3" class="warning">整改中</text>
              <text v-if="item.projectState === 4" class="success">已完工</text>
              <text v-if="item.projectState === 5" class="danger">停工中</text>
            </view>
          </view>
        </view>
      </template>
      <view class="content-box">
        <view class="flex-between text-padding">
          <view class="">项目经理: {{ item.dutyUserName }}</view>
          <view class="">合同总额: {{ item.contractMoney }} 元</view>
        </view>
        <view class="text-padding text-nowrap">工程地址: {{ item.address }}</view>
      </view>
    </van-panel>
    <!-- 暂无数据 -->
    <van-empty v-if="list.length === 0" description="暂无数据" />
  </view>
</template>

<script>
export default {
  props: {
    list: {}
  },
  data() {
    return {};
  },
  methods: {
    // 跳转工程详情页面
    openDetail(id) {
      uni.navigateTo({ url: '/index-pkg/projectDetail?id=' + id });
    }
  }
};
</script>

<style scoped lang="scss">
@function rpx2em($rpx) {
  @return ($rpx / 16) * 1rem;
}
.header {
  padding: rpx2em(8) rpx2em(16);
  font-size: rpx2em(18);
}
.content-box {
  padding: rpx2em(0) rpx2em(16);
}
.text-nowrap {
  width: 95%;
  overflow: hidden;
}
.text-info {
  color: #666666;
}
.text-green {
  color: #07c160;
}
::v-deep .van-tag {
  padding: rpx2em(2) rpx2em(6);
}
</style>

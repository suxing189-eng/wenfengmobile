<template>
  <view>
    <!-- 列表内容 -->
    <van-panel class="cell-name" @click="openDetail">
      <template #header>
        <view class="header">
          <text style="font-weight: 600;width: 520rpx;">{{ item.supplierName }}</text>
          <text :class="item.examineState === -1 ? 'info-color' : item.examineState === 1 ? 'green-color' : item.examineState === 0 ? 'color-blue' : 'color-red'">
            {{ item.stateText }}
          </text>
        </view>
      </template>
      <view style="padding: 0 32rpx;">
        <view class="flex-between text-padding">
          <view>供应商类别: {{ item.supplierType | typeFilter }}</view>
          <view>
            <van-tag type="success" size="medium" v-if="item.status">已启用</van-tag>
            <van-tag v-else size="medium" type="danger">已停用</van-tag>
          </view>
        </view>
        <view class="text-padding">主营类别: {{ item.catalog }}</view>
        <view class="text-padding">地址: {{ item.address }}</view>
      </view>
    </van-panel>
  </view>
</template>

<script>
export default {
  props: {
    item: {}
  },
  filters: {
    // 类别过滤器
    typeFilter(value) {
      let values = {
        '1': '订单供应商',
        '2': '合同供应商',
        '3': '临时供应商'
      };
      return values[value];
    }
  },
  data() {
    return {};
  },
  methods: {
    // 跳转详情页面
    openDetail() {
      uni.navigateTo({ url: '/index-pkg/supplierDetail?supplierId=' + this.item.id });
    }
  }
};
</script>

<style scoped lang="less">
.header {
  // padding: 18rpx 32rpx;
  display: flex;
  justify-content: space-between;
}
.info-color {
  color: #666666;
}
.green-color {
  color: #00cc00;
}
.red-color {
  color: red;
}
</style>

<template>
  <view>
    <!-- 列表 -->
    <uni-table border stripe emptyText="暂无更多数据">
      <!-- 表头行 -->
      <uni-tr>
        <uni-th class="table-th" width="80" align="center">月份</uni-th>
        <uni-th width="120" align="center">合同总额</uni-th>
        <uni-th width="120" align="center">已回总额</uni-th>
        <uni-th width="120" align="center">待回总额</uni-th>
        <uni-th width="120" align="center">工程支出</uni-th>
        <uni-th width="120" align="center">经营支出</uni-th>
      </uni-tr>
      <!-- 表格数据行 -->
      <uni-tr v-for="item in statisticsData" :key="item.id">
        <uni-td class="table-th" align="center">{{ item.monthValue }}</uni-td>
        <uni-td align="center">{{ item.totalMoney }}</uni-td>
        <uni-td align="center">{{ item.realBackMoney }}</uni-td>
        <uni-td align="center">{{ item.unreceivedMoney }}</uni-td>
        <uni-td align="center">{{ item.monthPaidMoney }}</uni-td>
        <uni-td align="center">{{ item.monthManageMoney }}</uni-td>
      </uni-tr>
    </uni-table>
  </view>
</template>

<script>
export default {
  props: {
    // 列表数据
    statisticsData: {}
  },
  data() {
    return {};
  },
  methods: {}
};
</script>

<style scoped lang="scss">
::v-deep .uni-table-th:first-child,
::v-deep .uni-table-td:first-child {
  position: sticky;
  left: 0;
  z-index: 5;
  // padding-left: 5px;
  background: #fff;
}
</style>

<template>
  <view class="mt-5">
    <!-- 待我整改 -->
    <van-cell is-link v-if="waitingSolveCount">
      <template #title>
        <view class="header-title">待我整改</view>
        <view class="assistant-title">
          您有
          <text class="number-text" style="color: #ffc833;">{{ ` ${waitingSolveCount} ` }}</text>
          条施工待整改问题，请及时整改
        </view>
      </template>
      <template #right-icon>
        <van-button round color="#ffc833" @click="openPatrol(1, 'mine', '待我整改')">去整改</van-button>
      </template>
    </van-cell>
    <!-- 待我验证 -->
    <van-cell is-link v-if="waitingCloseCount">
      <template #title>
        <view class="header-title">待我验证</view>
        <view class="assistant-title">
          您有
          <text class="number-text" style="color: #07c160;">{{ ` ${waitingCloseCount} ` }}</text>
          条整改已完成，请及时验证
        </view>
      </template>
      <template #right-icon>
        <van-button round type="primary" @click="openPatrol(2, 'mine', '待我验证')">去验证</van-button>
      </template>
    </van-cell>
    <!-- 我发起的 -->
    <van-cell is-link v-if="mineDonateCount">
      <template #title>
        <view class="header-title">我发起的</view>
        <view class="assistant-title">
          您有
          <text class="number-text" style="color: #36d7ff;">{{ ` ${mineDonateCount} ` }}</text>
          条整改单无人整改，请及时跟进
        </view>
      </template>
      <template #right-icon>
        <van-button round color="#36d7ff" @click="openPatrol(1, 'sponsor', '我发起的')">去看看</van-button>
      </template>
    </van-cell>
  </view>
</template>

<script>
import { projectTrend, patrolRemind } from '@/api/trend.js';
export default {
  props: {
    isLoading: {}
  },
  data() {
    return {
      mineDonateCount: 0,
      waitingCloseCount: 0,
      waitingSolveCount: 0
    };
  },
  onLoad() {},
  created() {
    this.remind();
  },
  methods: {
    // 页面提醒
    async remind() {
      try {
        let { mineDonateCount, waitingCloseCount, waitingSolveCount } = await patrolRemind();
        this.mineDonateCount = mineDonateCount;
        this.waitingCloseCount = waitingCloseCount;
        this.waitingSolveCount = waitingSolveCount;
        this.$emit('update:isLoading', false);
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 跳转页面
    openPatrol(type, queryType, name) {
      uni.navigateTo({ url: '/index-pkg/patrolAll?type=' + type + '&queryType=' + queryType + '&name=' + name });
    }
  }
};
</script>

<style scoped lang="scss">
@function rpx2em($rpx) {
  @return ($rpx / 16) * 1rem;
}
@media (min-width: 768px) {
  .assistant-title {
    padding-top: rpx2em(10);
  }
}
.header-title {
  font-size: rpx2em(13);
  color: #000;
  font-weight: bolder;
}

.assistant-title {
  color: #646566;
  font-size: 0.8em;
}

.number-text {
  font-weight: bolder;
  color: #000;
  font-size: rpx2em(16);
}

::v-deep .van-button {
  height: rpx2em(22);
  margin: rpx2em(12) rpx2em(0);
  padding: 0 rpx2em(10);
}
::v-deep .van-button--normal {
  font-size: rpx2em(10);
}
</style>

<template>
  <view class="">
    <view class="flex-between" style="position: relative;">
      <van-cell is-link>
        <!-- 标题 -->
        <template #title>
          <view class="dflex">
            <view class="portrait"><image style="width: 100%;height: 100%;" :src="userInfo.avatar" mode=""></image></view>
            <view class="user-name">
              <view class="" style="font-weight: 600;">{{ userInfo.nickName }}</view>
              <text class="">{{ userInfo.phone }}</text>
            </view>
          </view>
        </template>
        <template #right-icon></template>
      </van-cell>
      <van-grid clickable :column-num="2" :border="false" style="background-color: #fff;" class="grid-box">
        <van-grid-item @click="tabMessage" icon="chat-o" text="" :badge="messageCount" />
        <van-grid-item @click="tabTask" icon="add-o" />
      </van-grid>
      <!-- 弹出窗 -->
      <view class="popup" ref="popup" v-if="addShow">
        <view class="show-text" @click="pollingView">设计部巡检</view>
        <view class="show-text" @click="trendView">发起整改</view>
        <view class="show-text" @click="donationView">发乐捐单</view>
        <view class="show-text" @click="newPolling">工程部巡检</view>
      </view>
      <view class="show-icon" v-if="addShow"></view>
    </view>
  </view>
</template>

<script>
import { mapState, mapMutations } from 'vuex';
import { getByCurr } from '@/api/login.js';
import { messageCount } from '@/api/wait.js';
export default {
  data() {
    return {
      userInfo: {},
      messageCount: 0,
      // 概览信息
      info: {
        examineCount: 0,
        taskCount: 0
      },
      addShow: false
    };
  },
  onLoad() {},
  created() {
    this.getData();
    this.getMessage();
  },
  computed: {
    ...mapState('user', ['perList'])
  },
  beforeUnmount() {
    // 组件卸载时移除监听
    document.removeEventListener('click', this.handleClickOutside);
  },
  methods: {
    ...mapMutations('user', ['USER_INFO']),
    // 获取用户信息
    async getData() {
      try {
        let { data } = await getByCurr();
        this.userInfo = data;
        await this.USER_INFO(this.userInfo);

        // let { data: datas } = await AccAdminTodo();
        // this.info = {
        //   examineCount: datas.examineCount,
        //   taskCount: datas.taskCount
        // };
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 获取消息信息
    async getMessage() {
      let { data: messageData } = await messageCount();
      this.messageCount = messageData || 0;
      this.isLoading = false;
    },
    // 打开待办任务页面
    tabTask() {
      this.addShow = !this.addShow;
      if (this.addShow) {
        // 延迟绑定事件，避免立即触发
        setTimeout(() => {
          document.addEventListener('click', this.handleClickOutside);
        }, 0);
      } else {
        document.removeEventListener('click', this.handleClickOutside);
      }
      // uni.navigateTo({ url: '/wait-pkg/backlogTask' });
    },
    handleClickOutside(event) {
      // 直接通过 event.target 判断是否在弹窗内
      const popup = this.$refs.popup.$el;
      if (!popup || !popup.contains(event.target)) {
        this.addShow = false;
        document.removeEventListener('click', this.handleClickOutside);
      }
    },
    closePopup() {
      this.addShow = false;
    },
    // 日常巡检
    pollingView() {
      if (!this.perList.includes('trend:patrol')) {
        this.Toast.fail('您暂无权限，请联系管理员');
        return;
      }
      uni.navigateTo({ url: '/index-pkg/pollingView' });
    },
    newPolling() {
      if (!this.perList.includes('trend:patrol')) {
        this.Toast.fail('您暂无权限，请联系管理员');
        return;
      }
      uni.navigateTo({ url: '/index-pkg/newPolling' });
    },
    // 发起整改
    trendView() {
      if (!this.perList.includes('trend:patrol')) {
        this.Toast.fail('您暂无权限，请联系管理员');
        return;
      }
      uni.navigateTo({ url: '/index-pkg/trendView' });
    },
    // 乐捐单
    donationView() {
      if (!this.perList.includes('trend:money')) {
        this.Toast.fail('您暂无权限，请联系管理员');
        return;
      }
      uni.navigateTo({ url: '/index-pkg/donationView' });
    },
    // 打开我的消息页面
    tabMessage() {
      uni.navigateTo({ url: '/wait-pkg/myMessage' });
    },
    // 打开用户信息
    openUserInfo() {
      uni.navigateTo({ url: '/wait-pkg/userInfo' }); // 客户
    }
  }
};
</script>

<style scoped lang="scss">
@function rpx2em($rpx) {
  @return ($rpx / 16) * 1rem;
}
.user-name {
  font-size: rpx2em(13);
}
.popup {
  position: absolute;
  background-color: #4c4c4c;
  color: #fff;
  width: rpx2em(140);
  top: 80%;
  right: 4%;
  z-index: 100;
  border-radius: 5%;
  padding: rpx2em(5) rpx2em(0);
  .show-text {
    font-size: rpx2em(17);
    padding: rpx2em(14) rpx2em(5);
    text-align: center;
  }
}
.show-icon {
  position: absolute;
  top: 72%;
  right: 8%;
  width: 0;
  height: 0;
  border-left: rpx2em(5) solid transparent; /* 左侧透明边框 */
  border-right: rpx2em(5) solid transparent; /* 右侧透明边框 */
  border-bottom: rpx2em(8.66) solid #333; /* 底部实色边框（高度 = 边宽 × √3 / 2） */
}
.show-add ::v-deep .van-cell {
  background-color: #fff;
}
.gray-text {
  color: #969799;
  line-height: rpx2em(50);
}
.grid-box {
  flex: 0 0 35%;
}
::v-deep .van-cell {
  padding: rpx2em(8) rpx2em(10);
}
.portrait {
  width: rpx2em(54);
  height: rpx2em(54);
  padding: rpx2em(0) rpx2em(5);
}
::v-deep .van-grid-item__icon {
  font-size: rpx2em(30);
}
::v-deep .van-grid-item__content {
  // padding: rpx2em(2) rpx2em(16);
}
/* 平板竖屏模式 (768px-1024px) */
@media (min-width: 768px) and (max-width: 1024px) {
  /* 平板竖屏样式 */
  .popup {
    position: absolute;
    background-color: #4c4c4c;
    color: #fff;
    width: rpx2em(140);
    top: 90%;
    right: 4%;
    z-index: 100;
    border-radius: 5%;
    padding: rpx2em(5) rpx2em(0);
    .show-text {
      font-size: rpx2em(17);
      padding: rpx2em(14) rpx2em(5);
      text-align: center;
    }
  }
  .show-icon {
    position: absolute;
    top: 80%;
    right: 8%;
    width: 0;
    height: 0;
    border-left: rpx2em(5) solid transparent; /* 左侧透明边框 */
    border-right: rpx2em(5) solid transparent; /* 右侧透明边框 */
    border-bottom: rpx2em(8.66) solid #333; /* 底部实色边框（高度 = 边宽 × √3 / 2） */
  }
}
</style>

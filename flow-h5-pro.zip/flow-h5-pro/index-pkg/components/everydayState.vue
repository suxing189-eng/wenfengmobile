<template>
  <view class="gray-bj-color">
    <view class="tab"></view>
    <van-dropdown-menu>
      <!-- 日期选择 -->
      <van-dropdown-item @open="calendarOpen" :title="trendDate" ref="item">
        <van-calendar v-model="show" @select="selectCalendar" :min-date="minDate" :max-date="maxDate" />
      </van-dropdown-item>
      <!-- 巡检类型 -->
      <van-dropdown-item :title="statusText" v-model="queryParams.trendType" :options="examineOption" @change="dropownChange"></van-dropdown-item>
    </van-dropdown-menu>
    <!-- 施工动态列表 -->
    <van-list v-model="loading" :finished="finished" :finished-text="finishedText" @load="upwardPull">
      <view class="mt-10">
        <van-cell class="" v-for="item in trendData" :key="item.id">
          <template #title>
            <view class="project-title">{{ item.projectName }}</view>
            <view class="flex-between">
              <van-tag plain type="primary" style="font-weight: 600;line-height: 24px;height: 24px;" v-if="item.trendType === 1">早会视频</van-tag>
              <van-tag plain type="primary" style="font-weight: 600;line-height: 24px;height: 24px;" v-if="item.trendType === 2">施工日志</van-tag>
              <van-tag plain type="primary" style="font-weight: 600;line-height: 24px;height: 24px;" v-if="item.trendType === 3">质量巡检</van-tag>
              <van-tag plain type="primary" style="font-weight: 600;line-height: 24px;height: 24px;" v-if="item.trendType === 4">周计划</van-tag>
              <van-tag plain type="primary" style="font-weight: 600;line-height: 24px;height: 24px;" v-if="item.trendType === 5">乐捐单</van-tag>
              <view>{{ item.trendNode }}</view>
              <van-icon v-if="item.trendType === 1" @click="openVideo(item)" size="26" name="play-circle-o" />
              <text v-if="item.trendType === 5" style="color: red;">{{ `乐捐金额: ${item.trendMoney} 元` }}</text>
            </view>
          </template>
          <template #label>
            <view v-if="item.trendType !== 1">
              <view class="text-padding" v-html="item.trendContent"></view>
              <view class="image-view">
                <view @tap="tabImage" v-for="(i, index) in item.imageThumbList" :key="index" :data-url="item.images[index]" :data-imgList="item.images" class="image-item">
                  <image style="width: 100%;height: 100%;" :src="i" mode=""></image>
                </view>
              </view>
              <!-- 整改图片 （只有质量巡检才有） -->
              <view v-if="item.trendType === 3 && item.trendState !== 0 && item.trendState !== 1" class="">
                <view class="text-padding">{{ item.solveContent }}</view>
                <view class="image-view">
                  <view
                    @tap="tabImage"
                    v-for="(i, index) in item.solveThumbList"
                    :key="index"
                    :data-url="item.solveImages[index]"
                    :data-imgList="item.solveImages"
                    class="image-item"
                  >
                    <image style="width: 100%;height: 100%;" :src="i" mode=""></image>
                  </view>
                </view>
              </view>
              <view class="flex-between text-padding">
                <text>{{ `${util.dateFormat('yyyy-mm-dd', new Date(item.trendDate))}【${item.createBy}】` }}</text>
              </view>
            </view>
            <!-- 早会视频 -->
            <view v-else>
              <view class="project-title">{{ item.projectName }}</view>
              <view class="video-update"><image style="width: 100%;height: 100%;" src="@/static/trendVideo.png" mode=""></image></view>
              <view class="flex-between text-padding">
                <view>{{ `${util.dateFormat('yyyy-mm-dd', new Date(item.trendDate))}【${item.createBy}】` }}</view>
              </view>
            </view>
          </template>
        </van-cell>
      </view>
      <van-empty v-if="trendData.length === 0" description="暂无数据" />
    </van-list>
    <view style="height: 92rpx;width: 100%;"></view>
  </view>
</template>

<script>
import { projectTrend, patrolRemind } from '@/api/trend.js';
export default {
  data() {
    return {
      // 请求数据参数
      queryParams: {
        pageNo: 0,
        pageSize: 10,
        trendDate: '',
        trendType: ''
      },
      // 数据列表
      trendData: [],
      // 页面显示时间
      trendDate: '',
      statusText: '全部',
      show: false,
      // 选择的日期（用来对应时间选择器的时间）
      nowDate: '',
      // 状态集合
      examineOption: [
        { text: '全部', value: '' },
        { text: '施工日志', value: 2 },
        { text: '早会视频', value: 1 },
        { text: '质量巡检', value: 3 },
        { text: '周计划', value: 4 },
        { text: '乐捐单', value: 5 }
      ],
      minDate: new Date(2016, 0, 1),
      maxDate: new Date(),
      // 视频
      trailer: [],
      danmuList: [],
      // 下拉状态
      loading: false,
      // 是否已加载完成
      finished: false,
      // 加载完成文字
      finishedText: '没有更多了'
    };
  },
  created() {
    // 查询参数
    this.queryParams.trendDate = this.util.dateFormat('yyyy-mm-dd', new Date());
    // 显示的标题 年月
    this.trendDate = this.util.dateFormat('yyyy-mm-dd', new Date());
    this.projectTrend();
    this.remind();
  },
  methods: {
    // 页面提醒
    async remind() {
      try {
        let { remind, msg } = await patrolRemind();
        if (remind !== 0) {
          this.Dialog.alert({
            title: '提示',
            message: msg
          }).then(() => {});
        }
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 获取页面数据
    async projectTrend() {
      try {
        let { data, dataCount } = await projectTrend(this.queryParams);
        // this.trendData = data;
        this.isLoading = false;
        this.trendData = this.trendData.concat(data);
        this.loading = false;
        this.isLoading = false;
        if (this.queryParams.pageNo * this.queryParams.pageSize > dataCount) {
          this.finished = true;
        } else {
          this.finished = false;
        }
        if (dataCount === 0) {
          this.finishedText = '';
        } else {
          console.log(111);
          this.finishedText = '没有更多了...';
        }
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 上拉回调
    upwardPull() {
      this.queryParams.pageNo += 1;
      this.projectTrend();
    },
    // 下拉回调
    dropownChange(value) {
      this.trendData = [];
      let examine = this.examineOption.filter(item => {
        return item.value === value;
      });
      this.statusText = examine[0].text;
      this.queryParams.trendType = value;
      this.projectTrend();
    },
    calendarOpen() {
      this.show = true;
    },
    // 预览图片
    tabImage(e) {
      uni.previewImage({
        urls: e.currentTarget.dataset.imglist,
        current: e.currentTarget.dataset.url
      });
    },
    // 获取视频信息
    loadedmetadata(e) {
      this.$nextTick(() => {
        this.trailer.push(e.target.id);
      });
    },
    // 控制视频播放
    play(e) {
      setTimeout(() => {
        let createId = e.target.id;
        this.trailer.forEach(id => {
          if (id != createId) uni.createVideoContext(id + '', this).pause();
        });
      }, 500);
    },
    // 选择日期
    selectCalendar(date) {
      this.show = false;
      this.trendData = [];
      this.trendDate = this.util.dateFormat('yyyy-mm-dd', new Date(date));
      this.queryParams.trendDate = this.util.dateFormat('yyyy-mm-dd', new Date(date));
      this.$refs.item.toggle();
      this.projectTrend();
    },
    // 播放视频
    openVideo(item) {
      uni.navigateTo({ url: '/index-pkg/trendVideo?video=' + item.trendVideo });
    }
  }
};
</script>

<style scoped lang="scss">
.project-title {
  font-weight: 600;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.image-view {
  display: flex;
  flex-wrap: wrap;
  .image-item {
    width: 32%;
    height: 230rpx;
    margin: 4rpx;
  }
}
.van-empty {
  padding: 40rpx 0;
}
.video-update {
  width: 100%;
  height: 280rpx;
  display: flex;
  justify-content: center;
  flex-direction: column;
}
::v-deep .van-cell__title,
.van-cell__value {
  overflow: hidden;
}
</style>

<template>
  <view style="overflow: auto;">
    <van-cell>
      <template #title>
        <view class="flex-between">
          <text style="font-weight: 600;width: 450rpx;overflow:hidden; text-overflow:ellipsis;white-space: nowrap;">{{ item.useTypeName }}</text>
          <view>
            <text style="color: #909399;" v-if="item.examineState === -1">{{ item.stateText }}</text>
            <text style="color: #409EFF;" v-else-if="item.examineState === 0">{{ item.stateText }}</text>
            <text style="color: #67C23A;" v-else-if="item.examineState === 1">{{ item.stateText }}</text>
            <text style="color: red;" v-else>{{ item.stateText }}</text>
          </view>
        </view>
      </template>
      <template #label>
        <view class="flex-between text-padding">
          <view class="">申请日期: {{ item.requestDate }}</view>
          <view class="">请款金额: {{ item.requestMoney }}</view>
        </view>
        <view class="text-padding">收款人: {{ item.payeeUser }}</view>
        <!-- <view class="text-padding">卡号: {{ item.payeeAccount }}</view> -->
        <view class="text-padding">{{ item.remark }}</view>
      </template>
    </van-cell>
  </view>
</template>

<script>
export default {
  props: {
    item: {}
  },
  data() {
    return {};
  },
  created() {},
  methods: {}
};
</script>

<style scoped lang="less">
::v-deep .van-cell {
  border-bottom: 3rpx solid #f2f2f2;
}
</style>

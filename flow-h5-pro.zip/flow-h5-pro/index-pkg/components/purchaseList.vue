<template>
  <van-panel class="">
    <template #header>
      <view class="header" @click="openProject(item)">{{ item.projectName }}</view>
    </template>
    <view style="padding: 0 32rpx;">
      <view class="text-padding">{{item.contractName}}</view>
      <!-- <view class="text-padding">计划付款：{{item.}}</view> -->
      <view class="text-padding">付款节点：{{item.planNode}}</view>
      <view class="flex-between text-padding">
        <view>
          <view style="padding-bottom: 14rpx;">应付金额</view>
          <view>{{ item.planMoney }}</view>
        </view>
        <view>
          <view style="padding-bottom: 14rpx;">实付金额</view>
          <view>{{ item.realBackMoney }}</view>
        </view>
        <view>
          <view style="padding-bottom: 14rpx;">到期未付</view>
          <view style="color: red;font-weight: 600;">{{ item.remainPayMoney }}</view>
        </view>
      </view>
    </view>
  </van-panel>
</template>

<script>
export default {
  props: {
    item: {}
  },
  data() {
    return {
      // 跳转工程详情
      openProject(item) {
        uni.navigateTo({ url: '/index-pkg/projectDetail?id=' + item.projectId });
      }
    };
  }
};
</script>

<style>
.header {
  font-weight: 600;
  color: #0000ff;
  text-decoration: underline;
  /* padding: 18rpx 32rpx; */
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
</style>

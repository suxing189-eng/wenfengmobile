<template>
  <view>
    <van-panel v-for="item in followData" :key="item.id">
      <template #header>
        <view class="header">
          <text style="font-weight: 600;width: 520rpx;" class="text-nowrap">{{ item.followDate }}</text>
          <text style="color: red;" v-if="item.showDeleteBtn" @click="delFollow(item.id)">删除</text>
        </view>
      </template>
      <view style="padding: 0 32rpx;">
        <view class="flex-between text-padding">
          <view>跟进人: {{ item.createBy }}</view>
          <view>方式：{{ item.followType }}</view>
        </view>
        <view class="text-padding"><text v-html="item.content"></text></view>
      </view>
    </van-panel>
    <view v-if="followData.length > 0" style="height: 114rpx;"></view>
    <van-empty v-if="followData.length === 0" description="暂无数据" />
    <!-- 写跟进 -->
    <view class="van-contact-list__bottom"><van-button color="#666666" round icon="plus" size="normal" @click="openFollow">写跟进</van-button></view>
  </view>
</template>

<script>
import { followRecordDelete} from '@/api/index.js';
export default {
  props: {
    followData: {},
    businessId: {}
  },
  data() {
    return {
      // 跟进方式
      typeColumns: []
    };
  },
  created() {
    
  },
  methods: {
    // 写跟进
    openFollow() {
      uni.navigateTo({ url: '/index-pkg/businessFollow?businessId=' + this.businessId });
    },
    // 删除
    async delFollow(id) {
      try {
        this.Dialog.confirm({
          message: '确认删除此跟进记录吗？'
        })
          .then(() => {
            followRecordDelete(id).then(item => {
              this.Toast('删除成功');
              this.$emit('changeList');
            });
            // on confirm
          })
          .catch(() => {
            // on cancel
          });
      } catch (e) {
        //TODO handle the exception
      }
    }
  }
};
</script>

<style>
.header {
  /* padding: 18rpx 32rpx; */
  display: flex;
  justify-content: space-between;
}
.van-button--normal {
  width: 95%;
}
.van-button {
  margin: 12rpx 20rpx;
}
</style>

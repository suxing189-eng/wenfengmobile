<template>
  <view style="overflow: auto;">
    <van-cell class="cell-name" v-for="item in orderData" :key="item.id" @click="openDetail(item)">
      <template #title>
        <view class="flex-between">
          <text class="text-nowrap" style="font-weight: 600;width: 75%;color: #0000ff;text-decoration: underline;">{{ item.supplierName }}</text>
          <view>
            <text style="color: #909399;" v-if="item.examineState === -1">{{ item.stateText }}</text>
            <text style="color: #409EFF;" v-else-if="item.examineState === 0">{{ item.stateText }}</text>
            <text style="color: #67C23A;" v-else-if="item.examineState === 1">{{ item.stateText }}</text>
            <text style="color: red;" v-else>{{ item.stateText }}</text>
          </view>
        </view>
      </template>
      <template #label>
        <view class="flex-between text-padding">
          <view class="">送货日期: {{ item.sendDate }}</view>
          <view class="">请款金额: {{ item.totalMoney }}</view>
        </view>
        <view class="text-padding">单据号: {{ item.paperNo }}</view>
        <view class="text-padding">{{ item.remark }}</view>
      </template>
    </van-cell>
    <van-empty v-if="orderData.length === 0" description="暂无数据" />
  </view>
</template>

<script>
export default {
  props: {
    orderData: {}
  },
  data() {
    return {};
  },
  created() {},
  methods: {
    // 查看材料单详情
    openDetail(item) {
      uni.navigateTo({ url: '/index-pkg/materialsView?id=' + item.id });
    }
  }
};
</script>

<style scoped lang="less">
.van-empty {
  padding: 40rpx 0;
}
</style>

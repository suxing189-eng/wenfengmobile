<template>
  <view class="">
    <!-- 项目外采合同付款概览 -->
    <van-cell class="mt-10" @click="openDetail('项目外采合同付款概览')">
      <template #title>
        <view class="header">
          <view style="font-weight: 600;text-align: center;">项目外采合同付款概览</view>
          <text class="header-detail">详情</text>
        </view>
      </template>
      <template #label>
        <view class="flex-between text-padding">
          <view class="">外包总额: {{ projectInfo.totalContractMoney }} 元</view>
          <view class="">计划付款总额: {{ projectInfo.totalPlanPayMoney }} 元</view>
        </view>
        <view class="flex-between text-padding">
          <view class="">已付总额: {{ projectInfo.totalPayMoney }} 元</view>
          <view class="">待付总额: {{ projectInfo.unpayMoney }} 元</view>
        </view>
        <view class="text-padding">付款进度：{{ projectInfo.progress }}</view>
      </template>
    </van-cell>
    <!-- 公司合同分包付款概览 -->
    <van-cell class="mt-10" @click="openDetail('公司合同分包付款概览')">
      <template #title>
        <view class="header">
          <view style="font-weight: 600;text-align: center;">公司合同分包付款概览</view>
          <text class="header-detail">详情</text>
        </view>
      </template>
      <template #label>
        <view class="flex-between text-padding">
          <view class="">外包总额: {{ companyInfo.totalContractMoney }} 元</view>
          <view class="">计划付款总额: {{ companyInfo.totalPlanPayMoney }} 元</view>
        </view>
        <view class="flex-between text-padding">
          <view class="">已付总额: {{ companyInfo.totalPayMoney }} 元</view>
          <view class="">待付总额: {{ companyInfo.unpayMoney }} 元</view>
        </view>
        <view class="text-padding">付款进度：{{ companyInfo.progress }}</view>
      </template>
    </van-cell>
  </view>
</template>

<script>
import { ContractPlanOverview } from '@/api/index.js';
export default {
  props: {
    projectId: {}
  },
  data() {
    return {
      // 项目外采详情
      projectInfo: {},
      // 公司外采详情
      companyInfo: {}
    };
  },
  created() {
    this.getData();
  },
  methods: {
    // 获取数据
    async getData() {
      try {
        let { data } = await ContractPlanOverview({ projectId: this.projectId });
        this.projectInfo = data[0];
        this.companyInfo = data[1];
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 打开详情页面
    openDetail(type) {
       uni.navigateTo({ url: '/index-pkg/procureDetail?type=' + type + '&projectId=' + this.projectId });
    }
  }
};
</script>

<style scoped lang="scss">
.header {
  position: relative;
  .header-detail {
    color: #409eff;
    text-decoration: underline;
    position: absolute;
    right: 0;
    top: 0;
  }
}
</style>

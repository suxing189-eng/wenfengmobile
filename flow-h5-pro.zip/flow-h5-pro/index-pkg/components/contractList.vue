<template>
  <view>
    <!-- 合同总览 -->
    <van-cell class="mt-10">
      <template #title>
        <view style="font-weight: 600;text-align: center;background-color: ;">合同总览</view>
      </template>
      <template #label>
        <view class="flex-between text-padding">
          <view class="">合同总额: {{ info.totalContractMoney }}</view>
          <view class="">已收款: {{ info.receivedMoney }}</view>
        </view>
        <view class="flex-between text-padding">
          <view class="">待收款: {{ info.unreceivedMoney }}</view>
          <view class="">回款进度: {{ info.progress }}</view>
        </view>
      </template>
    </van-cell>
    <!-- 合同列表 -->
    <contract-view :contractData="contractData"></contract-view>
  </view>
</template>

<script>
import contractView from '@/index-pkg/components/contractView.vue';
import { contractsList } from '@/api/index.js';
export default {
  props: {
    projectId: {}
  },
  components: {
    contractView
  },
  data() {
    return {
      // 概览数据
      info: {
        progress: '0%',
        receivedMoney: 0,
        totalContractMoney: 0,
        unreceivedMoney: 0
      },
      // 合同信息列表
      contractData: []
    };
  },
  onLoad() {},
  created() {
    this.getData();
  },
  methods: {
    // 获取合同信息数据
    async getData() {
      try {
        let { data, progress, receivedMoney, totalContractMoney, unreceivedMoney } = await contractsList({ projectId: this.projectId, category: 1 });
        this.info = {
          progress: progress,
          receivedMoney: receivedMoney,
          totalContractMoney: totalContractMoney,
          unreceivedMoney: unreceivedMoney
        };
        this.contractData = data;
      } catch (e) {
        //TODO handle the exception
      }
    }
  }
};
</script>

<style></style>

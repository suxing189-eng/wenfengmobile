<template>
  <view class="">
    <!-- 数据概览 -->
    <van-row class="header-box">
      <van-col span="12">
        <view class="header-item">
          <view class="header-title">项目经理支出合计(含在途)</view>
          <view class="header-title">其中在途请款</view>
        </view>
      </van-col>
      <van-col span="12">
        <view class="header-item">
          <view class="header-content">{{ paymentData.managerTotalPaidMoney }}</view>
          <view class="header-content">{{ paymentData.managerTotalExaminingMoney }}</view>
        </view>
      </van-col>
      <van-col span="12">
        <view class="header-item">
          <view class="header-title">公司支出合计(含在途)</view>
          <view class="header-title">其中在途请款</view>
        </view>
      </van-col>
      <van-col span="12">
        <view class="header-item">
          <view class="header-content">{{ paymentData.companyPaidMoney }}</view>
          <view class="header-content">{{ paymentData.companyExaminingMoney }}</view>
        </view>
      </van-col>
      <van-col span="12">
        <view class="header-item"><view class="header-title">工程合计总支出(含在途)</view></view>
      </van-col>
      <van-col span="12">
        <view class="header-item">
          <view class="header-content">{{ paymentData.totalPaidMoney }}</view>
        </view>
      </van-col>
    </van-row>
    <!-- 列表 -->
    <view style="overflow: auto;" class="mt-10">
      <van-cell class="cell-name" v-for="item in this.paymentData.data" :key="item.id">
        <template #title>
          <view class="flex-between">
            <text style="font-weight: 600;">{{ item.useType | purposeFilter }}</text>
          </view>
        </template>
        <template #label>
          <view class="flex-between text-padding">
            <view class="">申请日期: {{ util.dateFormat('yyyy-mm-dd', new Date(item.payDate)) }}</view>
            <view class="">请款金额: {{ item.payMoney }}</view>
          </view>
          <view class="text-padding">收款人: {{ item.payee }}</view>
          <view class="text-padding">卡号: {{ item.payeeAccount }}</view>
          <view class="text-padding">{{ item.remark }}</view>
        </template>
      </van-cell>
      <van-empty v-if="paymentData.data && paymentData.data.length === 0" description="暂无数据" />
    </view>
  </view>
</template>

<script>
import { paymentList } from '@/api/index.js';
export default {
  props: {
    projectId: {}
  },
  data() {
    return {
      // 支出信息
      paymentData: []
    };
  },
  created() {
    this.getData();
  },
  filters: {
    purposeFilter(value) {
      let values = {
        1: '零星人工费',
        2: '班组人工费',
        3: '项目外采',
        4: '备用金',
        5: '项目经理借支',
        6: '公司外采',
        7: '公司支出',
        8: '工程押金',
        9: '零星材料费',
        10: '订货单'
      };
      return values[value];
    }
  },
  methods: {
    // 获取数据
    getData() {
      try {
        paymentList({ projectId: this.projectId }).then(res => {
          this.paymentData = res;
        });
      } catch (e) {
        //TODO handle the exception
      }
    }
  }
};
</script>

<style scoped lang="scss">
@function rpx2em($rpx) {
  @return ($rpx / 16) * 1rem;
}
.header-box {
  // background-color: #fff;
  margin-bottom: rpx2em(10);
  margin-top: rpx2em(10);
  .header-item {
    flex: 0 0 49%;
    border-collapse: collapse;
    .header-title {
      text-align: center;
      height: rpx2em(28);
      line-height: rpx2em(28);
      padding: rpx2em(4) rpx2em(1);
      color: #646566;
      font-size: rpx2em(14);
      font-weight: 600;
      background-color: #fff;
    }
    .header-content {
      height: rpx2em(22);
      line-height: rpx2em(22);
      padding: rpx2em(7) rpx2em(10);
      font-size: rpx2em(16);
      // font-weight: 600;
      background-color: #fff;
      text-align: left;
    }
  }
}
.header-box ::v-deep .van-col {
  border-bottom: 1px solid #f7f8fa;
  border-right: 1px solid #f7f8fa;
}
// .item-project {
//   padding: rpx2em(10) rpx2em(5);
//   font-weight: 600;
//   font-size: rpx2em(13);
//   color: #646566;
// }
// .item-value {
//   padding: rpx2em(10) rpx2em(5);
//   // height: rpx2em(41);
//   font-weight: 600;
//   font-size: rpx2em(19);
//   background-color: #fff;
// }
</style>

<template>
  <view>
    <!-- 列表内容 -->
    <van-panel class="cell-name">
      <template #header>
        <view class="header">
          <text class="text-name">{{ item.customerName }}</text>
          <text :class="item.examineState === -1 ? 'info-color' : item.examineState === 1 ? 'green-color' : item.examineState === 0 ? 'color-blue' : 'color-red'">
            {{ item.stateText }}
          </text>
        </view>
      </template>
      <view class="content-box">
        <view class="text-padding">客户状态: {{ item.customerStatus }}</view>
        <view class="text-padding">客户地址: {{ item.customerAddress }}</view>
        <view class="flex-between text-padding">
          <view class="">联系人: {{ item.contactUser }}</view>
          <view class="">联系电话: {{ item.tell }}</view>
        </view>
      </view>
    </van-panel>
  </view>
</template>

<script>
export default {
  props: {
    item: {}
  },
  data() {
    return {};
  },
  methods: {}
};
</script>

<style scoped lang="scss">
@function rpx2em($rpx) {
  @return ($rpx / 16) * 1rem;
}
.header {
  padding: rpx2em(8) rpx2em(16) rpx2em(2) rpx2em(16);
  display: flex;
  justify-content: space-between;
}
.text-name {
  font-weight: 600;
  width: 80%;
}
.info-color {
  color: #666666;
}
.green-color {
  color: #00cc00;
}
.red-color {
  color: red;
}
</style>

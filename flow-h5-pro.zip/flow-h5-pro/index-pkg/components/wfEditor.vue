<template>
  <view class="" style="background-color: #fff;padding: 8rpx;">
    <div style="border: 1px solid #ccc;height: 320px;background-color: #fff;">
      <Toolbar style="border-bottom: 1px solid #ccc" :editor="editor" :defaultConfig="toolbarConfig" :mode="mode" />
      <Editor style="height: 315px; overflow-y: hidden;" v-model="value" :defaultConfig="editorConfig" :mode="mode" @onCreated="onCreated" @onChange="onChange" />
    </div>
  </view>
</template>

<script>
import { Editor, Toolbar } from '@wangeditor/editor-for-vue';
import '@wangeditor/editor/dist/css/style.css'; // wangeditor css
import { DomEditor } from '@wangeditor/editor';
export default {
  components: {
    Editor,
    Toolbar
  },
  props: {
    trendContent: {}
  },
  data() {
    return {
      value: '',
      // 富文本编辑器
      editor: null,
      html: '<p>hello</p>',
      toolbarConfig: {
        toolbarKeys: []
      },
      editorConfig: {
        placeholder: '请输入原因',
        maxLength: 500,
        hoverbarKeys: {
          // text: {
          //   // 重写 link 元素的 hoverbar
          //   menuKeys: []
          // }
        }
      },
      mode: 'simple' // or 'simple'
    };
  },
  beforeDestroy() {
    const editor = this.editor;
    if (editor == null) return;
    editor.destroy(); // 组件销毁时，及时销毁编辑器
  },
  created() {
    setTimeout(() => {
      this.value = this.trendContent;
    }, 300);
  },
  watch:{
    trendContent(value) {
      this.value = this.trendContent;
    },
  },
  methods: {
    onCreated(editor) {
      this.editor = Object.seal(editor); // 一定要用 Object.seal() ，否则会报错
    },
    // 富文本编辑器 change事件
    onChange(editor) {
      this.$emit('update:trendContent', this.value);
    }
  }
};
</script>

<style scoped lang="scss">
::v-deep #w-e-textarea-1 {
  padding: 0 10rpx;
}
::v-deep .w-e-text-container {
  height: 320px;
  padding: 0;
  background-color: #fff;
}
::v-deep .w-e-text-container p​:first-child {
  margin-top: 15px !important;
}
::v-deep .w-e-text-container p {
  margin: 8rpx;
}
</style>

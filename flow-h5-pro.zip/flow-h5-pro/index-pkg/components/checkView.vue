<template>
  <view class="">
    <!-- 概览 -->
    <van-cell class="mt-10">
      <template #title>
        <view class="flex-between text-padding">
          <view>今日打卡</view>
          <view>{{ todayWorkers }} 人</view>
          <view>累计打卡</view>
          <view>{{ totalWorkers }} 人</view>
        </view>
      </template>
    </van-cell>
    <van-cell>
      <template #title></template>
      <template #label>
        <view class="flex-between text-padding">
          <view>今日工日</view>
          <view>{{ todayClockDays }} 天</view>
          <view>累计工日</view>
          <view>{{ totalClockDays }} 天</view>
        </view>
      </template>
    </van-cell>
    <van-cell>
      <template #title></template>
      <template #label>
        <view class="flex-between text-padding">
          <view>缺勤人数</view>
          <view style="text-decoration: underline;color: blue;" @click="openNoRegister()">{{ `${absentClockCount} 人缺卡` }}</view>
          <view>缺银行卡</view>
          <view style="text-decoration: underline;color: blue;" @click="openSalaryCard()">{{ `${absentBankCount} 人` }}</view>
        </view>
      </template>
    </van-cell>
    <view class="flex-between text-padding">
      <van-radio-group style="margin: 20rpx 20rpx 10rpx 20rpx;" v-model="today" @change="radioChange" direction="horizontal">
        <van-radio name="1" icon-size="18px">今日打卡</van-radio>
        <van-radio name="2" icon-size="18px">全部打卡</van-radio>
      </van-radio-group>
      <!-- <view v-if="absentClockCount" style="margin: 20rpx 0rpx 10rpx 20rpx;text-decoration: underline;color: blue;" @click="openNoRegister()">
        {{ `${absentClockCount}人缺卡` }}
      </view> -->
    </view>
    <!-- 列表 -->
    <uni-table class="" border stripe emptyText="暂无更多数据">
      <!-- 表头行 -->
      <uni-tr>
        <uni-th width="70px" align="center">姓名</uni-th>
        <uni-th width="70px" align="center">工种</uni-th>
        <uni-th width="70px" align="center">打卡</uni-th>
        <uni-th width="70px" align="center">日工价</uni-th>
        <uni-th width="100px" align="center">应付工资</uni-th>
        <uni-th width="140px" align="center">已付工资</uni-th>
        <uni-th width="100px" align="center">待结清</uni-th>
      </uni-tr>
      <!-- 表格数据行 -->
      <uni-tr v-for="item in checkData" :key="item.id">
        <uni-td align="center">
          <text class="text-blue" @click="openDetail(item)">{{ item.realName }}</text>
        </uni-td>
        <uni-td align="center">
          <text class="text-blue" @click="openWorker(item)">{{ item.workerType }}</text>
        </uni-td>
        <uni-td align="center">{{ item.clockDays }}</uni-td>
        <uni-td align="center">
          <text class="text-blue" @click="openDayPrice(item)">{{ item.dayPrice }}</text>
        </uni-td>
        <uni-td align="center">{{ item.totalSalary }}</uni-td>
        <uni-td align="center">{{ item.paidSalary }}</uni-td>
        <uni-td align="center">{{ item.needPaySalary }}</uni-td>
      </uni-tr>
    </uni-table>

    <!-- 对话框 -->
    <van-dialog v-model="show" title="设置日工价" @confirm="confirm" @cancel="show = false" show-cancel-button>
      <van-field class="field-item" readonly v-model="realName" label="姓名" placeholder="" />
      <van-field class="field-item" type="number" v-model="dayPrice" label="日工价" placeholder="" />
    </van-dialog>

    <!-- 工种动作面板 -->
    <van-action-sheet v-model="activeShow" close-on-click-action :actions="workerTypeList" @select="onSelect" />
  </view>
</template>

<script>
import { ProjectWorker, ProjectWorkerUpdate, dictList } from '@/api/index.js';
export default {
  props: {
    projectId: {}
  },
  data() {
    return {
      // 考勤数据
      checkData: [],
      totalClockDays: 0,
      totalWorkers: 0,
      todayWorkers: 0,
      todayClockDays: 0,
      // 参数
      today: '2',
      startDate: '',
      endDate: '',
      // 对话框显示
      show: false,
      // 姓名
      realName: '',
      // 日工价
      dayPrice: '',
      // 数据id
      currentId: undefined,
      // 缺卡人数
      absentClockCount: 0,
      // 缺工资卡人数
      absentBankCount: 0,
      // 工种字典
      workerTypeList: [],
      // 动作面板显示
      activeShow: false
    };
  },
  created() {
    this.getData();
  },
  methods: {
    // 获取工种字段
    async getWorker() {
      try {
        this.workerTypeList = [];
        let { data } = await dictList({ dictType: 'worker_type' });
        data.forEach(item => {
          this.workerTypeList.push({ name: item.dictValue });
        });
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 获取数据
    async getData() {
      try {
        let queryParams = {
          projectId: this.projectId,
          startDate: this.startDate,
          endDate: this.endDate
        };
        let { data, totalClockDays, totalWorkers, todayWorkers, todayClockDays, absentClockCount, absentBankCount } = await ProjectWorker(queryParams);
        this.checkData = data;
        this.totalClockDays = totalClockDays || 0;
        this.totalWorkers = totalWorkers || 0;
        this.todayWorkers = todayWorkers || 0;
        this.todayClockDays = todayClockDays || 0;
        this.absentClockCount = absentClockCount || 0;
        this.absentBankCount = absentBankCount || 0;
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 单选框回调
    radioChange(value) {
      if (value === '1') {
        this.startDate = this.util.dateFormat('yyyy-mm-dd', new Date());
        this.endDate = this.util.dateFormat('yyyy-mm-dd', new Date());
      } else {
        this.startDate = '';
        this.endDate = '';
      }
      this.getData();
    },
    //跳转工人打卡详情
    openDetail(item) {
      uni.navigateTo({ url: '/index-pkg/checkDetail?id=' + item.dingUserId + '&projectId=' + this.projectId });
    },
    // 打开缺卡详情
    openNoRegister(item) {
      uni.navigateTo({ url: '/index-pkg/absent?projectId=' + this.projectId });
    },
    // 打开缺工资卡详情
    openSalaryCard() {
      uni.navigateTo({ url: '/index-pkg/deficiencyWageCard?projectId=' + this.projectId });
    },
    // 设置日工价
    openDayPrice(item) {
      this.realName = item.realName;
      this.dayPrice = item.dayPrice;
      this.currentId = item.id;
      this.show = true;
    },
    // 设置工种
    openWorker(item) {
      this.currentId = item.id;
      this.workerTypeList.length === 0 && this.getWorker();
      this.activeShow = true;
    },
    // 选择工种
    async onSelect(item) {
      try {
        let { msg } = await ProjectWorkerUpdate({ id: this.currentId, workerType: item.name });
        this.Toast.success('修改成功');
        setTimeout(() => {
          this.getData();
        }, 500);
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 对话框保存按钮
    async confirm() {
      try {
        let { msg } = await ProjectWorkerUpdate({ id: this.currentId, dayPrice: this.dayPrice });
        this.Toast.success('修改成功');
        this.show = false;
        setTimeout(() => {
          this.getData();
        }, 500);
      } catch (e) {
        //TODO handle the exception
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.flex-between {
  view {
    flex: 0 0 25%;
    text-align: center;
  }
}
.text-blue {
  color: #409eff;
  text-decoration: underline;
}
::v-deep .uni-table-th:first-child,
::v-deep .uni-table-td:first-child {
  position: sticky;
  left: 0;
  z-index: 5;
  // padding-left: 5px;
  background: #fff;
}
.text-blue {
  text-decoration: underline;
  color: #1989fa;
}
::v-deep.van-cell {
  padding: 8rpx 30rpx;
}
</style>

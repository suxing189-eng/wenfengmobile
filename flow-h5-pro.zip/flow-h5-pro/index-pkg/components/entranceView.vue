<template>
  <view class="mt-5 white-bg-color">
    <view class="header-title">快捷入口</view>
    <van-grid style="background-color: #fff;" :border="false" clickable :column-num="4">
      <van-grid-item v-for="item in crmList" :key="item.menuCode" @click="tabDetail(item.menuCode)" :icon="item.menuIcon" :text="item.menuName"></van-grid-item>
    </van-grid>
  </view>
</template>

<script>
import { quickMenu } from '@/api/index.js';
import { mapState } from 'vuex';
export default {
  data() {
    return {
      // 视图高度
      windowHeight: '',
      crmList: [],
      // 九宫格数据
      crmData: [
        'business-list',
        'customer-list',
        'supplier-list',
        'offer-list',
        'project-list',
        'history-bill',
        'worker-roster',
        'expired-plan',
        'contract-statistics',
        'manage-report',
        'profit-report',
        'cert-list'
      ]
    };
  },
  created() {
    this.projectData = ['project-list', 'history-bill', 'offer-list'];
    if (this.perList.includes('worker-roster')) {
      //有权限就加载 没权限就不加载
      this.projectData.push('worker-roster');
    }
    this.getData();
  },
  computed: {
    ...mapState('user', ['perList'])
  },
  methods: {
    // 获取数据
    async getData() {
      this.ListData = [];
      let { data } = await quickMenu();
      this.crmList = data.filter(obj => this.crmData.includes(obj.menuCode)).sort((a, b) => this.crmData.indexOf(a.menuCode) - this.crmData.indexOf(b.menuCode));
    },
    // 打开列表详情
    tabDetail(code) {
      switch (code) {
        case 'customer-list':
          uni.navigateTo({ url: '/index-pkg/customerList' }); // 客户
          break;
        case 'project-list':
          uni.navigateTo({ url: '/index-pkg/projectList' }); // 工程
          break;
        case 'supplier-list':
          uni.navigateTo({ url: '/index-pkg/supplierList' }); // 供应商
          break;
        case 'history-bill':
          uni.navigateTo({ url: '/index-pkg/historyBill' }); // 历史单据
          break;
        case 'business-list':
          uni.navigateTo({ url: '/index-pkg/businessList' }); //业务登记
          break;
        case 'offer-list':
          uni.navigateTo({ url: '/index-pkg/offerList' }); //报价查询
          break;
        case 'worker-roster':
          uni.navigateTo({ url: '/index-pkg/workerRoster' }); //花名册
          break;
        case 'expired-plan':
          uni.navigateTo({ url: '/index-pkg/expiredPlan' }); //
          break;
        case 'contract-purchase':
          uni.navigateTo({ url: '/index-pkg/contractPurchase' }); // 工程
          break;
        case 'return-record':
          uni.navigateTo({ url: '/index-pkg/returnRecord' }); // 供应商
          break;
        case 'payment-record':
          uni.navigateTo({ url: '/index-pkg/paymentRecord' }); //
          break;
        case 'commission-record':
          uni.navigateTo({ url: '/index-pkg/commissionRecord' }); //
          break;
        case 'manage-report':
          uni.navigateTo({ url: '/index-pkg/manageView' }); //
          break;
        case 'profit-report':
          uni.navigateTo({ url: '/index-pkg/profitList' }); //
          break;
        case 'contract-statistics':
          uni.navigateTo({ url: '/index-pkg/contractStatistics' }); //
          break;
        case 'cert-list':
          uni.navigateTo({ url: '/index-pkg/certList' }); // 证书管理
          break;
      }
    }
  }
};
</script>

<style scoped lang="scss">
@function rpx2em($rpx) {
  @return ($rpx / 16) * 1rem;
}
.gray-bj-color {
  width: 100%;
  overflow: auto;
  height: calc(100vh - var(--window-top) - var(--window-bottom));
}
.header-title {
  padding: rpx2em(10);
  font-size: rpx2em(13);
  color: #000;
  font-weight: bolder;
}
::v-deep .uni-app--showtabbar uni-page-wrapper::after {
  height: 0rpx;
}
::v-deep .van-grid-item__content {
  padding: rpx2em(8);
}
::v-deep .van-grid-item__text {
  font-size: rpx2em(14);
}
</style>

<template>
  <view class="">
    <van-panel>
      <template #header>
        <view class="header">
          <text style="font-weight: 600;width: 520rpx;" class="text-nowrap">{{ businessInfo.businessName }}</text>
          <text style="color: #666666;">{{ businessInfo.businessStateName }}</text>
        </view>
      </template>
      <view style="padding: 0 32rpx;">
        <view class="text-padding">地址: {{ businessInfo.businessAddress }}</view>
        <view class="text-padding">创建人: {{ businessInfo.createBy }}</view>
        <view class="text-padding">联系人: {{ businessInfo.contactUser }}</view>
        <view class="text-padding">联系电话: {{ businessInfo.contactPhone }}</view>
        <view class="text-padding">登记日期: {{ businessInfo.businessDate }}</view>
        <view class="text-padding">业务类型: {{ businessInfo.businessTypeName }}</view>
        <view class="text-padding">公司名称: {{ businessInfo.businessAddress }}</view>
        <view class="text-padding">公司法人: {{ businessInfo.legalRepresentative }}</view>
        <view class="text-padding">注册资金(万元): {{ businessInfo.registeredCapital }}</view>
        <view class="text-padding">营业执照编号: {{ businessInfo.businessLicenseNumber }}</view>
        <view class="text-padding">
          业务需求:
          <text v-html="businessInfo.remark"></text>
        </view>
      </view>
    </van-panel>
  </view>
</template>

<script>
export default {
  props: {
    businessInfo: {}
  },
  data() {
    return {};
  },
  methods: {}
};
</script>

<style>
.header {
  /* padding: 18rpx 32rpx; */
  display: flex;
  justify-content: space-between;
}
</style>

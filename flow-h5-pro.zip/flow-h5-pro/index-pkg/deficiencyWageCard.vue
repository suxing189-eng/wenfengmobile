<template>
  <view class="gray-bj-color" style="height: 100%;">
    <view class="tab"></view>
    <van-cell>
      <template #title>
        <view class="text-padding"><view>以下是当前项目没有收款信息的工人清单</view></view>
      </template>
    </van-cell>
    <!-- 列表 -->
    <uni-table class="" border stripe emptyText="暂无更多数据">
      <!-- 表头行 -->
      <uni-tr>
        <uni-th width="70" align="center">姓名</uni-th>
        <uni-th width="100" align="center">打卡手机号</uni-th>
        <uni-th width="70" align="center">日工价</uni-th>
        <uni-th width="70" align="center">出勤</uni-th>
      </uni-tr>
      <!-- 表格数据行 -->
      <uni-tr v-for="(item, index) in deficiencyCardData" :key="index">
        <uni-td align="center">{{ item.realName }}</uni-td>
        <uni-td align="center">{{ item.tell }}</uni-td>
        <uni-td align="center">{{ item.dayPrice }}</uni-td>
        <uni-td align="center">{{ item.clockDays }}</uni-td>
      </uni-tr>
    </uni-table>
  </view>
</template>

<script>
import { absentBankList } from '@/api/index.js';
export default {
  data() {
    return {
      projectId: undefined,
      // 缺卡人员数据
      deficiencyCardData: []
    };
  },
  onLoad(option) {
    this.projectId = option.projectId;
    this.getData();
  },
  methods: {
    // 获取数据
    async getData() {
      try {
        let { data } = await absentBankList({ projectId: this.projectId });
        this.deficiencyCardData = data;
      } catch (e) {
        //TODO handle the exception
      }
    }
  }
};
</script>

<style></style>

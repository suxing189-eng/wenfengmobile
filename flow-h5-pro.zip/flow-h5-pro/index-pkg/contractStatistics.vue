<template>
  <view class="gray-bj-color">
    <van-tabs v-model="active" sticky offset-top="44px" @change="tabChange" title-inactive-color="#666666" title-active-color="#000">
      <van-tab title="今年">
        <!-- 概览统计 -->
        <uni-table class="mt-5" border stripe emptyText="暂无更多数据">
          <!-- 表头行 -->
          <uni-tr>
            <uni-th width="120" align="center">名称</uni-th>
            <uni-th min-width="120" align="center">金额</uni-th>
          </uni-tr>
          <!-- 表格数据行 -->
          <uni-tr v-for="item in overviewData" :key="item.id">
            <uni-td align="center">{{ item.name }}</uni-td>
            <uni-td align="center">{{ item.value }}</uni-td>
          </uni-tr>
        </uni-table>
        <!-- 列表 -->
        <statistics-list class="mt-5" :statisticsData="statisticsData"></statistics-list>
      </van-tab>
      <van-tab title="同比">
        <uni-table class="mt-5" border stripe emptyText="暂无更多数据">
          <!-- 表头行 -->
          <uni-tr>
            <uni-th width="80" align="center">月份</uni-th>
            <uni-th width="120" align="center">今年</uni-th>
            <uni-th width="120" align="center">去年</uni-th>
          </uni-tr>
          <!-- 表格数据行 -->
          <uni-tr v-for="item in statisticsData" :key="item.id">
            <uni-td align="center">{{ item.monthValue }}</uni-td>
            <uni-td align="center">{{ item.totalMoney }}</uni-td>
            <uni-td align="center">{{ item.preYearMonthTotalMoney }}</uni-td>
          </uni-tr>
        </uni-table>
      </van-tab>
    </van-tabs>
  </view>
</template>

<script>
import statisticsList from '@/index-pkg/components/statisticsList.vue';
import { getContractStatistics } from '@/api/index.js';
export default {
  components: {
    statisticsList
  },
  data() {
    return {
      queryParams: {
        queryType: 'year'
      },
      // tab标签页
      active: 0,
      // 概览数据
      overviewData: [],
      // 列表数据
      statisticsData: []
    };
  },
  onLoad() {
    this.queryParams.queryYear = new Date().getFullYear() + '';
    this.getData();
  },
  methods: {
    // 获取数据接口
    async getData() {
      try {
        let { data, totalContractMoney, totalRealBackMoney, totalOverdueMoney, totalUnreceivedMoney, totalPaidMoney, totalManageMoney } = await getContractStatistics(this.queryParams);
        this.statisticsData = data;
        // 概览数据
        this.overviewData = [];
        this.overviewData.push({ name: '合同总额', value: totalContractMoney });
        this.overviewData.push({ name: '已回总额', value: totalRealBackMoney });
        this.overviewData.push({ name: '逾期回款', value: totalOverdueMoney });
        this.overviewData.push({ name: '待回总额', value: totalUnreceivedMoney });
        this.overviewData.push({ name: '工程支出', value: totalPaidMoney });
        this.overviewData.push({ name: '经营支出', value: totalManageMoney });
      } catch (e) {
        //TODO handle the exception
      }
    },
    // tab回调函数
    tabChange() {}
  }
};
</script>

<style></style>

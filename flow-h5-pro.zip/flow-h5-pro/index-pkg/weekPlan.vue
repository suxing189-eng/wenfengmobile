<template>
  <view class="gray-bj-color">
    <view class="tab5"></view>
    <van-form @submit="onSubmit">
      <van-field
        v-model="form.trendDate"
        @click="calendarShow = true"
        name="trendDate"
        label="开始日期"
        placeholder="请选择开始日期"
        :rules="[{ required: true, message: '请选择开始日期' }]"
      />
      <!-- <van-field v-model="form.trendContent" rows="2" autosize label="周计划内容" type="textarea" placeholder="请输入周计划内容" /> -->
      <!-- <wf-editor :trendContent.sync="form.trendContent"></wf-editor> -->
      <QuillEditor ref="quill" :value.sync="form.trendContent" :options="editorOptions" />
      <image-picker class="image" :fileValue.sync="fileValue" labelName="周计划图片"></image-picker>
      <div style="margin: 16px;"><van-button round block type="info" native-type="submit">提交</van-button></div>
    </van-form>

    <!-- 选择日历 -->
    <van-calendar v-model="calendarShow" :min-date="minDate" :max-date="maxDate" @confirm="dateConfirm" />
  </view>
</template>

<script>
import { dictList, projectTrendAdd, getCfg } from '@/api/index.js';
import imagePicker from '@/components/imagePicker.vue';
import QuillEditor from '@/components/quillEditor.vue';
// import wfEditor from '@/index-pkg/components/wfEditor.vue';
export default {
  components: {
    imagePicker,
    QuillEditor
    // wfEditor
  },
  data() {
    return {
      // 工程id
      projectId: 0,
      // 表单
      form: {
        trendContent: ''
      },
      editorOptions: {
        modules: {
          toolbar: [
            // 可以覆盖默认工具栏配置
            ['bold', 'italic'],
            ['link', 'image']
          ]
        }
      },
      // 日历显示
      calendarShow: false,
      fileValue: [],
      minDate: new Date(2000, 0, 1),
      maxDate: new Date()
    };
  },
  onLoad(option) {
    this.projectId = option.projectId;
    this.initData();
  },
  methods: {
    // 数据初始化
    async initData() {
      try {
        let { data } = await getCfg({ cfgName: 'week_plan_tpl' });
        this.form.trendContent = data;
        this.$refs.quill.initData();
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 选择日历
    formatDate(date) {
      return `${date.getFullYear()}/${date.getMonth() + 1}/${date.getDate()}`;
    },
    // 选择日期
    dateConfirm(date) {
      this.calendarShow = false;
      this.form.trendDate = this.formatDate(date);
    },
    // 上传成功回调
    successChange(e) {},
    selectChange(e) {
      let tempFilePaths = e.tempFilePaths;
      let upUrl;
      upUrl = window.config.apiUrl + '/upload/image';
      tempFilePaths.forEach(item => {
        uni.uploadFile({
          url: upUrl,
          fileType: 'image',
          filePath: item,
          name: 'file',
          header: {
            token: sessionStorage.getItem('satoken')
          },
          success: uploadFileRes => {
            let result = JSON.parse(uploadFileRes.data);
            this.fileValue = [...this.fileValue, { url: result.data.url, name: result.data.originalFilename, extname: result.data.ext }];
          },
          fail: result => {}
        });
      });
    },
    // 表单提交按钮
    async onSubmit() {
      try {
        this.form.trendType = 4;
        this.form.projectId = this.projectId;
        this.form.images = [];
        this.fileValue.forEach(item => {
          this.form.images.push(item.url);
        });
        this.form.images = this.form.images.join(',');
        let { msg } = await projectTrendAdd(this.form);
        this.Toast.success(msg);
        uni.navigateBack();
      } catch (e) {}
    }
  }
};
</script>

<style lang="scss" scoped>
::v-deep .uni-file-picker__header {
  padding: 0;
}
.tab5 {
  height: 10rpx;
}
</style>

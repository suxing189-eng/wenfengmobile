<template>
  <view>
    <van-form>
      <van-field v-model="form.trendDate" @click="calendarShow = true" name="trendDate" label="早会日期:" placeholder="请选择早会日期" />
      <view style="margin-top: 16rpx;">
        <view class="flex-between" style="padding: 14rpx 30rpx;">
          <text style="color: #646566;font-size: 28rpx;">早会视频</text>
          <text style="color:red" @click="delectVideo">移除视频</text>
        </view>
        <view class="video-update">
          <van-button v-if="upflag === 0" type="info" size="small" @click="uploadVideo">选择视频</van-button>
          <van-circle v-if="upflag === 1" v-model="currentRate" :rate="rate" :speed="100" :text="text" />
          <video
            style="width: 100%;"
            v-if="upflag === 2"
            @play="play"
            @loadedmetadata="loadedmetadata"
            :custom-cache="false"
            class="video-body"
            :danmu-list="danmuList"
            :src="videoSrc"
            controls
            object-fit="fill"
          />
        </view>
      </view>
      <div style="margin: 16px;"><van-button round block type="info" :disabled="isdisabled" native-type="submit" @click="onSubmit">提交</van-button></div>
    </van-form>

    <!-- 选择日历 -->
    <van-calendar v-model="calendarShow" :min-date="minDate" :max-date="maxDate" @confirm="dateConfirm" />
  </view>
</template>

<script>
import { dictList, projectTrendAdd } from '@/api/index.js';
export default {
  data() {
    return {
      // 工程id
      projectId: 0,
      // 表单
      form: {},
      // 日历显示
      calendarShow: false,
      videoSrc: '',
      minDate: new Date(2000, 0, 1),
      maxDate: new Date(),
      // 上传步骤
      upflag: 0,
      // 进度条
      currentRate: 0,
      rate: 20,
      // 视频
      trailer: [],
      danmuList: [],
      isdisabled: true
    };
  },
  computed: {
    text() {
      return this.currentRate.toFixed(0) + '%';
    }
  },
  onLoad(option) {
    this.projectId = option.projectId;
    this.form.trendDate = this.formatDate(new Date());
  },
  methods: {
    // 选择日历
    formatDate(date) {
      return `${date.getFullYear()}/${date.getMonth() + 1}/${date.getDate()}`;
    },
    // 选择日期
    dateConfirm(date) {
      this.calendarShow = false;
      this.form.trendDate = this.formatDate(date);
    },
    uploadVideo() {
      this.rate = 0;
      uni.chooseVideo({
        count: 1,
        sourceType: ['album'],
        compressed: false,
        success: res => {
          if (res.duration > 10 * 60) {
            // this.$bee.$msgError('视频时长超范围');
            return;
          }
          let upUrl;
          upUrl = window.config.apiUrl + '/upload/video/async';
          this.upflag = 1;
          const uploadTask = uni.uploadFile({
            url: upUrl,
            filePath: res.tempFilePath,
            name: 'file',
            header: {
              token: sessionStorage.getItem('satoken')
            },
            success: uploadFileRes => {
              setTimeout(() => {
                let res = JSON.parse(uploadFileRes.data);
                if (res.code === 200) {
                  this.videoSrc = res.data.url;
                  this.upflag = 2;
                  this.Toast.success('视频处理完成');
                  this.isdisabled = false;
                } else {
                  this.upflag = 0;
                  Toast.fail('上传失败');
                }
              }, 3000);
            },
            fail: result => {
              Toast.fail('上传失败');
              this.upflag = 0;
            }
          });
          uploadTask.onProgressUpdate(res => {
            let temPercent = Math.ceil(res.progress);
            if (temPercent > 99) {
              this.rate = 99;
            } else {
              this.rate = temPercent;
            }
          });
        }
      });
    },
    // 移除视频
    delectVideo() {
      if (!this.videoSrc) return;
      this.videoSrc = '';
      this.upflag = 0;
      this.isdisabled = true;
      this.Toast({ message: '视频已移除，请重新选择视频', position: 'top' });
    },
    // 表单提交按钮
    async onSubmit() {
      try {
        this.form.trendType = 1;
        this.form.projectId = this.projectId;
        this.form.trendVideo = this.videoSrc;
        // console.log(this.form, 777);
        let { msg } = await projectTrendAdd(this.form);
        this.Toast.success(msg);
        uni.navigateBack();
      } catch (e) {}
    },
    // 获取视频信息
    loadedmetadata(e) {
      this.$nextTick(() => {
        this.trailer.push(e.target.id);
      });
    },
    // 控制视频播放
    play(e) {
      setTimeout(() => {
        let createId = e.target.id;
        this.trailer.forEach(id => {
          if (id != createId) uni.createVideoContext(id + '', this).pause();
        });
      }, 500);
    }
  }
};
</script>

<style lang="scss" scoped>
::v-deep .uni-file-picker__header {
  padding: 0;
}
.video-update {
  width: 92%;
  height: 300rpx;
  display: flex;
  margin: 0 auto;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  border: dotted 2rpx #c8c9cc;
}
::v-deep .van-field__label {
  width: 5.2em;
}
</style>

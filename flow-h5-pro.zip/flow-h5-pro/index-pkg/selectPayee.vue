<template>
  <view class="gray-bj-color">
    <van-tabs v-model="active" sticky offset-top="44px" @change="tabChange" title-inactive-color="#666666" title-active-color="#000">
      <van-tab title="花名册">
        <van-search class="mt-10" v-model="queryParams.searchValue" @search="changeSearch" :clearable="false" placeholder="请输入搜索关键词" />
        <!-- 列表数据 -->
        <uni-table class="" ref="table" border stripe emptyText="暂无更多数据">
          <!-- 表头行 -->
          <uni-tr>
            <uni-th width="100" align="center">姓名</uni-th>
            <uni-th width="100" align="center">手机号</uni-th>
            <uni-th width="60" align="center">操作</uni-th>
          </uni-tr>
          <!-- 表格数据行 -->
          <uni-tr v-for="item in userData" :key="item.id">
            <uni-td align="center">{{ item.payeeUser }}</uni-td>
            <uni-td align="center">{{ item.tell }}</uni-td>
            <uni-td align="center"><text @click="selectChange(item)" style="color: blue;text-decoration: underline;">选择</text></uni-td>
          </uni-tr>
        </uni-table>
        <view class="uni-pagination-box">
          <uni-pagination show-icon :page-size="queryParams.pageSize" :current="queryParams.pageNo" :total="total" @change="paginationChange" />
        </view>
      </van-tab>
      <van-tab title="打卡名单">
        <van-search class="mt-10" v-model="queryParams.searchValue" @search="changeSearch" :clearable="false" placeholder="请输入搜索关键词" />
        <!-- 列表数据 -->
        <uni-table class="" ref="table" border stripe emptyText="暂无更多数据">
          <!-- 表头行 -->
          <uni-tr>
            <uni-th width="100" align="center">姓名</uni-th>
            <uni-th width="100" align="center">手机号</uni-th>
            <uni-th width="60" align="center">操作</uni-th>
          </uni-tr>
          <!-- 表格数据行 -->
          <uni-tr v-for="item in userData" :key="item.id">
            <uni-td align="center">{{ item.payeeUser }}</uni-td>
            <uni-td align="center">{{ item.tell }}</uni-td>
            <uni-td align="center"><text @click="selectChange(item)" style="color: blue;text-decoration: underline;">选择</text></uni-td>
          </uni-tr>
        </uni-table>
        <view class="uni-pagination-box">
          <uni-pagination show-icon :page-size="queryParams.pageSize" :current="queryParams.pageNo" :total="total" @change="paginationChange" />
        </view>
      </van-tab>
    </van-tabs>
  </view>
</template>

<script>
import { workerRoster, ProjectWorkerChoose } from '@/api/index.js';
export default {
  data() {
    return {
      active: 0,
      // 请求数据参数
      queryParams: {
        pageNo: 0,
        pageSize: 10,
        searchValue: ''
      },
      // 总条数
      total: 0,
      // 人员数据
      userData: [],
      // 工程ID
      projectId: undefined
    };
  },
  onLoad(option) {
    this.projectId = option.projectId;
    this.workerGetData();
  },
  methods: {
    // 刷新数据
    changeSearch() {
      this.userData = [];
      this.queryParams.pageNo = 1;
      if (this.active == 0) {
        this.workerGetData();
      } else {
        this.projectWorker();
      }
    },
    // 花名册请款人
    async workerGetData() {
      try {
        let { data, dataCount } = await workerRoster(this.queryParams);
        this.userData = data;
        this.total = dataCount;
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 打卡名单请款人
    async projectWorker() {
      try {
        this.queryParams.projectId = this.projectId;
        let { data, dataCount } = await ProjectWorkerChoose(this.queryParams);
        this.userData = data;
        this.total = dataCount;
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 选择数据
    selectChange(val) {
      var pages = getCurrentPages();
      var prevPage = pages[pages.length - 2]; //上一个页面
      prevPage.$vm.reBackData(val);
      uni.navigateBack({
        delta: 1
      });
    },
    // tab回调函数
    tabChange() {
      this.userData = [];
      this.queryParams.pageNo = 1;
      if (this.active == 0) {
        this.workerGetData();
      } else {
        this.projectWorker();
      }
    },
    // 换页刷新
    paginationChange(e) {
      this.$refs.table.clearSelection();
      this.queryParams.pageNo = e.current;
      if (this.active == 0) {
        this.workerGetData();
      } else {
        this.projectWorker();
      }
    }
  }
};
</script>

<style></style>

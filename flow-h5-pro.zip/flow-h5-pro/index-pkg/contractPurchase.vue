<template>
  <view class="gray-bj-color" style="height: calc(100vh - 88rpx);">
    <!-- tab页 -->
    <van-tabs v-model="active" sticky offset-top="44px" @change="tabChange" title-inactive-color="#666666" title-active-color="#000">
      <van-tab title="项目外采合同"></van-tab>
      <van-tab title="公司分包合同"></van-tab>
    </van-tabs>
    <!-- 数据概览 -->
    <view class="header">
      <view class="header-item">
        <view class="header-title">应付总额</view>
        <view class="header-content">{{ totalPlanMoney }}</view>
      </view>
      <view class="header-item">
        <view class="header-title">实付总额</view>
        <view class="header-content">{{ totalRealPayMoney }}</view>
      </view>
      <view class="header-item">
        <view class="header-title">到期未付</view>
        <view class="header-content">{{ totalRemainPayMoney }}</view>
      </view>
    </view>
    <!-- 工程列表 -->
    <view style="background-color: #fff;" v-for="item in dataList" :key="item.id"><purchase-list :item="item"></purchase-list></view>
    <van-empty v-if="dataList.length === 0" description="暂无数据" />
  </view>
</template>

<script>
import { expiredPayList } from '@/api/index.js';
import purchaseList from '@/index-pkg/components/purchaseList.vue';
export default {
  components: {
    purchaseList
  },
  data() {
    return {
      active: 0,
      category: 2,
      // 数据
      totalPlanMoney: 0,
      totalRealPayMoney: 0,
      totalRemainPayMoney: 0,
      dataList: []
    };
  },
  onLoad() {
    this.getData();
  },
  methods: {
    // 获取数据
    async getData() {
      try {
        let { data, totalPlanMoney, totalRealPayMoney, totalRemainPayMoney } = await expiredPayList({ category: this.category });
        this.dataList = data;
        this.totalPlanMoney = totalPlanMoney;
        this.totalRealPayMoney = totalRealPayMoney;
        this.totalRemainPayMoney = totalRemainPayMoney;
      } catch (e) {}
    },
    // tab页 回调
    tabChange() {
      if (this.active === 0) {
        this.category = 2;
      } else {
        this.category = 3;
      }
      this.getData();
    }
  }
};
</script>

<style>
.header {
  margin-top: 20rpx;
  background-color: #fff;
  margin-bottom: 20rpx;
  display: flex;
  justify-content: space-between;
  align-items: center;
  .header-item {
    flex: 0 0 33.3%;
    text-align: center;
    border: 1px solid #f5f6f8;
    border-collapse: collapse;
    .header-title {
      padding: 20rpx 10rpx;
      border-bottom: solid 1px #f5f6f8;
      color: #646566;
      font-size: 26rpx;
      font-weight: 600;
    }
    .header-content {
      padding: 40rpx 10rpx;
      font-size: 36rpx;
    }
  }
}
</style>

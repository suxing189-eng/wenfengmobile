<template>
  <view class="gray-bj-color"><patrol-view :type="queryParams.queryType" :trendData="trendData" @initData="initData"></patrol-view></view>
</template>

<script>
import patrolView from '@/index-pkg/components/patrolView.vue';
import { patrolCase } from '@/api/index.js';
export default {
  components: {
    patrolView
  },
  data() {
    return {
      trendData: [],
      queryParams: {
        pageNo: 0,
        pageSize: 10,
        trendState: 1,
        queryType: 'mine'
      }
    };
  },
  onLoad(option) {
    // 设置页面标题
    uni.setNavigationBarTitle({
      title: option.name
    });
    this.queryParams.trendState = option.type;
    this.queryParams.queryType = option.queryType;
    this.getData();
  },
  methods: {
    // 获取整改数据
    async getData() {
      try {
        let { data, dataCount } = await patrolCase(this.queryParams);
        this.trendData = data;
      } catch (e) {
        //TODO handle the exception
      }
    },
    /* 刷新*/
    initData() {
      this.getData();
    }
  }
};
</script>

<style scoped lang="scss">
@function rpx2em($rpx) {
  @return ($rpx / 16) * 1rem;
}
.gray-bj-color {
  height: 100vh;
  height: calc(100vh - 3rem);
}
</style>

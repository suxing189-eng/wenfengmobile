<template>
  <view class="gray-bj-color" style="height: calc(100vh - 88rpx);">
    <!-- 内容 -->
    <view class="">
      <view class="text-header">您整改的内容</view>
      <QuillEditor ref="quill" :value.sync="form.solveContent" :options="editorOptions" />
      <!-- <div style="border: 1px solid #ccc;margin: 8rpx;height: 200px;">
        <Toolbar style="border-bottom: 1px solid #ccc" :editor="editor" :defaultConfig="toolbarConfig" :mode="mode" />
        <Editor style="height: 200px; overflow-y: hidden;" v-model="form.solveContent" :defaultConfig="editorConfig" :mode="mode" @onCreated="onCreated" />
      </div> -->
    </view>
    <!-- 图片 -->
    <view class="">
      <view class="text-header">整改后的现场图片</view>
      <!-- <uni-file-picker
        style="background-color: #fff;padding: 10rpx;"
        mode="grid"
        file-mediatype="image"
        @select="selectChange"
        v-model="solveImages"
        @progress="progress"
        @success="success"
        @delete="onDelete"
        limit="9"
        title=""
        :list-styles="listStyles"
      ></uni-file-picker> -->
      <image-picker :fileValue.sync="solveImages" labelName="" title=""></image-picker>
    </view>
    <!-- 上传图片的加载弹窗 -->
    <van-dialog v-model="imageShow" style="background-color: #f7f8fa;" :showConfirmButton="false" :show-cancel-button="false">
      <view class="image-progress"><van-circle v-model="currentRate" :rate="100" :speed="0" text="上传中" /></view>
    </van-dialog>
    <!-- 底部按钮 -->
    <view class="van-contact-list__bottom"><van-button color="#666666" round icon="plus" size="normal" @click="openSheet">提交整改</van-button></view>
  </view>
</template>

<script>
import { trendDetail, trendSolve } from '@/api/trend.js';
import imagePicker from '@/components/imagePicker.vue';
// import { Editor, Toolbar } from '@wangeditor/editor-for-vue';
// import '@wangeditor/editor/dist/css/style.css'; // wangeditor css
// import { DomEditor } from '@wangeditor/editor';
import QuillEditor from '@/components/quillEditor.vue';
export default {
  components: {
    // Editor,
    // Toolbar
    QuillEditor,
    imagePicker
  },
  data() {
    return {
      // 数据id
      id: undefined,
      // 整改详情数据
      infoData: {},
      // 表单
      form: {
        solveContent: ''
      },
      // 上传的数据
      solveImages: [],
      editorOptions: {
        modules: {
          toolbar: [
            // 可以覆盖默认工具栏配置
            ['bold', 'italic'],
            ['link', 'image']
          ]
        }
      },
      // 线条样式
      listStyles: {
        // 是否显示边框
        border: true,
        // 是否显示分隔线
        dividline: true,
        // 线条样式
        borderStyle: {
          width: 1,
          color: 'blue',
          radius: 2
        }
      },
      // 图片上传对话框显示
      imageShow: false,
      // 上传进度条
      currentRate: 0
    };
  },
  onLoad(option) {
    this.id = option.id;
    this.getData();
  },
  methods: {
    // 获取整改详情数据
    async getData() {
      try {
        let { data } = await trendDetail({ id: this.id });
        this.infoData = data;
      } catch (e) {
        //TODO handle the exception
      }
    },
    success(e) {
      console.log('上传成功：', e);
    },
    // 获取上传进度
    progress(e) {
      console.log('上传进度：', e);
    },
    // // 移除图片
    // onDelete(e) {
    //   this.solveImages = this.solveImages.filter(item => item.url !== e.tempFilePath);
    // },
    // 整改提交
    async openSheet() {
      try {
        let solveImages = [];
        this.solveImages.forEach(item => {
          solveImages.push(item.url);
        });
        let image = solveImages.join(',');
        let form = {
          id: this.id,
          projectId: this.infoData.projectId,
          solveContent: this.form.solveContent,
          solveImages: image
        };
        let { msg } = await trendSolve(form);
        this.Toast.success(msg);
        uni.navigateBack();
      } catch (e) {
        //TODO handle the exception
      }
    },
    selectChange(e) {
      let tempFilePaths = e.tempFilePaths;
      let upUrl;
      upUrl = window.config.apiUrl + '/upload/image';
      tempFilePaths.forEach((item, index) => {
        this.imageShow = true;
        let progress = 0;
        let uploadTask = uni.uploadFile({
          url: upUrl,
          fileType: 'image',
          filePath: item,
          name: 'file',
          header: {
            token: sessionStorage.getItem('satoken')
          },
          success: uploadFileRes => {
            let result = JSON.parse(uploadFileRes.data);
            let fileData = [...this.solveImages, { url: result.data.url, name: result.data.originalFilename, extname: result.data.ext }];
            this.solveImages = fileData;
          },
          fail: result => {}
        });

        uploadTask.onProgressUpdate(res => {
          this.currentRate = res.progress;
          if (res.progress === 100) {
            setTimeout(() => {
              this.imageShow = false;
            }, 1300);
          }
        });
      });
    }
  }
};
</script>

<style scoped lang="scss">
.image-progress {
  width: 200rpx;
  margin: 40rpx auto;
}
.text-header {
  color: #606060;
  padding: 14rpx 10rpx;
}
::v-deep #w-e-textarea-1 {
  padding: 0;
}
::v-deep .w-e-text-container {
  height: 200px;
  padding: 0;
}
::v-deep .w-e-text-container p​:first-child {
  margin-top: 15px !important;
}
::v-deep .w-e-text-container p {
  margin: 8rpx;
}
.van-button--normal {
  width: 95%;
}
.van-button {
  margin: 12rpx 20rpx;
}
</style>

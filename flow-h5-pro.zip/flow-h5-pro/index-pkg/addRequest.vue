<template>
  <view>
    <van-form label-align="">
      <van-field readonly clickable name="款项用途" required v-model="useType" label="款项用途" placeholder="请点击选择款项用途" @click="useTypePicker = true" />
      <van-field readonly clickable name="选择班组" v-if="groupShow" v-model="teamGroupId" label="选择班组" placeholder="请点击选择班组" @click="groupPicker = true" />
      <van-field v-model="form.requestMoney" name="请款金额" type="number" required label="请款金额" placeholder="请填写请款金额" />
      <van-field readonly clickable name="付款方式" v-model="payType" label="付款方式" placeholder="请点击选择付款方式" @click="payTypePicker = true" />
      <!-- 收款信息 -->
      <view class="view-flex">
        <view class="">
          <text style="color: red;margin-right: 4rpx;">*</text>
          收款信息
        </view>
        <view class="text-blue" @click="selectPayee">选择收款人</view>
      </view>
      <van-field v-model="form.payeeUser" disabled name="收款人" label="收款人" placeholder="请填写收款人" />
      <van-field v-model="form.payeeAccount" disabled name="收款账号" type="digit" label="收款账号" placeholder="请填写收款账号" />
      <van-field v-model="form.payeeBank" disabled name="收款银行" label="收款银行" placeholder="请填写收款银行" />
      <van-field v-model="form.remark" border rows="3" required autosize label="请款说明" type="textarea" maxlength="100" placeholder="请输入请款说明" show-word-limit />
      <!-- 单据附件 -->
      <view class="view-flex">
        <view class="">单据附件</view>
        <view class="text-blue">
          <uni-file-picker show-recent-files="false" limit="9" file-mediatype="all" @select="selectChange"><view class="text-blue">选择文件</view></uni-file-picker>
        </view>
      </view>
      <uni-table class="mt-10" border stripe emptyText="暂无更多数据">
        <!-- 表头行 -->
        <uni-tr>
          <uni-th width="240" align="left">附件名称</uni-th>
          <uni-th width="60" align="center">操作</uni-th>
        </uni-tr>
        <!-- 表格数据行 -->
        <uni-tr v-for="item in uploadData" :key="item.id">
          <uni-td align="left">
            <text style=" word-break: break-all;">{{ item.fileName }}</text>
          </uni-td>
          <uni-td align="center"><text style="color: red;text-decoration: underline;" @click="fileRemove(item)">删除</text></uni-td>
        </uni-tr>
      </uni-table>
    </van-form>
    <!-- 保存按钮 -->
    <view class="van-contact-list__bottom"><van-button color="#666666" round size="normal" @click="onSubmit">保存请款单</van-button></view>
    <!-- 选择款项用途 -->
    <van-popup v-model="useTypePicker" position="bottom">
      <van-picker show-toolbar :columns="useTypeOption" @confirm="onUseTypeConfirm" @cancel="useTypePicker = false" />
    </van-popup>
    <!-- 付款方式 -->
    <van-popup v-model="payTypePicker" position="bottom">
      <van-picker show-toolbar :columns="payTypeOption" @confirm="onPayTypeConfirm" @cancel="payTypePicker = false" />
    </van-popup>
    <!-- 班组 -->
    <van-popup v-model="groupPicker" position="bottom"><van-picker show-toolbar :columns="groupOption" @confirm="groupConfirm" @cancel="groupPicker = false" /></van-popup>
  </view>
</template>

<script>
import { teamGroup, addApplyBill, applyBillDetail, applyBIllUpdate } from '@/api/index.js';
export default {
  data() {
    return {
      // 表单
      form: {
        payeeUser: '',
        payeeBank: '',
        payeeAccount: '',
        workerId: '',
        payType: '转账'
      },
      // 款项用途显示
      useTypePicker: false,
      useType: '',
      useTypeOption: [
        { text: '零星人工费', value: 1 },
        { text: '班组人工费', value: 2 },
        { text: '项目经理借支', value: 5 },
        { text: '零星材料费', value: 9 },
        { text: '备用金', value: 4 },
        { text: '项目外采', value: 3, disabled: true },
        { text: '项目内经费', value: 11 }
      ],
      // 付款方式显示
      payTypePicker: false,
      payType: '转账',
      payTypeOption: [{ text: '转账', value: '转账' }, { text: '现金', value: '现金' }, { text: '其他', value: '其他' }],
      // 班组显示
      groupPicker: false,
      teamGroupId: '',
      groupOption: [],
      groupShow: false,
      // 附件数据
      uploadData: [],
      // 工程ID
      projectId: undefined,
      id: undefined
    };
  },
  onLoad(option) {
    this.projectId = option.projectId;
    if (option.id) {
      this.id = option.id;
      console.log();
      this.getDetail();
    }
    this.initData();
  },
  methods: {
    // 编辑时数据回显
    async getDetail() {
      let { data } = await applyBillDetail({ id: this.id, projectId: this.projectId });
      this.form = data;
      let item = { value: this.form.useType, text: this.form.useTypeName };
      this.onUseTypeConfirm(item);
      this.payType = this.form.payType;
      this.uploadData = this.form.attachList;
      try {
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 查询班组数据
    async initData() {
      try {
        let { data } = await teamGroup({ projectId: this.projectId });
        this.groupOption = [];
        data.forEach(item => {
          this.groupOption.push({ text: item.groupName, value: item.id });
        });
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 保存请款单
    async onSubmit() {
      try {
        this.form.projectId = this.projectId;
        let attachs = [];
        this.uploadData.forEach(item => {
          attachs.push(item.url);
        });
        this.form.attachs = attachs.join(',');
        if (!this.form.id) {
          let { msg } = await addApplyBill(this.form);
          this.Toast.success(msg);
          this.reset();
        } else {
          let { msg } = await applyBIllUpdate(this.form);
          this.Toast.success(msg);
          uni.navigateBack();
        }
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 重置表单
    reset() {
      this.form = {
        payeeUser: '',
        payeeBank: '',
        payeeAccount: '',
        workerId: '',
        attachs: '',
        payType: '',
        remark: '',
        useType: '',
        requestMoney: ''
      };
      this.uploadData = [];
      this.useType = '';
      this.payType = '';
      this.groupShow = false;
      this.teamGroupId = '';
    },
    // 选择款项用途回调
    onUseTypeConfirm(item) {
      this.useType = item.text;
      this.form.useType = item.value;
      this.useTypePicker = false;
      if (item.value === 2) {
        this.groupShow = true;
      } else {
        this.groupShow = false;
      }
    },
    // 选择付款方式
    onPayTypeConfirm(item) {
      this.payType = item.text;
      this.form.payType = item.value;
      this.payTypePicker = false;
    },
    // 选择班组
    groupConfirm(item) {
      this.teamGroupId = item.text;
      this.form.teamGroupId = item.value;
      this.groupPicker = false;
    },
    // 选择收款人
    selectPayee() {
      uni.navigateTo({ url: '/index-pkg/selectPayee?projectId=' + this.projectId });
    },
    // 选择收款信息数据
    reBackData(value) {
      this.form.payeeUser = value.payeeUser;
      this.form.payeeBank = value.payeeBank;
      this.form.payeeAccount = value.payeeAccount;
      this.form.workerId = value.id;
    },
    // 选择文件上传
    selectChange(e) {
      let tempFilePaths = e.tempFilePaths;
      let upUrl;
      upUrl = window.config.apiUrl + '/upload/image/async?reqId=' + e.tempFiles[0].uuid;
      tempFilePaths.forEach((item, index) => {
        this.imageShow = true;
        let progress = 0;
        let uploadTask = uni.uploadFile({
          url: upUrl,
          fileType: 'image',
          filePath: item,
          name: 'file',
          header: {
            token: sessionStorage.getItem('satoken')
          },
          success: uploadFileRes => {
            let result = JSON.parse(uploadFileRes.data);
            let fileData = [...this.uploadData, { url: result.data.url, fileName: result.data.originalFilename, extname: result.data.ext, reqId: result.data.reqId }];
            this.uploadData = fileData;
            console.log(this.uploadData, '上传的数据！！！！！');
          },
          fail: result => {}
        });

        uploadTask.onProgressUpdate(res => {
          this.currentRate = res.progress;
          if (res.progress === 100) {
            setTimeout(() => {
              this.imageShow = false;
            }, 1300);
          }
        });
      });
    },
    // 删除文件
    fileRemove(value) {
      let fileData = [];
      fileData = this.uploadData.filter(item => {
        return item.url != value.url;
      });
      this.uploadData = fileData;
    }
  }
};
</script>

<style lang="scss" scoped>
.van-button--normal {
  width: 95%;
}
.van-button {
  margin: 12rpx 20rpx;
}
.view-flex {
  display: flex;
  justify-content: space-between;
  padding: 0 16rpx;
  margin-top: 28rpx;
  font-size: 28rpx;
  color: #646566;
  .text-blue {
    color: blue;
    text-decoration: underline;
  }
}
::v-deep .uni-file-picker__item {
  display: none;
}
::v-deep .uni-progress-bar {
  display: none;
}
::v-deep .files-border {
  border: none;
}
::v-deep .uni-file-picker__lists {
  margin-top: 0;
}
::v-deep .is-text-box {
  border-style: none !important;
}
</style>

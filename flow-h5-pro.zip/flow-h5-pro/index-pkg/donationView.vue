<template>
  <view class="gray-bj-color">
    <view class="tab5"></view>
    <van-form>
      <van-field class="project-name" v-model="form.projectName" center readonly clearable label="乐捐工程" placeholder="请选择工程">
        <template #extra>
          <van-button size="small" @click="openProject" color="#e35f24">选择工程</van-button>
        </template>
      </van-field>
      <van-field
        v-model="form.trendDate"
        @click="calendarShow = true"
        name="trendDate"
        label="处罚日期"
        placeholder="请选择处罚日期"
        :rules="[{ required: true, message: '请选择处罚日期' }]"
      />
      <van-field v-model="form.trendMoney" name="乐捐金额" oninput="value=value.replace(/[^0-9.]/g,'')" placeholder="请输入乐捐金额" label="乐捐金额">
        <template #input></template>
      </van-field>
      <QuillEditor ref="quill" :value.sync="form.trendContent" height="200px" :options="editorOptions" />
      <image-picker :fileValue.sync="fileValue" labelName="依据图片"></image-picker>
      <div style="margin: 16px;"><van-button round block type="info" @click="onSubmit" native-type="submit">提交</van-button></div>
    </van-form>

    <!-- 选择日历 -->
    <van-calendar v-model="calendarShow" :min-date="minDate" :max-date="maxDate" @confirm="dateConfirm" />

    <!-- 侧边栏 -->
    <popup-project ref="popup" @selectChange="selectChange"></popup-project>
  </view>
</template>

<script>
import { ProjectUserList, projectTrendAdd, getCfg } from '@/api/index.js';
import imagePicker from '@/components/imagePicker.vue';
import QuillEditor from '@/components/quillEditor.vue';
import popupProject from '@/index-pkg/components/popupProject.vue';
export default {
  components: {
    imagePicker,
    QuillEditor,
    popupProject
    // wfEditor
  },
  data() {
    return {
      // 表单
      form: {
        trendState: 0,
        trendContent: '',
        projectName: '',
        projectId: undefined
      },
      editorOptions: {
        modules: {
          toolbar: [
            // 可以覆盖默认工具栏配置
            ['bold', 'italic'],
            ['link', 'image']
          ]
        }
      },
      // 日历显示
      calendarShow: false,
      fileValue: [],
      minDate: new Date(2000, 0, 1),
      maxDate: new Date(),
      // 侧边栏
      // popupShow: false
    };
  },
  onLoad(option) {
    this.form.trendDate = this.formatDate(new Date());
    this.initData();
  },
  methods: {
    // 获取字典数据
    async initData() {
      try {
        setTimeout(item => {
          this.form.trendContent = '<p style="line-height: 1;">[乐捐原因]</p><p>1.</p>';
          this.$refs.quill.initData();
        }, 100);
      } catch (e) {}
    },
    // 选择工程
    openProject() {
      this.$refs.popup.popupShow = true;
    },
    // 工程回调
    selectChange(value) {
      this.form.projectId = value.id;
      this.form.projectName = value.projectName;
    },
    // 选择日历
    formatDate(date) {
      return `${date.getFullYear()}/${date.getMonth() + 1}/${date.getDate()}`;
    },
    // 选择日期
    dateConfirm(date) {
      this.calendarShow = false;
      this.form.trendDate = this.formatDate(date);
    },
    // 表单提交按钮
    async onSubmit() {
      try {
        this.form.trendType = 5;
        this.form.images = [];
        this.fileValue.forEach(item => {
          this.form.images.push(item.url);
        });
        this.form.images = this.form.images.join(',');
        let { msg } = await projectTrendAdd(this.form);
        this.Toast.success('操作成功');
        uni.navigateBack();
      } catch (e) {}
    }
  }
};
</script>

<style scoped lang="scss">
@function rpx2em($rpx) {
  @return ($rpx / 16) * 1rem;
}
.tab5 {
  height: rpx2em(5);
}
.project-name ::v-deep .van-field__control {
  width: 95%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
</style>

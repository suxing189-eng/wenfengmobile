<template>
  <view class="gray-bj-color" style="height: 100%;">
    <!-- 到期回款计划 -->
    <view class="header">
      <view class="header-item">
        <view class="header-title">应回总额</view>
        <view class="header-content">{{ totalPlanMoney }}</view>
      </view>
      <view class="header-item">
        <view class="header-title">实回总额</view>
        <view class="header-content">{{ totalRealBackMoney }}</view>
      </view>
      <view class="header-item">
        <view class="header-title">到期未回</view>
        <view class="header-content">{{ totalRemainBackMoney }}</view>
      </view>
    </view>
    <!-- 内容 工程列表-->
    <view style="background-color: #fff;"><plan-list v-for="item in dataList" :key="item.id" :item="item"></plan-list></view>
    <van-empty v-if="dataList.length === 0" description="暂无数据" />
  </view>
</template>

<script>
import { expiredBackList } from '@/api/index.js';
import planList from '@/index-pkg/components/planList.vue';
export default {
  components: {
    planList
  },
  data() {
    return {
      // 数据
      totalPlanMoney: 0,
      totalRealBackMoney: 0,
      totalRemainBackMoney: 0,
      dataList: []
    };
  },
  onLoad() {
    this.getData();
  },
  methods: {
    // 获取数据
    async getData() {
      try {
        let { data, totalPlanMoney, totalRealBackMoney, totalRemainBackMoney } = await expiredBackList();
        this.dataList = data;
        this.totalPlanMoney = totalPlanMoney || 0;
        this.totalRealBackMoney = totalRealBackMoney || 0;
        this.totalRemainBackMoney = totalRemainBackMoney || 0;
      } catch (e) {
        //TODO handle the exception
      }
    }
  }
};
</script>

<style scoped lang="scss">
@function rpx2em($rpx) {
  @return ($rpx / 16) * 1rem;
}
.header {
  background-color: #fff;
  margin-bottom: rpx2em(10);
  display: flex;
  justify-content: space-between;
  align-items: center;
  .header-item {
    flex: 0 0 33.3%;
    text-align: center;
    border: 1px solid #f5f6f8;
    border-collapse: collapse;
    .header-title {
      padding: rpx2em(10) rpx2em(5);
      border-bottom: solid 1px #f5f6f8;
      color: #646566;
      font-size: rpx2em(14);
      font-weight: 600;
    }
    .header-content {
      padding: rpx2em(20) rpx2em(5);
      font-size: rpx2em(19);
    }
  }
}
</style>

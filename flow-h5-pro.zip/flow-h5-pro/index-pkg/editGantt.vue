<template>
  <view>
    <van-cell>
      <template #title>
        <view class="flex-between" style="color: #c8c9cc;">
          <view class="title">任务名称</view>
          <view class="content">{{ info.text }}</view>
        </view>
      </template>
    </van-cell>
    <van-cell>
      <template #title>
        <view class="flex-between" style="color: #c8c9cc;">
          <view class="title">工期</view>
          <view class="content">{{ info.duration }}</view>
        </view>
      </template>
    </van-cell>
    <van-cell>
      <template #title>
        <view class="flex-between" style="color: #c8c9cc;">
          <view class="title">开始日期</view>
          <view class="content">{{ info.startDate }}</view>
        </view>
      </template>
    </van-cell>
    <van-cell>
      <template #title>
        <view class="flex-between" style="color: #c8c9cc;">
          <view class="title">状态</view>
          <view class="content">
            <view v-if="info.type === 0">未开始</view>
            <view v-if="info.type === 2">已完成</view>
            <view v-if="info.type === 1">进行中</view>
            <view v-if="info.type === 3">已逾期</view>
          </view>
        </view>
      </template>
    </van-cell>
    <van-cell>
      <template #title>
        <view class="flex-between">
          <view class="title">进度</view>
          <van-field
            v-model="info.progress"
            name="进度"
            type="digit"
            oninput="if(!/^[0-9]+$/.test(value)) value=value.replace(/\D/g,'');if(value>100)value=100;if(value<0)value=null"
            label=""
            placeholder="请输入0 ~ 100"
          />
        </view>
      </template>
    </van-cell>
    <view style="padding: 20rpx;"><van-button color="#666666" round size="normal" @click="onSubmit">更新进度</van-button></view>
  </view>
</template>

<script>
import { ganttGetById, ganttUpdate } from '@/api/index.js';
export default {
  data() {
    return {
      // id
      id: undefined,
      // 详细信息
      info: {}
    };
  },
  onLoad(option) {
    this.id = option.id;
    this.getData();
  },
  methods: {
    // 获取详情数据
    async getData() {
      try {
        let { data } = await ganttGetById({ id: this.id });
        this.info = data;
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 保存按钮
    async onSubmit() {
      try {
        let { msg } = await ganttUpdate(this.info);
        this.Toast.success(msg);
        uni.navigateBack();
      } catch (e) {
        //TODO handle the exception
      }
    }
  }
};
</script>

<style>
.flex-between {
  .title {
    text-align: center;
    flex: 0 0 160rpx;
    border-right: 1px solid #f5f6f8;
    padding: 20rpx 32rpx;
  }
  .content {
    text-align: left;
    flex: 1;
    padding: 20rpx 32rpx;
    /* background-color: #f2f3f5; */
  }
}
::v-deep .van-field__control {
  padding: 20rpx 32rpx;
}
::v-deep .van-cell {
  padding: 0;
}
.van-button--normal {
  width: 100%;
}
</style>

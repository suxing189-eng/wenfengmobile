<template>
  <view class="gray-bj-color" style="height: 100%;">
    <!-- 头部下拉 -->
    <van-dropdown-menu style="margin-bottom: 10rpx;">
      <van-dropdown-item v-model="dropdownValue" @change="dropdownChange" :title="year" :options="option" ref="datetime"></van-dropdown-item>
    </van-dropdown-menu>
    <!-- 列表展示 -->
    <van-cell value-class="van-table" title="支出合计" size="large" :value="totalMoney"></van-cell>
    <van-cell v-for="item in infoData" :key="item.monthNo">
      <template #title>
        <view class="flex-between">
          <view class="title text-blue" @click="openDetail(item)">{{ item.monthText }}</view>
          <view class="content">{{ item.monthMoney }}</view>
        </view>
      </template>
    </van-cell>
    <van-empty v-if="infoData.length === 0" description="暂无数据" />
  </view>
</template>

<script>
import { monthReport } from '@/api/index.js';
export default {
  data() {
    return {
      // 参数
      year: '2024年',
      queryYear: '',
      // 选择的年度集合
      option: [],
      dropdownValue: 0,
      // 数据
      infoData: [],
      totalMoney: 0
    };
  },
  onLoad() {
    this.year = new Date().getFullYear() + '年';
    this.queryYear = new Date().getFullYear() + '';
    // 计算显示时间
    let nowYear = new Date().getFullYear();
    this.option = [];
    // 可选择当前时间 前十年
    for (let i = 0; i < 10; i++) {
      this.option.push({ text: nowYear + '年', value: i });
      nowYear--;
    }
    this.getData();
  },
  methods: {
    // 获取数据
    async getData() {
      try {
        let { data, totalMoney } = await monthReport({ queryYear: this.queryYear });
        this.infoData = data;
        this.totalMoney = totalMoney;
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 选择回调
    dropdownChange(value) {
      let selectYear = this.option.filter(item => {
        return item.value === value;
      });
      this.year = selectYear[0].text;
      this.dropdownValue = value;
      // 传递的参数需要把'年'去掉
      this.queryYear = selectYear[0].text.slice(0, selectYear[0].text.indexOf('年'));
      this.getData();
    },
    // 进入经营费用明细
    openDetail(item) {
      uni.navigateTo({ url: '/index-pkg/manageCost?queryMonth=' + item.monthValue });
    }
  }
};
</script>

<style scoped lang="scss">
@function rpx2em($rpx) {
  @return ($rpx / 16) * 1rem;
}
.flex-between {
  .title {
    text-align: center;
    flex: 0 0 200rpx;
    border-right: 1px solid #f5f6f8;
  }
  .content {
    text-align: right;
    flex: 1;
  }
}
.van-table {
  font-weight: bold;
  color: #000;
  font-size: rpx2em(18);
}
.text-blue {
  color: #409eff;
  text-decoration: underline;
}
</style>

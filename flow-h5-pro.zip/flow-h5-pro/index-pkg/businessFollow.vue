<template>
  <view>
    <van-form @submit="onSubmit">
      <van-field
        v-model="form.followDate"
        @click="calendarShow = true"
        name="followDate"
        label="跟进日期"
        placeholder="请选择跟进日期"
        :rules="[{ required: true, message: '请选择跟进日期' }]"
      />
      <van-field
        readonly
        clickable
        name="followType"
        v-model="followTypeName"
        label="跟进节点"
        placeholder="点击选择跟进方式"
        :rules="[{ required: true, message: '请选择跟进方式' }]"
        @click="followPicker = true"
      />
      <!-- <div style="border: 1px solid #ccc;margin: 8rpx;height: 300px;">
        <Toolbar style="border-bottom: 1px solid #ccc" :editor="editor" :defaultConfig="toolbarConfig" :mode="mode" />
        <Editor style="height: 295px; overflow-y: hidden;" v-model="form.content" :defaultConfig="editorConfig" :mode="mode" @onCreated="onCreated" />
      </div> -->
      <QuillEditor :value.sync="form.content" :options="editorOptions" />
      <div style="margin: 16px;"><van-button round block type="info" native-type="submit">提交</van-button></div>
    </van-form>

    <!-- 选择日历 -->
    <van-calendar v-model="calendarShow" :min-date="minDate" :max-date="maxDate" @confirm="dateConfirm" />
    <!-- 选择跟进节点 -->
    <van-popup v-model="followPicker" position="bottom"><van-picker show-toolbar :columns="typeColumns" @confirm="typeConfirm" @cancel="followPicker = false" /></van-popup>
  </view>
</template>

<script>
import { dictList, businessFollowRecordAdd } from '@/api/index.js';
// import { Editor, Toolbar } from '@wangeditor/editor-for-vue';
// import '@wangeditor/editor/dist/css/style.css'; // wangeditor css
// import { DomEditor } from '@wangeditor/editor';
import QuillEditor from '@/components/quillEditor.vue';
export default {
  components: {
    // Editor,
    // Toolbar
    QuillEditor
  },
  data() {
    return {
      // 表单
      form: {
        followDate: '',
        content: ''
      },
      // 日历显示
      calendarShow: false,
      // 跟进节点显示
      followPicker: false,
      minDate: new Date(2000, 0, 1),
      maxDate: new Date(),
      // 节点显示
      followTypeName: '',
      typeColumns: [],
      // 富文本编辑器
      editorOptions: {
        modules: {
          toolbar: [
            // 可以覆盖默认工具栏配置
            ['bold', 'italic'],
            ['link', 'image']
          ]
        }
      },
      // editor: null,
      // html: '<p>hello</p>',
      // toolbarConfig: {
      //   toolbarKeys: []
      // },
      // editorConfig: { placeholder: '请输入跟进内容...', maxLength: 500 },
      // mode: 'default', // or 'simple'
      businessId: undefined
    };
  },
  onLoad(option) {
    // console.log(1);
    // let data = Date.now() - 3600 * 24 * 28 * 1000
    // console.log(this.util.dateFormat('yyyy-mm-dd', new Date(data)));
    this.businessId = option.businessId;
    this.initData();
  },
  created() {
    this.form.followDate = this.util.dateFormat('yyyy-mm-dd', new Date());
    // this.minDate =
  },
  methods: {
    // 获取字典数据
    async initData() {
      try {
        this.typeColumns = [];
        let { data } = await dictList({ dictType: 'customer_follow_type' });
        data.forEach(item => {
          this.typeColumns.push({ text: item.dictLabel, value: item.dictValue });
        });
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 保存按钮
    async onSubmit() {
      try {
        this.form.businessId = this.businessId;
        let { data, msg } = await businessFollowRecordAdd(this.form);
        this.Toast.success(msg);
        uni.navigateBack();
      } catch (e) {
        //TODO handle the exception
      }
    },
    //选择跟进节点
    typeConfirm(value) {
      this.form.followType = value.value;
      this.followTypeName = value.text;
      this.followPicker = false;
    },
    // 选择日历
    formatDate(date) {
      console.log('选择的时间==============》', date);
      return `${date.getFullYear()}/${date.getMonth() + 1}/${date.getDate()}`;
    },
    // 选择日期
    dateConfirm(date) {
      this.calendarShow = false;
      this.form.followDate = this.formatDate(date);
    },
    onCreated(editor) {
      this.editor = Object.seal(editor); // 一定要用 Object.seal() ，否则会报错
    }
  }
};
</script>

<style scoped lang="scss">
::v-deep #w-e-textarea-1 {
  padding: 0;
}
::v-deep .w-e-text-container {
  height: 300px;
  padding: 0;
}
::v-deep .w-e-text-container p​:first-child {
  margin-top: 15px !important;
}
::v-deep .w-e-text-container p {
  margin: 8rpx;
}
</style>

<template>
  <view class="gray-bj-color" style="height: 100%;">
    <!-- 甘特图 -->
    <van-pull-refresh v-model="isLoading" @refresh="refresh">
      <van-dropdown-menu><van-dropdown-item :title="statusText" v-model="type" :options="stateOption" @change="dropownChange"></van-dropdown-item></van-dropdown-menu>
      <!-- 内容 -->
      <view style="margin-top: 10px;overflow: auto;height: calc(100vh - 194rpx)">
        <van-cell v-for="(item, index) in ganttData" :key="item.id" @click="editGantt(item)">
          <template #title>
            <view class="text-padding">
              <van-tag v-if="item.nodeLevel === 1" color="#c9c9ca" style="margin-right: 16rpx;">一级</van-tag>
              <van-tag v-if="item.nodeLevel === 2" color="#c9c9ca" style="margin-right: 16rpx;">二级</van-tag>
              <van-tag v-if="item.nodeLevel === 3" color="#c9c9ca" style="margin-right: 16rpx;">三级</van-tag>
              <text class="text-nowrap" style="font-weight: 600;width: 520rpx;">{{ item.text }}</text>
            </view>
          </template>
          <template #label>
            <view class="flex-between text-padding">
              <view class="">{{ `工期: ${item.duration} 天` }}</view>
              <view class="">{{ `开始日期: ${item.startDate}` }}</view>
              <view v-if="item.type === 0">未开始</view>
              <view v-if="item.type === 2" style="color:#07c160;">已完成</view>
              <view v-if="item.type === 1" style="color:#E6A23C;">进行中</view>
              <view v-if="item.type === 3" style="color:#ee0a24;">已逾期</view>
            </view>
            <view class="text-padding" style="padding-top: 12px;">
              <view style="display: inline;"><van-progress :percentage="item.progress * 100" stroke-width="5" /></view>
            </view>
          </template>
        </van-cell>
      </view>
    </van-pull-refresh>
  </view>
</template>

<script>
import { ganttList } from '@/api/index.js';
export default {
  data() {
    return {
      // 工程ID
      projectId: 0,
      ganttData: [],
      isLoading: false,
      // 查询类型
      type: '-1',
      statusText: '',
      // 状态集合
      stateOption: [{ text: '全部', value: '-1' }, { text: '未开始', value: '0' }, { text: '进行中', value: '1' }, { text: '已完成', value: '2' }, { text: '已逾期', value: '3' }]
    };
  },
  onShow() {
    this.getData();
  },
  onLoad(option) {
    this.projectId = option.id;
  },
  methods: {
    // 获取页面数据
    async getData() {
      this.isLoading = false;
      let { data } = await ganttList({ projectId: this.projectId, type: this.type });
      this.ganttData = data;
    },
    // 刷新
    refresh() {
      this.ganttData = [];
      this.getData();
    },
    // 下拉回调
    dropownChange(value) {
      let state = this.stateOption.filter(item => {
        return item.value === value;
      });
      this.statusText = state[0].text;
      this.type = value;
      this.refresh();
    },
    // 编辑甘特图
    editGantt(item) {
      uni.navigateTo({ url: '/index-pkg/editGantt?id=' + item.id });
    }
  }
};
</script>

<style scoped lang="scss">
::v-deep .van-progress__pivot {
  min-width: 3.5em;
  line-height: 1.3;
}
</style>

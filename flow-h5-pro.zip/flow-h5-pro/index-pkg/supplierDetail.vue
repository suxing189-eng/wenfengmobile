<template>
  <view class="gray-bj-color" style="height: calc(100vh - 88rpx);">
    <van-tabs v-model="active" sticky offset-top="44px" @change="tabChange" title-inactive-color="#666666" title-active-color="#000">
      <van-tab title="送货工程">
        <!-- 下拉刷新 -->
        <van-pull-refresh v-model="isLoading" @refresh="onRefresh">
          <view class="tab"></view>
          <project-view :list="list"></project-view>
        </van-pull-refresh>
      </van-tab>
      <van-tab title="外采合同">
        <van-pull-refresh v-model="isLoading" @refresh="onRefresh">
          <view class="tab"></view>
          <purchase-detail v-for="item in list" :key="item.id" :item="item"></purchase-detail>
          <!-- 暂无数据 -->
          <van-empty v-if="list.length === 0" description="暂无数据" />
        </van-pull-refresh>
      </van-tab>
      <van-tab title="分包合同">
        <van-pull-refresh v-model="isLoading" @refresh="onRefresh">
          <view class="tab"></view>
          <purchase-detail v-for="item in list" :key="item.id" :item="item"></purchase-detail>
          <!-- 暂无数据 -->
          <van-empty v-if="list.length === 0" description="暂无数据" />
        </van-pull-refresh>
      </van-tab>
    </van-tabs>
  </view>
</template>

<script>
import projectView from './components/projectView.vue';
import purchaseDetail from './components/purchaseDetail.vue';
import { supplierProject, supplierContract } from '../api/index.js';
export default {
  components: {
    projectView,
    purchaseDetail
  },
  data() {
    return {
      supplierId: undefined,
      isLoading: false,
      active: 0,
      // 数据
      list: []
    };
  },
  onLoad(option) {
    this.supplierId = option.supplierId;
    this.getData();
  },
  methods: {
    // 获取数据
    async getData() {
      try {
        if (this.active === 0) {
          let { data } = await supplierProject({ supplierId: this.supplierId });
          this.list = data;
          this.isLoading = false;
        } else if (this.active === 1) {
          let { data } = await supplierContract({ supplierId: this.supplierId, category: 3 });
          this.list = data;
          this.isLoading = false;
        } else {
          let { data } = await supplierContract({ supplierId: this.supplierId, category: 2 });
          this.list = data;
          this.isLoading = false;
        }
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 切换tab回调
    tabChange() {
      this.getData();
    },
    // 下拉刷新
    onRefresh() {
      this.getData();
    }
  }
};
</script>

<style scoped lang="scss">
.van-empty {
  padding: 40rpx 0;
}
::v-deep .van-pull-refresh {
  height: calc(100vh - 160rpx);
  overflow: auto;
}
</style>

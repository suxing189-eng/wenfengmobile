<template>
  <view class="gray-bj-color">
    <!-- 头部下拉 -->
    <van-dropdown-menu style="margin-bottom: 10rpx;">
      <van-dropdown-item v-model="dropdownValue" @change="dropdownChange" :title="year" :options="option" ref="datetime"></van-dropdown-item>
    </van-dropdown-menu>
    <!-- 内容 -->
    <view v-for="item in profitData" :key="item.quarterName" class="mb-10">
      <van-cell style="font-weight: bold;" :title="item.quarterName" />
      <van-cell title="A.含税合同额" :value="item.totalContractMoney" />
      <van-cell title="B.税后合同额" :value="item.totalExcludeTaxesMoney" />
      <van-cell title="C.已回款" :value="item.totalRealBackMoney" />
      <van-cell title="D.未回款" :value="item.totalRemainBackMoney" />
      <van-cell title="E.工程支出" :value="item.totalPaidMoney" />
      <van-cell title="F.经营支出" :value="item.totalCostMoney" />
      <van-cell title="G.预估毛利润" :value="item.predictGrossProfit" />
      <van-cell title="H.毛利润" :value="item.grossProfit" />
      <van-cell title="J.回款利润" :value="item.contractProfit" />
      <van-cell title="K.营业利润" :value="item.operatingProfit" />
    </view>
  </view>
</template>

<script>
import { profitList } from "@/api/index.js"
export default {
  data() {
    return {
      // 参数
      year: '2024年',
      queryYear: '',
      // 选择的年度集合
      option: [],
      dropdownValue: 0,
      // 列表数据
      profitData: []
    };
  },
  onLoad() {
    this.year = new Date().getFullYear() + '年';
    this.queryYear = new Date().getFullYear() + '';
    // 计算显示时间
    let nowYear = new Date().getFullYear();
    this.option = [];
    // 可选择当前时间 前十年
    for (let i = 0; i < 10; i++) {
      this.option.push({ text: nowYear + '年', value: i });
      nowYear--;
    }
    this.getData();
  },
  methods: {
    // 获取列表数据
    async getData() {
      try{
        let { data } = await profitList({ queryYear: this.queryYear });
        this.profitData = data.quarterList;
      }catch(e){
        //TODO handle the exception
      }
    },
    // 选择回调
    dropdownChange(value) {
      let selectYear = this.option.filter(item => {
        return item.value === value;
      });
      this.year = selectYear[0].text;
      this.dropdownValue = value;
      // 传递的参数需要把'年'去掉
      this.queryYear = selectYear[0].text.slice(0, selectYear[0].text.indexOf('年'));
      this.getData();
    }
  }
};
</script>

<style scoped lang="scss">
.flex-between {
  .title {
    text-align: center;
    flex: 0 0 200rpx;
    border-right: 1px solid #f5f6f8;
  }
  .content {
    text-align: right;
    flex: 1;
  }
}
.van-table {
  font-weight: bold;
  color: #000;
  font-size: 32rpx;
}
.text-blue {
  color: #409eff;
  text-decoration: underline;
}
</style>

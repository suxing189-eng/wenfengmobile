<template>
  <view class="gray-bj-color-polling">
    <!-- 内容 -->
    <van-form class="">
      <van-field class="project-name" v-model="form.projectName" center readonly clearable label="巡检工程" placeholder="请选择工程">
        <template #extra>
          <van-button class="ml-5" size="small" @click="openProject" color="#e35f24">选择工程</van-button>
        </template>
      </van-field>
      <van-field
        v-model="form.trendDate"
        @click="calendarShow = true"
        name="trendDate"
        label="巡检日期"
        placeholder="请选择巡检日期"
        :rules="[{ required: true, message: '请选择巡检日期' }]"
      />
    </van-form>

    <van-tabs v-model="pollingTab" class="mt-5">
      <van-tab title="巡检节点">
        <!-- 巡检节点 -->
        <view class="grid-box mt-5">
          <view class="grid-item" :class="selectIndex === index ? 'grid-orange' : ''" v-for="(item, index) in pollingList" :key="item.id" @click="tabDetail(index, item)">
            <text :class="selectIndex === index ? 'grid-orange' : ''">{{ item.nodeName }}</text>
          </view>
        </view>

        <!-- 内容 -->
        <view class="mt-10 content">
          <!-- <van-cell class="cell-name" v-for="(item, index) in optionList" :key="item.id">
            <template #title>
              <view class="text-title">{{ `${index + 1}. ${item.content}` }}</view>
            </template>
            <template #label>
              <van-radio-group @change="radioChange(item)" v-model="item.state" direction="horizontal">
                <van-radio :name="1">合格</van-radio>
                <van-radio :name="0">不合格</van-radio>
                <van-radio :name="2">不检查</van-radio>
              </van-radio-group>
            </template>
          </van-cell>
          <van-empty v-if="optionList.length === 0" description="暂无内容项" /> -->
          <!-- 列表 -->
          <uni-table border :stripe="false" emptyText="暂无内容项">
            <!-- 表头行 -->
            <uni-tr>
              <uni-th class="table-th" align="center"></uni-th>
              <uni-th width="400" align="center"></uni-th>
            </uni-tr>
            <!-- 表格数据行 -->
            <uni-tr v-for="item in optionList" :key="item.id">
              <uni-td class="table-th" width="230" align="center">
                <van-radio-group @change="radioChange(item)" v-model="item.state" direction="horizontal">
                  <van-radio :name="1">合格</van-radio>
                  <van-radio :name="0">不合格</van-radio>
                  <van-radio :name="2">不检查</van-radio>
                </van-radio-group>
              </uni-td>
              <uni-td align="left" min-width="600">{{ item.content }}</uni-td>
            </uni-tr>
          </uni-table>
        </view>
      </van-tab>
      <van-tab title="巡检图片">
        <image-picker class="mt-5" :fileValue.sync="fileValue" labelName="巡检图片"></image-picker>
        <!-- 补充说明 -->
        <view class="remark">补充说明</view>
        <van-field class="mt-5" v-model="trendContent" rows="3" autosize label="" type="textarea" placeholder="请输入补充说明" />
      </van-tab>
    </van-tabs>

    <!-- 按钮 -->
    <view class="van-contact-list__bottom">
      <view class="state" @click="openDetail">{{ `已巡检: ${accomplishList.length}项` }}</view>
      <van-button color="#e35f24" class="share" size="normal" @click="handleSubmit">提交本次巡检</van-button>
    </view>

    <!-- 选择日历 -->
    <van-calendar v-model="calendarShow" :min-date="minDate" :max-date="maxDate" @confirm="dateConfirm" />
    <!-- 侧边栏 -->
    <popup-project class="project-popup" ref="popup" @selectChange="selectChange"></popup-project>

    <!-- 底部弹出 -->
    <van-popup v-model="contentShow" :style="{ maxHeight: '70%' }" position="bottom">
      <view class="content">
        <!-- 列表 -->
        <uni-table border :stripe="false" emptyText="暂无内容项">
          <!-- 表头行 -->
          <uni-tr>
            <uni-th class="table-th" width="150" align="center"></uni-th>
            <uni-th width="400" align="center"></uni-th>
          </uni-tr>
          <!-- 表格数据行 -->
          <uni-tr v-for="item in accomplishList" :key="item.id">
            <uni-td class="table-th" width="70" align="center">
              <text v-if="item.state === 1" style="color: #07c160;">合格</text>
              <text v-else style="color: red;">不合格</text>
            </uni-td>
            <uni-td align="left" width="400">{{ item.content }}</uni-td>
          </uni-tr>
        </uni-table>
      </view>
    </van-popup>
  </view>
</template>

<script>
import { trendNode, getOptionList, projectTrendSave } from '@/api/index.js';
import popupProject from '@/index-pkg/components/popupProject.vue';
import imagePicker from '@/components/imagePicker.vue';
export default {
  components: {
    popupProject,
    imagePicker
  },
  data() {
    return {
      // 巡检节点
      pollingList: [],
      // 表单
      form: {
        trendState: 0,
        projectName: '',
        projectId: undefined,
        images: []
      },
      // 日历显示
      calendarShow: false,
      minDate: new Date(2000, 0, 1),
      maxDate: new Date(),
      // 选择的节点
      selectIndex: 0,
      // 题目集合
      optionList: [],
      // 完成题目集合
      accomplishList: [],
      // 保存已经请求过的数据
      oldList: new Map(),
      // 底部弹出窗
      contentShow: false,
      pollingTab: 0,
      fileValue: [],
      // 补充说明
      trendContent: ''
    };
  },
  onLoad(option) {
    this.form.trendDate = this.formatDate(new Date());
    this.initData();
  },
  methods: {
    // 页面初始化
    async initData() {
      try {
        this.optionList = [];
        let { data, optionList, hasNode } = await trendNode();
        if (hasNode === 0) {
          this.Dialog.alert({
            title: '提示',
            message: '暂无巡检节点，请联系管理员!'
          }).then(() => {
            uni.navigateBack();
          });
        }
        this.pollingList = data;
        // 添加状态字段
        optionList.forEach(item => {
          item.state = 2;
          this.optionList.push(item);
        });
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 选择工程
    openProject() {
      this.$refs.popup.popupShow = true;
    },
    // 工程回调
    selectChange(value) {
      this.form.projectId = value.id;
      this.form.projectName = value.projectName;
    },
    // 选择日历
    formatDate(date) {
      return `${date.getFullYear()}/${date.getMonth() + 1}/${date.getDate()}`;
    },
    // 选择日期
    dateConfirm(date) {
      this.calendarShow = false;
      this.form.trendDate = this.formatDate(date);
    },
    // 选择节点
    tabDetail(index, item) {
      // 当页面第一次进来 oldList为空时 把第一次数据添加
      if (this.oldList.size === 0) {
        this.oldList.set(this.pollingList[0].id, this.optionList);
        this.getOption(item);
        // console.log(this.oldList, '第一次保存数据');
      } else {
        // 通过选择节点的id去判断 保存旧数据的map中是否存在 不存在就发起请求 存在就去map中获取 获取数据后在存入map中
        if (this.oldList.has(item.id)) {
          // console.log('已经拥有');
          this.optionList = this.oldList.get(item.id);
        } else {
          // console.log('没有');
          this.getOption(item);
        }
      }
      this.selectIndex = index;
    },
    // 获取节点内容项
    async getOption(item) {
      try {
        this.optionList = [];
        let { data } = await getOptionList({ trendId: item.id });
        data.forEach(item => {
          item.state = 2;
          this.optionList.push(item);
        });
        // 获取数据后在存入map中
        this.oldList.set(item.id, this.optionList);
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 选择内容项
    radioChange(value) {
      if (this.accomplishList.length > 0) {
        // 使用函数处理 判断如果状态为不检查（state: 2）将数据从accomplishList删除， 如果(state 0 1)就把数据添加到accomplishList中
        this.accomplishList = this.upsertObjectById(this.accomplishList, value);
        // console.log('过滤对比完', this.accomplishList);
      } else {
        this.accomplishList.push(value);
        // console.log('第一次进来', this.accomplishList);
      }
    },
    // 处理数据函数
    upsertObjectById(arr, newObj) {
      if (newObj.state === 2) {
        const map = new Map(arr.map(obj => [obj.id, obj]));
        map.delete(newObj.id);
        return Array.from(map.values());
      } else {
        const map = new Map(arr.map(obj => [obj.id, obj]));
        map.set(newObj.id, newObj);
        return Array.from(map.values());
      }
    },
    // 查看完成题目详情
    openDetail() {
      this.contentShow = !this.contentShow;
    },
    // 表单提交按钮
    async handleSubmit() {
      try {
        let images = [];
        this.fileValue.forEach(item => {
          images.push(item.url);
        });
        let resultList = [];
        this.accomplishList.forEach(item => {
          resultList.push({ id: item.id, state: item.state });
        });
        this.form.images = images.join(',');
        this.form.trendContent = this.trendContent;
        this.form.resultList = JSON.stringify(resultList);
        let { msg } = await projectTrendSave(this.form);
        this.Toast.success('操作成功');
        uni.navigateBack();
      } catch (e) {
        //TODO handle the exception
      }
    }
  }
};
</script>

<style scoped lang="scss">
@function rpx2em($rpx) {
  @return ($rpx / 16) * 1rem;
}
.remark {
  color: #646566;
  margin: rpx2em(10) 0 0 rpx2em(5);
  font-size: rpx2em(15);
}
.project-name ::v-deep .van-field__control {
  width: 95%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.grid-box {
  background-color: #fff;
  display: flex;
  flex-wrap: wrap;
  box-sizing: border-box;
  .grid-item {
    border: rpx2em(1) solid #f6f7f8;
    border-collapse: collapse;
    margin-right: rpx2em(-1); /* 右边框重叠 */
    margin-bottom: rpx2em(-1); /* 下边框重叠 */
    box-sizing: border-box;
    flex: 0 0 20%;
    // flex: 0 0 calc(25% - 19px);
    padding: rpx2em(10) rpx2em(8);
    text-align: center;
    line-height: 1.5;
    font-size: rpx2em(12);
    color: #646566;
  }
}
.grid-orange {
  background-color: #e35f24;
  color: #fff;
}

::v-deep .van-contact-list__bottom {
  padding: 0;
  z-index: 8888;
}
.van-contact-list__bottom {
  display: flex;
  justify-content: space-between;
  .state {
    flex: 0 0 50%;
    box-sizing: border-box;
    padding-left: rpx2em(10);
    line-height: rpx2em(44);
    font-size: rpx2em(18);
    color: #1989fa;
    text-decoration: underline;
    font-weight: bolder;
  }
  .share {
    flex: 0 0 50%;
  }
}
@media (min-width: 768px) {
  .van-contact-list__bottom {
    .state {
      height: rpx2em(30);
      line-height: rpx2em(30);
    }
  }
}
.content {
  padding-bottom: rpx2em(60);
}
.content ::v-deep .van-cell {
  padding: rpx2em(6) rpx2em(16);
}
::v-deep .van-cell__label {
  margin-top: rpx2em(0);
}
.text-title {
  color: #666666;
  font-size: rpx2em(12);
  padding: rpx2em(4) rpx2em(0);
}
::v-deep .van-cell__label {
  font-size: rpx2em(12);
}
::v-deep .van-radio--horizontal {
  margin-right: rpx2em(8);
}
.van-radio-group--horizontal {
  flex-wrap: nowrap;
}
::v-deep .van-radio__label {
  margin-left: rpx2em(4);
  text-wrap: nowrap;
}
@media (min-width: 680px) and (max-width: 1024px) {
  .uni-table-td {
    font-size: 14px;
    line-height: 32px;
  }
  .uni-table-th {
    display: none !important;
  }

  .van-radio__label {
    text-wrap: nowrap;
  }
}
.uni-table-th {
  display: none !important;
}
</style>

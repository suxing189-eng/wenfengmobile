<template>
  <view class="gray-bj-color-44">
    <van-tabs v-model="active" sticky offset-top="44px" @change="tabChange" title-inactive-color="#666666" title-active-color="#000">
      <van-tab title="我的工程">
        <van-search class="mt-10" v-model="queryParams.searchValue" @search="changeSearch" :clearable="false" placeholder="请输入搜索关键词" />
        <van-list v-model="loading" :finished="finished" :finished-text="finishedText" @load="upwardPull"><project-view :list="list"></project-view></van-list>
      </van-tab>
      <van-tab title="在建工程">
        <van-search class="mt-10" show-action v-model="queryParams.searchValue" @search="changeSearch" :clearable="false" placeholder="请输入搜索关键词">
          <template #action>
            <van-icon style="font-size: 32rpx;" @click="openQuery" name="filter-o" />
          </template>
        </van-search>
        <project-view :list="list"></project-view>
      </van-tab>
      <!-- <van-tab title="待验收工程">
        <project-view v-if="perList.includes('project:view:dysgc')" class="mt-10" :list="list"></project-view>
        <van-empty v-else description="暂无权限" />
      </van-tab>
      <van-tab title="待核算工程">
        <project-view v-if="perList.includes('project:view:dhsgc')" class="mt-10" :list="list"></project-view>
        <van-empty v-else description="暂无权限" />
      </van-tab>
      <van-tab title="待结算工程">
        <project-view v-if="perList.includes('project:view:djsgc')" class="mt-10" :list="list"></project-view>
        <van-empty v-else description="暂无权限" />
      </van-tab>
      <van-tab title="应收款工程">
        <van-search class="mt-10" v-model="queryParams.searchValue" @search="changeSearch" :clearable="false" placeholder="请输入搜索关键词" />
        <project-view v-if="perList.includes('project:view:ysjdk')" :list="list"></project-view>
        <van-empty v-else description="暂无权限" />
      </van-tab> -->
      <van-tab title="所有工程">
        <view v-if="perList.includes('project:view:all')">
          <van-search class="mt-10" v-model="queryParams.searchValue" @search="changeSearch" :clearable="false" placeholder="请输入搜索关键词" />
          <van-list v-model="loading" :finished="finished" :finished-text="finishedText" @load="upwardPull"><project-view :list="list"></project-view></van-list>
        </view>
        <van-empty v-else description="暂无权限" />
      </van-tab>
    </van-tabs>

    <!-- 右侧弹出筛选 -->
    <van-popup v-model="popupShow" position="right">
      <view class="popup-box">
        <!-- 标签筛选条件 -->
        <view class="popup-item">
          <!-- 标题 -->
          <view class="popup-title">标 签</view>
          <!-- 标签选项 -->
          <view class="popup-content">
            <view
              v-for="(item, index) in projectLabelOption"
              @click="selectProjectLabel(item, index)"
              :key="item.value"
              :class="projectLabelIndex === index ? 'select-item' : ''"
              class="content-item"
            >
              {{ item.label }}
            </view>
          </view>

          <!-- 施工状态 -->
          <view class="popup-title" style="margin-top: 20rpx;">施工状态</view>
          <!-- 施工状态选项 -->
          <view class="popup-content">
            <view
              v-for="(item, index) in buildStatus"
              @click="selectProjectState(item, index)"
              :key="item.value"
              :class="projectStateIndex === index ? 'select-item' : ''"
              class="content-item"
            >
              {{ item.label }}
            </view>
          </view>
        </view>
        <!-- 按钮 -->
        <view class="van-contact-list__bottom">
          <van-button type="default" class="state" size="normal" @click="reset">重置</van-button>
          <van-button type="info" class="share" size="normal" @click="handle">确定</van-button>
        </view>
      </view>
    </van-popup>
  </view>
</template>

<script>
import { mineProject, allProject, buildingList, overdueList, stateList } from '@/api/index.js';
import projectView from './components/projectView.vue';
import { mapState } from 'vuex';
export default {
  components: {
    projectView
  },
  data() {
    return {
      // 请求数据参数
      queryParams: {
        pageNo: 0,
        pageSize: 10,
        searchValue: ''
      },
      // 下拉状态
      loading: false,
      // 是否已加载完成
      finished: false,
      active: 0,
      // 工程数据
      list: [],
      // 加载完成文字
      finishedText: '没有更多了',
      // 待验收1/待核算2/待结算3工程
      queryState: 1,
      perList: [],
      // 筛选弹出显示
      popupShow: false,
      projectLabelOption: [
        { value: '', label: '全部' },
        { value: 'A类', label: 'A类', remark: '优质客户金额大工期紧100W以上' },
        { value: 'B类', label: 'B类', remark: '50W - 100W重点工程' },
        { value: 'C类', label: 'C类', remark: '10W - 50W的常规工程' },
        { value: 'D类', label: 'D类', remark: '10万以内的小工程' },
        { value: 'E类', label: 'E类', remark: '零星|改造|维保等项目' }
      ],
      // 标签Index
      projectLabelIndex: 0,
      // 标签Value
      projectLabel: '',
      // 施工状态
      buildStatus: [
        { value: -1, label: '全部' },
        { value: 0, label: '待开工' },
        { value: 1, label: '施工中' },
        { value: 2, label: '待验收' },
        { value: 3, label: '停工中' },
        { value: 4, label: '已完工' }
      ],
      // 施工状态Index
      projectStateIndex: 0,
      // 施工状态
      projectState: -1
    };
  },
  computed: {
    // ...mapState('user',['perList'])
  },
  created() {
    this.perList = sessionStorage.getItem('perList');
  },
  methods: {
    // 筛选图标
    openQuery() {
      this.popupShow = true;
    },
    // 选择标签
    selectProjectLabel(item, index) {
      this.projectLabelIndex = index;
      this.projectLabel = item.value;
    },
    // 选择施工状态
    selectProjectState(item, index) {
      this.projectStateIndex = index;
      this.projectState = item.value;
    },
    // 重置按钮
    reset() {
      this.projectLabelIndex = 0;
      this.projectLabel = '';
      this.projectStateIndex = 0;
      this.projectState = -1;
      this.popupShow = false;
      this.buildingData();
    },
    // 确定按钮
    handle() {
      this.popupShow = false;
      this.buildingData();
    },
    // 获取工程列表
    getData() {
      try {
        if (this.active === 0 || this.active === 2) {
          // 我的工程/所有工程
          this.mineData();
        } else if (this.active === 1) {
          // 在建工程
          this.buildingData();
        } else {
          return;
        }
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 我的工程/所有工程 数据
    async mineData() {
      try {
        if (this.active === 0) {
          // 我的工程
          let { data, dataCount } = await mineProject(this.queryParams);
          this.list = this.list.concat(data);
          this.loading = false;
          // 判断是否已经全部加载完成
          this.allLoading(dataCount);
        } else {
          // 所有工程
          let { data, dataCount } = await allProject(this.queryParams);
          this.list = this.list.concat(data);
          this.loading = false;
          // 判断是否已经全部加载完成
          this.allLoading(dataCount);
        }
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 在建工程
    async buildingData() {
      try {
        let { data } = await buildingList({ searchValue: this.queryParams.searchValue, projectLabel: this.projectLabel, projectState: this.projectState });
        this.list = data;
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 应收款工程
    async overdueData() {
      try {
        let { data } = await overdueList({ searchValue: this.queryParams.searchValue });
        this.list = data;
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 待验收/待核算/待结算工程
    async stateData() {
      try {
        this.queryState = this.active === 2 ? 1 : this.active === 3 ? 2 : 3;
        let { data } = await stateList({ queryState: this.queryState });
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 判断全部加载完成
    allLoading(dataCount) {
      // console.log(dataCount);
      if (this.queryParams.pageNo * this.queryParams.pageSize > dataCount) {
        this.finished = true;
      } else {
        this.finished = false;
      }
      if (dataCount === 0) {
        this.finishedText = '';
      } else {
        this.finishedText = '没有更多了';
      }
    },

    // 上拉回调
    upwardPull() {
      this.queryParams.pageNo += 1;
      this.getData();
    },
    // 查询
    changeSearch() {
      this.queryParams.pageNo = 1;
      this.list = [];
      this.getData();
    },
    // tab回调函数
    tabChange() {
      this.queryParams.pageNo = 1;
      this.queryParams.searchValue = '';
      this.list = [];
      this.getData();
    }
  }
};
</script>

<style scoped lang="scss">
::v-deep .van-search__action {
  padding: 10rpx 32rpx;
  font-size: 36rpx;
}
.popup-box {
  width: calc(100vw - 70rpx);
  height: 100vh;
  background: #f2f2f2;
  .popup-item {
    background-color: #fff;
    padding: 30rpx 20rpx 10rpx 20rpx;
    .popup-title {
      font-weight: 600;
    }
    .popup-content {
      display: flex;
      // justify-content: space-around;
      flex-wrap: wrap;
      .content-item {
        width: 176rpx;
        height: 58rpx;
        background-color: #f2f2f2;
        margin: 14rpx;
        line-height: 58rpx;
        text-align: center;
        border-radius: 10rpx;
        color: #191919;
        font-size: 24rpx;
        border: 1rpx solid #f2f2f2;
      }
      .select-item {
        border: 1rpx solid #d6432e;
        background-color: #f7d8d5;
        color: #d6432e;
      }
    }
  }
}
.van-contact-list__bottom {
  display: flex;
  & > .state {
    width: 50%;
  }
  & > .share {
    flex: 1;
  }
}
::v-deep .van-contact-list__bottom {
  padding: 0;
}
</style>

<template>
  <view class="gray-bj-color-44">
    <!-- 内容 -->
    <van-form>
      <van-field class="project-name" v-model="form.projectName" center readonly clearable label="整改工程" placeholder="请选择工程">
        <template #extra>
          <van-button size="small" @click="openProject" color="#e35f24">选择工程</van-button>
        </template>
      </van-field>
      <van-field
        v-model="form.trendDate"
        @click="calendarShow = true"
        name="trendDate"
        label="巡检日期"
        placeholder="请选择巡检日期"
        :rules="[{ required: true, message: '请选择巡检日期' }]"
      />
      <QuillEditor ref="quill" :value.sync="form.trendContent" height="200px" :options="editorOptions" />
      <image-picker :fileValue.sync="fileValue" labelName="巡检图片"></image-picker>
      <div style="margin: 16px;">
        <van-button round block type="info" @click="onSubmit" native-type="submit">{{ textBtn }}</van-button>
      </div>
    </van-form>

    <!-- 选择日历 -->
    <van-calendar v-model="calendarShow" :min-date="minDate" :max-date="maxDate" @confirm="dateConfirm" />

    <!-- 侧边栏 -->
    <popup-project ref="popup" @selectChange="selectChange"></popup-project>
  </view>
</template>

<script>
import { ProjectUserList, projectTrendAdd, getCfg } from '@/api/index.js';
import imagePicker from '@/components/imagePicker.vue';
import QuillEditor from '@/components/quillEditor.vue';
import popupProject from '@/index-pkg/components/popupProject.vue';
export default {
  components: {
    imagePicker,
    QuillEditor,
    popupProject
  },
  data() {
    return {
      // 表单
      form: {
        trendState: 1,
        trendContent: '',
        projectName: '',
        projectId: undefined
      },
      editorOptions: {
        modules: {
          toolbar: [
            // 可以覆盖默认工具栏配置
            ['bold', 'italic'],
            ['link', 'image']
          ]
        }
      },
      // 日历显示
      calendarShow: false,
      fileValue: [],
      minDate: new Date(2000, 0, 1),
      maxDate: new Date(),
      trendContent: '',
      // 提交按钮文本
      textBtn: '提交整改单'
      // 侧边栏
      // popupShow: false
    };
  },
  onLoad(option) {
    this.form.trendDate = this.formatDate(new Date());
    this.initData();
  },
  methods: {
    // 获取字典数据
    initData() {
      try {
        // let { data: cfgData } = await getCfg({ cfgName: 'patrol_tpl' });
        // this.trendContent = cfgData;
        // this.form.trendContent = cfgData;
        this.form.trendContent = '<p style="line-height: 1;">[整改原因]</p><p>1.</p>';
        this.$refs.quill.initData();
      } catch (e) {}
    },
    // 选择工程
    openProject() {
      this.$refs.popup.popupShow = true;
    },
    // 工程回调
    selectChange(value) {
      this.form.projectId = value.id;
      this.form.projectName = value.projectName;
    },
    // 选择日历
    formatDate(date) {
      return `${date.getFullYear()}/${date.getMonth() + 1}/${date.getDate()}`;
    },
    // 选择日期
    dateConfirm(date) {
      this.calendarShow = false;
      this.form.trendDate = this.formatDate(date);
    },
    // 表单提交按钮
    async onSubmit() {
      try {
        this.form.trendType = 3;
        this.form.images = [];
        this.fileValue.forEach(item => {
          this.form.images.push(item.url);
        });
        this.form.images = this.form.images.join(',');
        let { msg } = await projectTrendAdd(this.form);
        this.Toast.success('操作成功');
        uni.navigateBack();
      } catch (e) {}
    }
  }
};
</script>

<style scoped lang="scss">
.project-name ::v-deep .van-field__control {
  width: 95%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
</style>

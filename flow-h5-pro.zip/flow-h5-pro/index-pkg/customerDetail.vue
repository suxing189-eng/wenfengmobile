<template>
  <view class="gray-bj-color" style="height: calc(100vh - 88rpx);">
    <van-tabs v-model="active" sticky offset-top="44px" @change="tabChange" title-inactive-color="#666666" title-active-color="#000">
      <van-tab title="签单工程">
        <!-- 下拉刷新 -->
        <van-pull-refresh v-model="isLoading" @refresh="onRefresh">
          <view class="tab"></view>
          <project-view :list="list"></project-view>
        </van-pull-refresh>
      </van-tab>
    </van-tabs>
  </view>
</template>

<script>
import { customerProjectList } from '@/api/index.js';
import projectView from './components/projectView.vue';
export default {
  components: {
    projectView
  },
  data() {
    return {
      customerId: undefined,
      isLoading: false,
      active: 0,
      // 数据
      list: []
    };
  },
  onLoad(option) {
    this.customerId = option.customerId;
    this.getData();
  },
  methods: {
    // 获取数据
    async getData() {
      try {
        let { data } = await customerProjectList({ customerId: this.customerId });
        this.list = data;
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 切换tab回调
    tabChange() {
      this.getData();
    },
    // 下拉刷新
    onRefresh() {
      this.getData();
    }
  }
};
</script>

<style scoped lang="scss">
.van-empty {
  padding: 40rpx 0;
}
::v-deep .van-pull-refresh {
  height: calc(100vh - 160rpx);
  overflow: auto;
}
</style>

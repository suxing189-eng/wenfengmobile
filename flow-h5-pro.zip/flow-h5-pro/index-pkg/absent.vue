<template>
  <view class="gray-bj-color" style="height: 100%;">
    <view class="tab"></view>
    <van-cell>
      <template #title>
        <view class="text-padding">
          <view>当前只统计最近五天有缺卡的工人，不含今天。</view>
        </view>
      </template>
    </van-cell>
    <!-- 列表 -->
    <uni-table class="" border stripe emptyText="暂无更多数据">
      <!-- 表头行 -->
      <uni-tr>
        <uni-th width="100" align="center">日期</uni-th>
        <uni-th width="100" align="center">姓名</uni-th>
        <uni-th width="50" align="center">上班</uni-th>
        <uni-th width="50" align="center">下班</uni-th>
      </uni-tr>
      <!-- 表格数据行 -->
      <uni-tr v-for="(item, index) in absentData" :key="index">
        <uni-td align="center">{{ item.dateStr }}</uni-td>
        <uni-td align="center">{{ item.realName }}</uni-td>
        <uni-td align="center">
          <text v-if="item.amTimeRepair" @click="reissueCard('AM', item)" class="text-blue">{{ item.amTime }}</text>
          <text v-else>{{ item.amTime }}</text>
        </uni-td>
        <uni-td align="center">
          <text v-if="item.pmTimeRepair" @click="reissueCard('PM', item)" class="text-blue">{{ item.pmTime }}</text>
          <text v-else>{{ item.pmTime }}</text>
        </uni-td>
      </uni-tr>
    </uni-table>

    <!-- 对话框 -->
    <van-dialog v-model="show" title="补卡" @confirm="confirm" @cancel="show = false" show-cancel-button>
      <van-field
        readonly
        clickable
        name="device"
        v-model="reissueForm.deviceSn"
        label="考勤机"
        placeholder="点击选择考勤机"
        :rules="[{ required: true, message: '请选择考勤机' }]"
        @click="devicePicker = true"
      />
      <van-field class="field-item" readonly v-model="mendCard" label="补卡" placeholder="" />
    </van-dialog>
    <van-popup v-model="devicePicker" position="bottom"><van-picker show-toolbar :columns="deviceOptions" @confirm="typeConfirm" @cancel="devicePicker = false" /></van-popup>
  </view>
</template>

<script>
import { absentList, repairClock, getClockRecord } from '@/api/index.js';
export default {
  data() {
    return {
      // 工人打卡id
      dingUserId: undefined,
      projectId: undefined,
      // 打卡记录数据
      absentData: [],
      realName: '',
      totalClockDays: 0,
      // 补卡对话框显示
      show: false,
      // 考勤机显示
      devicePicker: false,
      // 选择考勤机
      deviceOptions: [],
      // 补卡
      mendCard: '',
      // 表单
      reissueForm: {
        deviceSn: ''
      }
    };
  },
  onLoad(option) {
    this.projectId = option.projectId;
    this.getData();
  },
  methods: {
    // 获取工人打卡详情
    async getData() {
      try {
        this.deviceOptions = [];
        let { data, deviceList } = await absentList({ projectId: this.projectId });
        this.absentData = data;
        deviceList.forEach(item => {
          this.deviceOptions.push({ text: item, value: item });
        });
        // });
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 打开补卡对话框
    async reissueCard(type, item) {
      this.reissueForm.clockDate = '';
      this.reissueForm.realName = item.realName;
      this.reissueForm.projectId = this.projectId;
      this.reissueForm.dingUserId = item.dingUserId;
      // 当考勤机只有一个的时候 默认选择
      if (this.deviceOptions.length === 1) {
        this.reissueForm.deviceSn = this.deviceOptions[0].value;
      }
      // 从列表点击补卡 自动填入是上班还是下班补卡
      if (type) {
        this.reissueForm.clockTime = type;
        this.reissueForm.clockDate = item.dateStr;
      }
      // 页面显示判断
      if (type === 'AM') {
        this.mendCard = '上班卡';
      } else {
        this.mendCard = '下班卡';
      }
      this.show = true;
    },
    //选择节点
    typeConfirm(value) {
      this.reissueForm.deviceSn = value.value;
      this.devicePicker = false;
    },
    // 补卡对话框确定按钮
    async confirm() {
      try {
        let { msg } = await repairClock(this.reissueForm);
        this.Toast.success(msg);
        this.show = false;
        this.getData();
      } catch (e) {
        //TODO handle the exception
      }
    }
  }
};
</script>

<style>
.tab {
  height: 20rpx;
  background-color: #f2f2f2;
}
.text-blue {
  text-decoration: underline;
  color: #1989fa;
}
::v-deep .van-cell{
  padding: 10rpx 32rpx;
}
</style>

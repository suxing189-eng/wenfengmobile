<template>
  <view class="gray-bj-color" style="height: calc(100vh - 88rpx);">
    <van-tabs v-model="active" sticky offset-top="44px" @change="tabChange" title-inactive-color="#666666" title-active-color="#000">
      <van-tab title="请款单">
        <van-list v-model="loading" :finished="finished" :finished-text="finishedText" @load="upwardPull">
          <van-dropdown-menu class="mt-10">
            <van-dropdown-item :title="monthData" ref="item">
              <van-datetime-picker
                v-model="nowDate"
                @confirm="confirmDate"
                @cancel="$refs.item.toggle()"
                type="year-month"
                title="选择年月"
                :min-date="minDate"
                :max-date="maxDate"
                :formatter="formatter"
              />
            </van-dropdown-item>
            <van-dropdown-item :title="statusText" v-model="queryParams.examineState" :options="examineOption" @change="dropdownChnage"></van-dropdown-item>
          </van-dropdown-menu>
          <van-search class="" v-model="queryParams.searchValue" @search="changeSearch" :clearable="false" placeholder="请输入搜索关键词" />
          <apply-bill-list v-for="item in list" :key="item.id" :item="item"></apply-bill-list>
          <van-empty v-if="list.length === 0" description="暂无数据" />
        </van-list>
      </van-tab>
      <van-tab title="材料单">
        <van-dropdown-menu class="mt-10">
          <van-dropdown-item :title="monthData" ref="item">
            <van-datetime-picker
              v-model="nowDate"
              @confirm="confirmDate"
              @cancel="$refs.item.toggle()"
              type="year-month"
              title="选择年月"
              :min-date="minDate"
              :max-date="maxDate"
              :formatter="formatter"
            />
          </van-dropdown-item>
          <van-dropdown-item :title="statusText" v-model="queryParams.examineState" :options="examineOption" @change="dropdownChnage"></van-dropdown-item>
        </van-dropdown-menu>
        <van-list v-model="loading" :finished="finished" :finished-text="finishedText" @load="upwardPull">
          <van-search class="" v-model="queryParams.searchValue" @search="changeSearch" :clearable="false" placeholder="请输入搜索关键词" />
          <order-list :orderData="list"></order-list>
        </van-list>
      </van-tab>
    </van-tabs>
  </view>
</template>

<script>
import { applyBillHistory, supplierOrderHistory } from '@/api/index.js';
import applyBillList from '@/index-pkg/components/applyBillList.vue';
import orderList from '@/index-pkg/components/orderList.vue';
export default {
  components: {
    applyBillList,
    orderList
  },
  data() {
    return {
      // 请求数据参数
      queryParams: {
        pageNo: 0,
        pageSize: 10,
        searchValue: '',
        queryMonth: '',
        examineState: ''
      },
      active: 0,
      // 下拉状态
      loading: false,
      // 是否已加载完成
      finished: false,
      // 加载完成文字
      finishedText: '没有更多了',
      list: [],
      // 页面显示时间
      monthData: '',
      statusText: '全部',
      // 选择的日期（用来对应时间选择器的时间）
      nowDate: '',
      // 状态集合
      examineOption: [{ text: '全部', value: '' }, { text: '审批中', value: 0 }, { text: '已通过', value: 1 }, { text: '被驳回', value: 2 }],
      minDate: new Date(2016, 0, 1),
      maxDate: new Date()
    };
  },
  onLoad() {
    let month = new Date().getMonth() + 1 < 10 ? '0' + (new Date().getMonth() + 1) : new Date().getMonth() + 1;
    // 查询参数
    this.queryParams.queryMonth = new Date().getFullYear() + '-' + month;
    // 显示的标题 年月
    this.monthData = new Date().getFullYear() + '-' + month;
    // 对应时间选择器
    this.nowDate = new Date();
  },
  methods: {
    // 单据列表
    async mineData() {
      try {
        if (this.active === 0) {
          // 请款单
          let { data, dataCount } = await applyBillHistory(this.queryParams);
          this.list = this.list.concat(data);
          this.loading = false;
          // 判断是否已经全部加载完成
          this.allLoading(dataCount);
        } else {
          // 材料单
          let { data, dataCount } = await supplierOrderHistory(this.queryParams);
          this.list = this.list.concat(data);
          this.loading = false;
          // 判断是否已经全部加载完成
          this.allLoading(dataCount);
        }
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 判断是否已经全部加载完成
    allLoading(dataCount) {
      if (this.queryParams.pageNo * this.queryParams.pageSize > dataCount) {
        this.finished = true;
      }
      if (dataCount === 0) {
        this.finishedText = '';
      } else {
        this.finishedText = '没有更多了...';
      }
    },

    // 上拉回调
    upwardPull() {
      this.queryParams.pageNo += 1;
      this.mineData();
    },
    // tab回调函数
    tabChange() {
      this.monthData = this.util.dateFormat('yyyy-mm', new Date());
      this.statusText = '全部';
      this.queryParams = {
        pageNo: 1,
        pageSize: 10,
        queryMonth: this.util.dateFormat('yyyy-mm', new Date()),
        examineState: ''
      };
      this.list = [];
      this.mineData();
    },
    // 查询回调
    changeSearch() {
      this.queryParams.pageNo = 1;
      this.list = [];
      this.mineData();
    },
    // 选择时间确定按钮
    confirmDate(value) {
      this.nowDate = value;
      this.monthData = this.util.dateFormat('yyyy-mm', new Date(value));
      this.queryParams.queryMonth = this.util.dateFormat('yyyy-mm', new Date(value));
      this.changeSearch();
      this.$refs.item.toggle();
    },
    // 下拉回调
    dropdownChnage(value) {
      let examine = this.examineOption.filter(item => {
        return item.value === value;
      });
      this.statusText = examine[0].text;
      this.queryParams.examineState = value;
      this.changeSearch();
    },
    // 时间选择器
    formatter(type, val) {
      if (type === 'year') {
        return `${val}年`;
      } else if (type === 'month') {
        return `${val}月`;
      }
      return val;
    }
  }
};
</script>

<style scoped lang="scss">
::v-deep .van-list__finished-text {
  background-color: #f2f2f2 !important;
}
</style>

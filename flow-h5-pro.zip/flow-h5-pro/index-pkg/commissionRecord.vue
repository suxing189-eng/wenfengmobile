<template>
  <view class="gray-bj-color" style="height: 100%">
    <!-- 审批提成支付 -->
    <view class="" v-for="item in list" :key="item.id" @click="examineCommission(item)"><commission-view :item="item"></commission-view></view>
    <!-- 暂无数据 -->
    <van-empty v-if="list.length === 0" description="暂无数据" />
  </view>
</template>

<script>
import { ProjectCommission } from '@/api/index.js';
import commissionView from '@/wait-pkg/components/commissionView.vue';
export default {
  components: {
    commissionView
  },
  data() {
    return {
      list: []
    };
  },
  onLoad() {
    this.getData();
  },
  methods: {
    // 获取数据
    async getData() {
      try {
        let { data } = await ProjectCommission();
        this.list = data;
      } catch (e) {
        //TODO handle the exception
      }
    }
  }
};
</script>

<style></style>

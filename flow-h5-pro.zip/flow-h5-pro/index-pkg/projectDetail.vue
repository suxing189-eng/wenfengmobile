<template>
  <view style="height: calc(100vh - 44px);" class="gray-bj-color">
    <!-- 工程基本信息 -->
    <van-cell>
      <template #title>
        <view class="flex-between">
          <view class="text-nowrap" style="width: 680rpx;overflow: hidden;">
            <van-tag type="primary" style="margin-right: 10rpx;display: inline;">{{ info.deptName }}</van-tag>
            <view style="display: inline;font-weight: 600;">{{ info.projectName }}</view>
          </view>
        </view>
        <view class="flex-between" style="margin-top: 10rpx;">
          <view>
            <van-tag type="primary" style="margin-right: 10rpx;display: inline;">{{ info.projectLabel }}</van-tag>
            <van-tag v-if="info.explainState" type="success" style="margin-right: 10rpx;">已交底</van-tag>
            <van-tag v-else color="#e5e5e5" style="margin-right: 10rpx;">未交底</van-tag>
            <van-tag v-if="info.doneWorkState" type="success" style="margin-right: 10rpx;">已完工</van-tag>
            <van-tag v-else color="#e5e5e5" style="margin-right: 10rpx;">未完工</van-tag>
            <van-tag v-if="info.closeState" type="success" style="margin-right: 10rpx;">已关单</van-tag>
            <van-tag v-else color="#e5e5e5" style="margin-right: 10rpx;">未关单</van-tag>
            <van-tag v-if="info.statement" type="success" style="margin-right: 10rpx;">已结算</van-tag>
            <van-tag v-else color="#e5e5e5" style="margin-right: 10rpx;">未结算</van-tag>
          </view>
          <view>
            <text v-if="info.projectState === 0" class="text-info">待开工</text>
            <text v-if="info.projectState === 1" class="primary">施工中</text>
            <text v-if="info.projectState === 2" class="warning">待验收</text>
            <text v-if="info.projectState === 3" class="warning">整改中</text>
            <text v-if="info.projectState === 4" class="success">已完工</text>
            <text v-if="info.projectState === 5" class="danger">停工中</text>
          </view>
        </view>
      </template>
      <template #label>
        <view class="flex-between text-padding">
          <view class="">项目经理: {{ info.dutyUserName }}</view>
          <view class="">合同总额: {{ info.contractMoney }} 元</view>
        </view>
        <view class="text-padding">工程地址: {{ info.address }}</view>
        <!-- <view class="text-padding">施工日期: {{ `${info.planOpenDate}
         至 ${info.planFinishDate || ''}` }}</view> -->
        <view class="text-padding">施工日期: {{ info.dateScope }}</view>
        <view class="flex-between text-padding">
          <view class="">{{ `日志(${info.followCount || 0})` }}</view>
          <view class="">{{ `早会(${info.videoCount || 0})` }}</view>
          <view class="">{{ `巡检(${info.patrolCount || 0})` }}</view>
          <view class="">{{ `周计划(${info.weekPlanCount || 0})` }}</view>
          <view class="">{{ `待整改(${info.upgradeCount || 0})` }}</view>
        </view>
        <view class="flex-between text-padding">
          <view class="">施工节点: {{ info.nodeFollowTypeName }}</view>
          <view v-if="sys_gantt_state === '1'" style="text-decoration: underline;color: blue;line-height: 34rpx;" @click="openGantt(info)">甘特图</view>
        </view>
      </template>
    </van-cell>
    <!-- tab页 -->
    <van-tabs class="mt-10" sticky offset-top="44px" v-model="active" @change="tabChange" title-inactive-color="#666666" title-active-color="#000">
      <van-tab title="施工动态"><build-state ref="build" v-if="active === 0" :projectId="id"></build-state></van-tab>
      <van-tab title="考勤打卡"><check-view :projectId="id" v-if="active === 1"></check-view></van-tab>
      <van-tab title="合同信息">
        <contract-list v-if="active === 2 && perList.includes('project:detail:contract')" :projectId="id"></contract-list>
        <van-empty v-else description="暂无权限" />
      </van-tab>
      <van-tab title="回款信息">
        <returned-list v-if="active === 3 && perList.includes('project:detail:contract')" :projectId="id"></returned-list>
        <van-empty v-else description="暂无权限" />
      </van-tab>
      <van-tab title="外采">
        <purchase-view v-if="active === 4 && perList.includes('project:detail:purchase')" :projectId="id"></purchase-view>
        <van-empty v-else description="暂无权限" />
      </van-tab>
      <van-tab title="请款单">
        <view v-if="active === 5 && perList.includes('project:detail:bill')">
          <!-- 新增按钮 -->
          <view class="request-button m-5" v-if="sys_app_bill_state === '1'"><van-button type="info" style="width: 100%;" @click="addRequest">填写请款单</van-button></view>
          <!-- 统计概览 -->
          <view class="header-box">
            <view class="header-item">
              <view class="header-title">A.合计总额</view>
              <view class="header-content">{{ applyInfo.totalMoney }}</view>
            </view>
            <view class="header-item">
              <view class="header-title">B.已通过</view>
              <view class="header-content">{{ applyInfo.completeMoney }}</view>
            </view>
            <view class="header-item">
              <view class="header-title">C.审批中</view>
              <view class="header-content">{{ applyInfo.activeMoney }}</view>
            </view>
          </view>
          <van-search v-model="searchValue" show-action placeholder="请输入搜索关键词" :clearable="false" @search="getBillData">
            <template #action>
              <div @click="getBillData">搜 索</div>
            </template>
          </van-search>
          <view v-for="item in applyData" :key="item.id" @click="openSubmit(item)"><apply-bill-list :item.sync="item"></apply-bill-list></view>
          <van-empty v-if="applyData.length === 0" description="暂无数据" />
        </view>
        <van-empty v-else description="暂无权限" />
      </van-tab>
      <van-tab title="材料单">
        <view v-if="active === 6 && perList.includes('project:detail:order')">
          <!-- 统计概览 -->
          <view class="header-box">
            <view class="header-item">
              <view class="header-title">A.合计总额</view>
              <view class="header-content">{{ applyInfo.totalMoney }}</view>
            </view>
            <view class="header-item">
              <view class="header-title">B.已通过</view>
              <view class="header-content">{{ applyInfo.completeMoney }}</view>
            </view>
            <view class="header-item">
              <view class="header-title">C.审批中</view>
              <view class="header-content">{{ applyInfo.activeMoney }}</view>
            </view>
          </view>
          <order-list class="mt-10" v-if="orderData.length > 0" :orderData.sync="orderData"></order-list>
        </view>
        <van-empty v-else description="暂无权限" />
      </van-tab>
      <van-tab title="支出信息">
        <payment-list v-if="active === 7 && perList.includes('project:detail:payment')" :projectId="id"></payment-list>
        <van-empty v-else description="暂无权限" />
      </van-tab>
      <van-tab title="文档"><file-view v-if="active === 8" :projectId="id"></file-view></van-tab>
    </van-tabs>
  </view>
</template>

<script>
import { projectDetail, applyBillData, supplierOrder, sysCfg } from '@/api/index.js';
import contractList from '@/index-pkg/components/contractList.vue';
import returnedList from '@/index-pkg/components/returnedList.vue';
import applyBillList from '@/index-pkg/components/applyBillList.vue';
import orderList from '@/index-pkg/components/orderList.vue';
import paymentList from '@/index-pkg/components/paymentList.vue';
import buildState from '@/index-pkg/components/buildState.vue';
import purchaseView from '@/index-pkg/components/purchaseView.vue';
import checkView from '@/index-pkg/components/checkView.vue';
import fileView from '@/index-pkg/components/fileView.vue';
import { mapState } from 'vuex';
export default {
  components: {
    contractList,
    returnedList,
    applyBillList,
    orderList,
    paymentList,
    buildState,
    purchaseView,
    checkView,
    fileView
  },
  data() {
    return {
      active: 0,
      info: {},
      id: 0,
      // 请款单数据
      applyData: [],
      applyInfo: {},
      // 材料单数据
      orderData: [],
      perList: [],
      sys_app_bill_state: '0',
      // 甘特图显示
      sys_gantt_state: '0',
      // 请款单查询条件
      searchValue: ''
    };
  },
  onShow() {
    this.$nextTick(() => {
      if (this.active === 0) {
        this.$refs.build.getData();
      }
      if (this.active === 5) {
        this.getBillData();
      }
    });
  },
  computed: {
    // ...mapState('user', ['perList'])
  },
  onLoad(option) {
    this.getState();
    this.id = option.id;
    this.getData();
  },
  methods: {
    // 获取请款单数据
    async getBillData() {
      try {
        let { data, activeMoney, completeMoney, totalMoney } = await applyBillData({ projectId: this.id, searchValue: this.searchValue });
        this.applyData = data;
        this.applyInfo = {
          activeMoney: activeMoney || 0,
          completeMoney: completeMoney || 0,
          totalMoney: totalMoney || 0
        };
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 初始化
    async getState() {
      try {
        // 获取填写请款单按钮是否显示
        sessionStorage.removeItem('sys_app_bill_state');
        sessionStorage.removeItem('sys_gantt_state');
        let { data: datas } = await sysCfg();
        sessionStorage.setItem('sys_app_bill_state', datas.sys_app_bill_state);
        sessionStorage.setItem('sys_gantt_state', datas.sys_gantt_state);

        this.sys_app_bill_state = sessionStorage.getItem('sys_app_bill_state');
        this.sys_gantt_state = sessionStorage.getItem('sys_gantt_state');
        this.perList = sessionStorage.getItem('perList');
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 获取材料单数据
    async getSupplierData() {
      try {
        let { data, activeMoney, completeMoney, totalMoney } = await supplierOrder({ projectId: this.id });
        this.orderData = data;
        this.applyInfo = {
          activeMoney: activeMoney || 0,
          completeMoney: completeMoney || 0,
          totalMoney: totalMoney || 0
        };
      } catch (e) {
        //TODO handle the exception
      }
    },
    // tab页 回调
    tabChange() {
      if (this.active === 5) {
        this.getBillData();
      } else if (this.active === 6) {
        this.getSupplierData();
      } else {
        return;
      }
    },
    // 获取工程详情
    async getData() {
      try {
        let { data } = await projectDetail({ id: this.id });
        this.info = data;
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 打开甘特图
    openGantt(info) {
      uni.navigateTo({ url: '/index-pkg/ganttView?id=' + info.id });
    },

    // 调整提交请款单页面
    openSubmit(item) {
      uni.navigateTo({ url: '/index-pkg/submitApplyBill?id=' + item.id });
    },
    // 打开申请请款单页面
    addRequest() {
      uni.navigateTo({ url: '/index-pkg/addRequest?projectId=' + this.id });
    }
  }
};
</script>

<style lang="scss" scoped>
@function rpx2em($rpx) {
  @return ($rpx / 16) * 1rem;
}
.text-info {
  color: #666666;
}
.header-box {
  background-color: #fff;
  margin-bottom: rpx2em(5);
  margin-top: rpx2em(5);
  display: flex;
  justify-content: space-between;
  align-items: center;
  .header-item {
    flex: 0 0 33.3%;
    text-align: center;
    border: 1px solid #f5f6f8;
    border-collapse: collapse;
    .header-title {
      height: rpx2em(29);
      line-height: rpx2em(29);
      padding: rpx2em(5) rpx2em(1);
      border-bottom: solid 1px #f5f6f8;
      color: #646566;
      font-size: rpx2em(13);
      font-weight: 600;
    }
    .header-content {
      padding: rpx2em(8) rpx2em(5);
      font-size: rpx2em(16);
    }
  }
}
.text-green {
  color: #07c160;
}

::v-deep .van-tag {
  padding: rpx2em(2) rpx2em(6);
}
.request-button ::v-deep .van-button {
  height: rpx2em(34);
}
</style>

<template>
  <view class="gray-bj-color">
    <view class="tab5"></view>
    <van-form @submit="onSubmit">
      <van-field
        v-model="form.trendDate"
        @click="calendarShow = true"
        name="trendDate"
        label="跟进日期"
        placeholder="请选择跟进日期"
        :rules="[{ required: true, message: '请选择跟进日期' }]"
      />
      <van-field
        style="margin-top: 10rpx;"
        readonly
        clickable
        name="trendNode"
        v-model="trendNodeName"
        label="跟进节点"
        placeholder="点击选择跟进节点"
        :rules="[{ required: true, message: '请选择跟进节点' }]"
        @click="followPicker = true"
      />
      <QuillEditor ref="quill" :value.sync="form.trendContent" :options="editorOptions" />
      <!-- <van-field v-model="form.trendContent" rows="2" autosize label="跟进内容" type="textarea" placeholder="请输入跟进内容"/> -->
      <!-- <div style="border: 1px solid #ccc;margin: 8rpx;height: 300px;">
        <Toolbar style="border-bottom: 1px solid #ccc" :editor="editor" :defaultConfig="toolbarConfig" :mode="mode" />
        <Editor style="height: 295px; overflow-y: hidden;" v-model="form.trendContent" :defaultConfig="editorConfig" :mode="mode" @onCreated="onCreated" />
      </div> -->
      <image-picker :fileValue.sync="fileValue" labelName="跟进图片"></image-picker>
      <div style="margin: 16px;"><van-button round block type="info" native-type="submit">提交</van-button></div>
    </van-form>

    <!-- 选择日历 -->
    <van-calendar v-model="calendarShow" :min-date="minDate" :max-date="maxDate" @confirm="dateConfirm" />
    <!-- 选择跟进节点 -->
    <van-popup v-model="followPicker" position="bottom"><van-picker show-toolbar :columns="typeColumns" @confirm="typeConfirm" @cancel="followPicker = false" /></van-popup>
  </view>
</template>

<script>
import { dictList, projectTrendAdd, getCfg } from '@/api/index.js';
import imagePicker from '@/components/imagePicker.vue';
// import { Editor, Toolbar } from '@wangeditor/editor-for-vue';
// import '@wangeditor/editor/dist/css/style.css'; // wangeditor css
// import { DomEditor } from '@wangeditor/editor';
import QuillEditor from '@/components/quillEditor.vue';
export default {
  components: {
    imagePicker,
    // Editor,
    // Toolbar,
    QuillEditor
  },
  data() {
    return {
      // 工程id
      projectId: 0,
      // 表单
      form: {
        trendContent: ''
      },
      // 日历显示
      calendarShow: false,
      // 跟进节点显示
      followPicker: false,
      typeColumns: [],
      fileValue: [],
      // 节点显示
      trendNodeName: '',
      minDate: new Date(2000, 0, 1),
      maxDate: new Date(),
      // 富文本编辑器
      // editor: null,
      // toolbarConfig: {
      //   toolbarKeys: []
      // },
      editorOptions: {
        modules: {
          toolbar: [
            // 可以覆盖默认工具栏配置
            ['bold', 'italic'],
            ['link', 'image']
          ]
        }
      }
      // editorConfig: {
      //   placeholder: '请输入施工日志...',
      //   maxLength: 500,
      //   hoverbarKeys: {
      //     // text: {
      //     //   // 重写 link 元素的 hoverbar
      //     //   menuKeys: []
      //     // }
      //   }
      // },
      // mode: 'simple' // or 'simple'
    };
  },
  onLoad(option) {
    this.form.trendDate = this.formatDate(new Date());
    this.projectId = option.projectId;
    this.initData();
  },
  // beforeDestroy() {
  //   const editor = this.editor;
  //   if (editor == null) return;
  //   editor.destroy(); // 组件销毁时，及时销毁编辑器
  // },
  methods: {
    // 获取字典数据
    async initData() {
      try {
        this.typeColumns = [];
        let { data } = await dictList({ dictType: 'project_node_follow_type' });
        data.forEach(item => {
          this.typeColumns.push({ text: item.dictLabel, value: item.dictValue });
        });
        let { data: dataCfg } = await getCfg({ cfgName: 'log_tpl' });
        this.form.trendContent = dataCfg;
        this.$refs.quill.initData();
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 选择日历
    formatDate(date) {
      return `${date.getFullYear()}/${date.getMonth() + 1}/${date.getDate()}`;
    },
    // 选择日期
    dateConfirm(date) {
      this.calendarShow = false;
      this.form.trendDate = this.formatDate(date);
    },
    //选择跟进节点
    typeConfirm(value) {
      this.form.trendNode = value.value;
      this.trendNodeName = value.text;
      this.followPicker = false;
    },
    // 表单提交按钮
    async onSubmit() {
      try {
        this.form.trendType = 2;
        this.form.projectId = this.projectId;
        this.form.images = [];
        this.fileValue.forEach(item => {
          this.form.images.push(item.url);
        });
        this.form.images = this.form.images.join(',');
        let { msg } = await projectTrendAdd(this.form);
        this.Toast.success(msg);
        uni.navigateBack();
      } catch (e) {
        //TODO handle the exception
      }
    },
    onCreated(editor) {
      this.editor = Object.seal(editor); // 一定要用 Object.seal() ，否则会报错
    }
  }
};
</script>
<style scoped lang="scss">
::v-deep #w-e-textarea-1 {
  padding: 0;
}
::v-deep .w-e-text-container {
  height: 300px;
  padding: 0;
}
.van-contact-list__bottom {
  padding: 0;
}
::v-deep .w-e-text-container p​:first-child {
  margin-top: 15px !important;
}
::v-deep .w-e-text-container p {
  margin: 8rpx;
}
.tab5 {
  height: 10rpx;
}
</style>

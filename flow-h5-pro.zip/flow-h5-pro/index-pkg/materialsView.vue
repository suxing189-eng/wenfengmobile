<template>
  <view class="gray-bj-color" style="height: 100%;">
    <view class="tab"></view>
    <!-- 详情信息 -->
    <van-cell>
      <template #title>
        <view class="flex-between">
          <text class="text-nowrap" style="font-weight: 600;width: 500rpx;">{{ info.supplierName }}</text>
          <view>
            <text style="color: #909399;" v-if="info.examineState === -1">{{ info.stateText }}</text>
            <text style="color: #409EFF;" v-else-if="info.examineState === 0">{{ info.stateText }}</text>
            <text style="color: #67C23A;" v-else-if="info.examineState === 1">{{ info.stateText }}</text>
            <text style="color: red;" v-else>{{ info.stateText }}</text>
          </view>
        </view>
      </template>
      <template #label>
        <view class="flex-between text-padding">
          <view class="">送货日期: {{ info.sendDate }}</view>
          <view class="">请款金额: {{ info.totalMoney }}</view>
        </view>
        <view class="flex-between text-padding">
          <view class="">单据号: {{ info.paperNo }}</view>
          <view class="">审批金额: {{ info.checkMoney }}</view>
        </view>
        <view class="text-padding">{{ info.remark }}</view>
      </template>
    </van-cell>
    <view class="mt-10 ml-10 mb-10 text-title">材料明细</view>
    <materials-detail :detailData="info.itemList"></materials-detail>
  </view>
</template>

<script>
import { supplierOrderGetById } from '@/api/wait.js';
import materialsDetail from "@/wait-pkg/components/materialsDetail.vue"
export default {
  components: {
    materialsDetail
  },
  data() {
    return {
      // 订货单id
      orderId: 0,
      info: {}
    };
  },
  onLoad(option) {
    this.orderId = option.id;
    this.getDetail();
  },
  methods: {
    // 获取列表详情数据
    async getDetail() {
      try {
        let { data } = await supplierOrderGetById({ id: this.orderId });
        this.info = data;
        
      } catch (e) {
        //TODO handle the exception
      }
    }
  }
};
</script>

<style>
.text-title {
  color: #666666;
}
</style>

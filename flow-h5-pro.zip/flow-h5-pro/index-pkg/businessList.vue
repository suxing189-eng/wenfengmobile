<template>
  <view class="gray-bj-color-97">
    <!-- 业务登记 -->
    <van-tabs v-model="active" sticky offset-top="44px" @change="tabChange" title-inactive-color="#666666" title-active-color="#000">
      <van-tab title="业务列表">
        <van-pull-refresh v-model="isLoading" @refresh="refresh" class="mt-5">
          <van-dropdown-menu>
            <van-dropdown-item :title="statusText" v-model="queryParams.businessState" :options="stateOption" @change="dropownChange"></van-dropdown-item>
          </van-dropdown-menu>
          <van-search class="mt10" v-model="queryParams.searchValue" @search="refresh" :clearable="false" placeholder="请输入搜索关键词" />
          <van-list v-model="loading" :finished="finished" :finished-text="finishedText" @load="upwardPull">
            <view class="" v-for="item in list" :key="item.id"><business-view :item="item"></business-view></view>
            <van-empty v-if="list.length === 0" description="暂无数据" />
          </van-list>
        </van-pull-refresh>
      </van-tab>
      <!-- 业务统计 -->
      <van-tab title="业务统计">
        <view v-if="perList.includes('business:stats')">
          <van-dropdown-menu class="mt-5">
            <van-dropdown-item v-model="dropdownValue" @change="dropdownChange" :title="year" :options="option" ref="datetime"></van-dropdown-item>
          </van-dropdown-menu>
          <!-- 列表 -->
          <uni-table class="" border stripe emptyText="暂无更多数据">
            <!-- 表头行 -->
            <uni-tr>
              <uni-th width="100" align="center">姓名</uni-th>
              <uni-th width="100" align="center">总数</uni-th>
              <uni-th width="100" align="center">未开始</uni-th>
              <uni-th width="100" align="center">跟进中</uni-th>
              <uni-th width="100" align="center">已成交</uni-th>
              <uni-th width="100" align="center">已暂停</uni-th>
              <uni-th width="100" align="center">已取消</uni-th>
            </uni-tr>
            <!-- 表格数据行 -->
            <uni-tr v-for="item in statisticsData" :key="item.id">
              <uni-td align="center">
                <text class="text-blue" @click="openDetail(item)">{{ item.userName }}</text>
              </uni-td>
              <uni-td align="center">{{ item.totalCount }}</uni-td>
              <uni-td align="center">{{ item.stateWaiting }}</uni-td>
              <uni-td align="center">{{ item.stateFollowing }}</uni-td>
              <uni-td align="center">{{ item.stateFinish }}</uni-td>
              <uni-td align="center">{{ item.statePause }}</uni-td>
              <uni-td align="center">{{ item.stateCancel }}</uni-td>
            </uni-tr>
            <!-- 合计 -->
            <uni-tr>
              <uni-td width="100" align="center">合计</uni-td>
              <uni-td width="100" align="center">{{ totalCountSum }}</uni-td>
              <uni-td width="100" align="center">{{ stateWaitingSum }}</uni-td>
              <uni-td width="100" align="center">{{ stateFollowingSum }}</uni-td>
              <uni-td width="100" align="center">{{ stateFinishSum }}</uni-td>
              <uni-td width="100" align="center">{{ statePauseSum }}</uni-td>
              <uni-td width="100" align="center">{{ stateCancelSum }}</uni-td>
            </uni-tr>
          </uni-table>
        </view>
        <van-empty style="padding: 70px 0;" v-else description="暂无数据" />
      </van-tab>
    </van-tabs>
  </view>
</template>

<script>
import { businessList, kanbanList } from '@/api/wait.js';
import businessView from '../wait-pkg/components/businessView.vue';
export default {
  components: {
    businessView
  },
  data() {
    return {
      list: [],
      // 请求数据参数
      queryParams: {
        pageNo: 0,
        pageSize: 10,
        searchValue: '',
        businessState: ''
      },
      // tab页
      active: 0,
      // 下拉状态
      loading: false,
      // 是否已加载完成
      finished: false,
      // 加载完成文字
      finishedText: '没有更多了',
      statusText: '全部',
      isLoading: false,
      // 权限
      perList: [],
      // 状态集合
      stateOption: [
        { text: '全部', value: '' },
        { text: '未开始', value: '未开始' },
        { text: '跟进中', value: '跟进中' },
        { text: '已成交', value: '已成交' },
        { text: '已暂停', value: '已暂停' },
        { text: '已取消', value: '已取消' }
      ],
      // 参数
      year: '2024年',
      queryYear: '',
      option: [],
      dropdownValue: 0,
      // 业务统计列表
      statisticsData: [],
      // 合计
      totalCountSum: 0,
      stateWaitingSum: 0,
      stateFollowingSum: 0,
      stateFinishSum: 0,
      statePauseSum: 0,
      stateCancelSum: 0
    };
  },
  onLoad() {
    this.perList = sessionStorage.getItem('perList');
    this.year = new Date().getFullYear() + '年';
    this.queryYear = new Date().getFullYear() + '';
    // 计算显示时间
    let nowYear = new Date().getFullYear();
    this.option = [];
    for (let i = 0; i < 3; i++) {
      this.option.push({ text: nowYear + '年', value: i });
      nowYear--;
    }
  },
  onShow() {},
  methods: {
    // tab回调函数
    tabChange() {
      if (this.active === 0) {
        this.list = [];
        this.queryParams.pageNo = 1;
        this.getData();
      } else {
        this.userData();
      }
    },
    // 获取数据
    async getData() {
      try {
        let { data, dataCount } = await businessList(this.queryParams);
        this.isLoading = false;
        this.list = this.list.concat(data);
        this.loading = false;
        this.isLoading = false;
        if (this.queryParams.pageNo * this.queryParams.pageSize > dataCount) {
          this.finished = true;
        } else {
          this.finished = false;
        }
        if (dataCount === 0) {
          this.finishedText = '';
        } else {
          this.finishedText = '没有更多了...';
        }
      } catch (e) {}
    },
    // 获取业务统计看板人员数据
    async userData() {
      try {
        let { data } = await kanbanList({ queryType: 'user', queryYear: this.queryYear });
        this.statisticsData = data;
        this.totalCountSum = this.statisticsData.reduce((sum, item) => sum + item.totalCount, 0);
        this.stateWaitingSum = this.statisticsData.reduce((sum, item) => sum + item.stateWaiting, 0);
        this.stateFollowingSum = this.statisticsData.reduce((sum, item) => sum + item.stateFollowing, 0);
        this.stateFinishSum = this.statisticsData.reduce((sum, item) => sum + item.stateFinish, 0);
        this.statePauseSum = this.statisticsData.reduce((sum, item) => sum + item.statePause, 0);
        this.stateCancelSum = this.statisticsData.reduce((sum, item) => sum + item.stateCancel, 0);
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 刷新
    refresh() {
      this.list = [];
      this.queryParams.pageNo = 1;
      this.getData();
    },
    // 下拉回调
    dropownChange(value) {
      let state = this.stateOption.filter(item => {
        return item.value === value;
      });
      this.statusText = state[0].text;
      this.queryParams.businessState = value;
      this.refresh();
    },
    // 上拉回调
    upwardPull() {
      this.queryParams.pageNo += 1;
      this.getData();
    },
    // 选择回调
    dropdownChange(value) {
      let selectYear = this.option.filter(item => {
        return item.value === value;
      });
      this.year = selectYear[0].text;
      this.dropdownValue = value;
      this.queryYear = selectYear[0].text.slice(0, selectYear[0].text.indexOf('年'));
      // this.getData();
    },
    // 点击工人查看详情
    openDetail(item) {
      uni.navigateTo({ url: '/wait-pkg/userBusiness?userId=' + item.userId });
    }
  }
};
</script>

<style>
.van-empty {
  padding: 40rpx 0;
}
::v-deep .van-pull-refresh {
  overflow: auto;
}
::v-deep .uni-table-th:first-child,
::v-deep .uni-table-td:first-child {
  position: sticky;
  left: 0;
  z-index: 5;
  background: #fff;
}

.text-blue {
  color: #409eff;
  text-decoration: underline;
}
</style>

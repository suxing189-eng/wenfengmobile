<template>
  <view style="height: calc(100vh - 44px);" class="gray-bj-color">
    <van-pull-refresh v-model="isLoading" @refresh="onRefresh">
      <view class="tab"> </view>
      <van-search v-model="queryParams.supplierName" @search="changeSearch" :clearable="false" placeholder="请输入搜索关键词" />
      <!-- 列表内容 -->
      <van-list v-model="loading" :finished="finished" :finished-text="finishedText" @load="upwardPull">
        <supplier-view v-for="(item, index) in list" :key="item.id" :item="item"></supplier-view>
        <!-- 暂无数据 -->
        <van-empty v-if="list.length === 0" description="暂无数据" />
      </van-list>
    </van-pull-refresh>
  </view>
</template>

<script>
import supplierView from '@/index-pkg/components/supplierView.vue';
import { supplierList } from '@/api/index.js';
export default {
  components: {
    supplierView
  },
  data() {
    return {
      // 请求数据参数
      queryParams: {
        supplierName: '',
        pageNo: 0,
        pageSize: 10
      },
      active: 0,
      // 下拉状态
      loading: false,
      // 是否已加载完成
      finished: false,
      // 加载完成文字
      finishedText: '没有更多了',
      list: [],
      isLoading: false
    };
  },
  methods: {
    // 供应商列表
    async getData() {
      try {
        // 我的供应商
        let { data, dataCount } = await supplierList(this.queryParams);
        this.list = this.list.concat(data);
        this.loading = false;
        this.isLoading = false;
        // 判断是否已经全部加载完成
        this.allLoading(dataCount);
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 查询回调
    changeSearch() {
      this.queryParams.pageNo = 1;
      this.list = [];
      this.getData();
    },
    // 判断是否已经全部加载完成
    allLoading(dataCount) {
      if (this.queryParams.pageNo * this.queryParams.pageSize > dataCount) {
        this.finished = true;
      }
      if (dataCount === 0) {
        this.finishedText = '';
      } else {
        this.finishedText = '没有更多了...';
      }
    },
    // 上拉回调
    upwardPull() {
      this.queryParams.pageNo += 1;
      this.getData();
    },
    // 下拉刷新
    onRefresh() {
      this.queryParams.pageNo = 1;
      this.list = [];
      this.getData();
    }
  }
};
</script>

<style scoped lang="scss">
::v-deep .van-list__finished-text {
  background-color: #f2f2f2 !important;
}
.van-empty {
  padding: 40rpx 0;
}
::v-deep .van-pull-refresh {
  height: 100%;
  overflow: auto;
}
</style>

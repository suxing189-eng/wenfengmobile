<template>
  <view>
    <!-- 详情信息 -->
    <apply-bill-list :item="info"></apply-bill-list>
    <view v-if="stateList.includes(info.examineState)">
      <!-- 下拉流程选择 -->
      <van-field readonly clickable name="picker" :value="templateName" label="审批流程" placeholder="点击选择请款单流程" @click="showPicker = true" />
      <!-- 选择器 -->
      <van-popup v-model="showPicker" position="bottom"><van-picker show-toolbar :columns="bizCodeOption" @confirm="onConfirm" @cancel="showPicker = false" /></van-popup>
      <view style="margin-top: 40rpx;" v-if="sys_app_bill_state === '1'">
        <van-button style="margin-bottom: 60rpx;" color="#1989fa" round size="normal" @click="submitApply">提交请款单</van-button>
        <van-button style="margin-bottom: 60rpx;" color="#909399" round size="normal" @click="editApply">重新编辑</van-button>
        <van-button color="#ee0a24" round size="normal" @click="removeApply">删除单据</van-button>
      </view>
    </view>
  </view>
</template>

<script>
import applyBillList from '@/index-pkg/components/applyBillList.vue';
import { applyBillDetail, processTemplate, applyBIllCommit, applyBIllDelete } from '@/api/index.js';
export default {
  components: {
    applyBillList
  },
  data() {
    return {
      id: undefined,
      info: {},
      // 下拉框数据
      bizCodeOption: [],
      // 审批流程
      templateId: '',
      templateName: '',
      // 选择器显示
      showPicker: false,
      // 按钮显示
      stateList: [-1, 2, 3, 4, 5],
      sys_app_bill_state: '0'
    };
  },
  onLoad(option) {
    this.id = option.id;
    this.initData();
    this.sys_app_bill_state = sessionStorage.getItem('sys_app_bill_state');
  },
  onShow() {
    this.$nextTick(() => {
      this.getData();
    });
  },
  methods: {
    // 初始化
    async initData() {
      this.bizCodeOption = [];
      let { data } = await processTemplate({ bizCode: 'EX-PROJECT-APPLY' });
      data.forEach(item => {
        this.bizCodeOption.push({ value: item.templateId, text: item.templateName });
      });
    },
    // 获取数据
    async getData() {
      let { data } = await applyBillDetail({ id: this.id });
      this.info = data;
      try {
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 提交请款单
    async submitApply() {
      let { msg } = await applyBIllCommit({ templateId: this.templateId, id: this.id });
      this.Toast.success(msg);
      uni.navigateBack();
    },
    // 编辑请款单
    editApply() {
      uni.navigateTo({ url: '/index-pkg/addRequest?projectId=' + this.info.projectId + '&id=' + this.id });
    },
    // 删除单据
    removeApply() {
      this.Dialog.confirm({
        title: '删除',
        message: '确定删除此单据吗?'
      })
        .then(() => {
          applyBIllDelete({ id: this.id }).then(res => {
            this.Toast.success(res.msg);
            uni.navigateBack();
          });
        })
        .catch(() => {
          // on cancel
        });
    },
    // 选择器回调
    onConfirm(value) {
      this.templateName = value.text;
      this.templateId = value.value;
      this.showPicker = false;
    }
  }
};
</script>

<style scoped lang="scss">
.van-button--normal {
  width: 95%;
}
.van-button {
  margin: 12rpx 20rpx;
}
</style>

<template>
  <view class="gray-bj-color" style="height: 100%;">
    <view class="tab"></view>
    <!-- 概览 -->
    <view class="header">
      <view class="header-item">
        <view class="header-title">A.合计总额(A=B+C)</view>
        <view class="header-content">{{ totalMoney }}</view>
      </view>
      <view class="header-item">
        <view class="header-title">B.已通过</view>
        <view class="header-content">{{ completeMoney }}</view>
      </view>
      <view class="header-item">
        <view class="header-title">C.审批中</view>
        <view class="header-content">{{ activeMoney }}</view>
      </view>
    </view>
    <!-- 列表数据 -->
    <van-cell v-for="item in manageData" :key="item.id">
      <template #title>
        <view class="flex-between">
          <text class="text-nowrap" style="font-weight: 600;width: 500rpx;">{{ item.costName }}</text>
          <view>
            <text style="color: #909399;" v-if="item.examineState === -1">{{ item.stateText }}</text>
            <text style="color: #409EFF;" v-else-if="item.examineState === 0">{{ item.stateText }}</text>
            <text style="color: #67C23A;" v-else-if="item.examineState === 1">{{ item.stateText }}</text>
            <text style="color: red;" v-else>{{ item.stateText }}</text>
          </view>
        </view>
      </template>
      <template #label>
        <view class="flex-between text-padding">
          <view class="">{{ item.typeName }}</view>
          <view class="">费用金额: {{ item.costMoney }}</view>
        </view>
        <view class="flex-between text-padding">
          <view class="">发生部门：{{ item.deptName }}</view>
          <view class="">发生日期: {{ item.costDate }}</view>
        </view>
      </template>
    </van-cell>
  </view>
</template>

<script>
import { manageCostList } from '@/api/index.js';
export default {
  data() {
    return {
      // 数据
      manageData: [],
      queryMonth: '',
      activeMoney: 0,
      completeMoney: 0,
      totalMoney: 0
    };
  },
  onLoad(option) {
    this.queryMonth = option.queryMonth;
    this.getData();
  },
  methods: {
    // 获取数据
    async getData() {
      try {
        let { data, activeMoney, completeMoney, totalMoney } = await manageCostList({ queryMonth: this.queryMonth, commonCode: 'MANAGE_COST' });
        this.manageData = data;
        this.activeMoney = activeMoney;
        this.completeMoney = completeMoney;
        this.totalMoney = totalMoney;
      } catch (e) {
        //TODO handle the exception
      }
    }
  }
};
</script>

<style scoped lang="scss">
@function rpx2em($rpx) {
  @return ($rpx / 16) * 1rem;
}
.header {
  background-color: #fff;
  margin-bottom: rpx2em(5);
  padding: rpx2em(0);
  display: flex;
  justify-content: space-between;
  align-items: center;
  .header-item {
    flex: 0 0 33.3%;
    text-align: center;
    border: 1px solid #f5f6f8;
    border-collapse: collapse;
    .header-title {
      height: rpx2em(35);
      line-height: rpx2em(35);
      padding: rpx2em(5) rpx2em(1);
      border-bottom: solid 1px #f5f6f8;
      color: #646566;
      font-size: rpx2em(13);
      font-weight: 600;
    }
    .header-content {
      padding: rpx2em(20) rpx2em(5);
      font-size: rpx2em(19);
    }
  }
}
</style>

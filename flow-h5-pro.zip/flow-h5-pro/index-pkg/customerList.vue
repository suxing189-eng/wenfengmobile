<template>
  <view class="gray-bj-color-44">
    <van-tabs v-model="active" sticky offset-top="44px" @change="tabChange" title-inactive-color="#666666" title-active-color="#000">
      <van-tab title="我的客户">
        <!-- 下拉刷新 -->
        <van-pull-refresh v-model="isLoading" @refresh="onRefresh">
          <van-search class="mt-10" v-model="queryParams.searchValue" @search="changeSearch" :clearable="false" placeholder="请输入搜索关键词" />
          <!-- 列表 上拉加载 -->
          <van-list v-model="loading" :finished="finished" :finished-text="finishedText" @load="upwardPull">
            <view v-for="(item, index) in list" :key="item.id" @click="openDetail(item)"><customer-view :item="item"></customer-view></view>
            <!-- 暂无数据 -->
            <van-empty v-if="list.length === 0" description="暂无数据" />
          </van-list>
        </van-pull-refresh>
      </van-tab>
      <van-tab title="所有客户">
        <van-pull-refresh v-model="isLoading" @refresh="onRefresh">
          <van-search class="mt-10" v-model="queryParams.searchValue" @search="changeSearch" :clearable="false" placeholder="请输入搜索关键词" />
          <van-list v-model="loading" :finished="finished" :finished-text="finishedText" @load="upwardPull">
            <view v-for="(item, index) in list" :key="item.id"><customer-view :item="item"></customer-view></view>
            <!-- 暂无数据 -->
            <van-empty v-if="list.length === 0" description="暂无数据" />
          </van-list>
        </van-pull-refresh>
      </van-tab>
    </van-tabs>
  </view>
</template>

<script>
import customerView from '@/index-pkg/components/customerView.vue';
import { mineCustomer, allCustomer } from '@/api/index.js';
export default {
  components: {
    customerView
  },
  data() {
    return {
      // 请求数据参数
      queryParams: {
        pageNo: 0,
        pageSize: 10,
        customerName: ''
      },
      active: 0,
      // 下拉状态
      loading: false,
      // 是否已加载完成
      finished: false,
      // 加载完成文字
      finishedText: '没有更多了',
      list: [],
      isLoading: false
    };
  },
  methods: {
    // 客户列表
    async mineData() {
      try {
        if (this.active === 0) {
          // 我的客户
          let { data, dataCount } = await mineCustomer(this.queryParams);
          this.list = this.list.concat(data);
          this.loading = false;
          this.isLoading = false;
          // 判断是否已经全部加载完成
          this.allLoading(dataCount);
        } else {
          // 所有客户
          let { data, dataCount } = await allCustomer(this.queryParams);
          this.list = this.list.concat(data);
          this.loading = false;
          this.isLoading = false;
          // 判断是否已经全部加载完成
          this.allLoading(dataCount);
        }
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 判断是否已经全部加载完成
    allLoading(dataCount) {
      if (this.queryParams.pageNo * this.queryParams.pageSize > dataCount) {
        this.finished = true;
      } else {
        this.finished = false;
      }
      if (dataCount === 0) {
        this.finishedText = '';
      } else {
        this.finishedText = '没有更多了...';
      }
    },

    // 上拉回调
    upwardPull() {
      this.queryParams.pageNo += 1;
      this.mineData();
    },
    // tab回调函数
    tabChange() {
      this.queryParams.pageNo = 1;
      this.list = [];
      this.mineData();
    },
    // 查询回调
    changeSearch() {
      this.queryParams.pageNo = 1;
      this.list = [];
      this.mineData();
    },
    // 下拉刷新
    onRefresh() {
      this.queryParams.pageNo = 1;
      this.list = [];
      this.mineData();
    },
    // 跳转详情页面
    openDetail(item) {
      uni.navigateTo({ url: '/index-pkg/customerDetail?customerId=' + item.id });
    }
  }
};
</script>

<style scoped lang="scss">
@function rpx2em($rpx) {
  @return ($rpx / 16) * 1rem;
}
::v-deep .van-list__finished-text {
  background-color: #f2f2f2 !important;
}
.van-empty {
  padding: 40rpx 0;
}
::v-deep .van-pull-refresh {
  height: calc(100vh - 5.3rem);
  overflow: auto;
}
</style>

<template>
  <view class="gray-bj-color" style="height: 100%;">
    <view class="tab"></view>
    <van-pull-refresh v-model="isLoading" @refresh="getData">
      <van-collapse v-model="activeNames" accordion>
        <van-collapse-item v-for="(item,index) in detailData" :name="index" :key="item.id" style="margin-bottom: 10rpx;">
          <template #title>
            <div>
              <view class="text-padding" style="font-weight: 600;color: #323233;">{{ item.contractName }}</view>
              <view class="flex-between text-padding">
                <view>合同金额:{{ item.contractMoney }} 元</view>
                <view>计划付款:{{ item.totalPlanPayMoney }} 元</view>
              </view>
              <view class="flex-between text-padding">
                <view>合同税金: {{ item.taxesMoney }} 元</view>
                <view>已付金额:{{ item.totalPayMoney }} 元</view>
              </view>
              <view class="text-padding">{{ item.remark }}</view>
            </div>
          </template>
          <!-- 请款单 -->
          <view class="content-cell">
            <van-cell class="cell-name" v-for="items in item.planList" :key="items.id">
              <template #title>
                <view class="flex-between text-padding">
                  <view style="font-weight: 600;">{{ items.planDate }}</view>
                  <view>
                    <text style="font-weight: 600;">{{ `${items.planNo}期` }}</text>
                    <text v-if="items.planStatus === 0">(未到期)</text>
                    <text class="green-color" v-if="items.planStatus === 1">(已付款)</text>
                    <text style="color: red;" v-if="items.planStatus === 2">(预期中)</text>
                  </view>
                </view>
              </template>
              <template #label>
                <view class="flex-between text-padding">
                  <view class="text-nowrap">计划付款: {{ items.planMoney }} 元</view>
                  <view class="">已付金额: {{ items.realBackMoney }} 元</view>
                </view>
                <view class="text-padding">{{ items.remark }}</view>
              </template>
            </van-cell>
          </view>
        </van-collapse-item>
      </van-collapse>
      <van-empty v-if="detailData.length === 0" description="暂无数据" />
    </van-pull-refresh>
  </view>
</template>

<script>
import { contractsDetail } from '@/api/index.js';
export default {
  data() {
    return {
      isLoading: false,
      activeNames: '1',
      // 类型
      type: '',
      projectId: 0,
      // 详情数据
      detailData: []
    };
  },
  onLoad(option) {
    this.type = option.type;
    // 设置页面标题
    uni.setNavigationBarTitle({
      title: option.type
    });
    this.projectId = option.projectId;
    this.getData();
  },
  methods: {
    // 获取详情数据
    async getData() {
      try {
        let category;
        if (this.type === '项目外采合同付款概览') {
          category = 3;
        } else {
          category = 2;
        }
        let { data } = await contractsDetail({ category: category, projectId: this.projectId });
        this.detailData = data;
        this.isLoading = false;
      } catch (e) {
        //TODO handle the exception
      }
    }
  }
};
</script>

<style scoped lang="scss">
.content-cell ::v-deep .van-cell {
  padding: 0rpx;
}
::v-deep .van-empty {
  padding: 200rpx 0;
}
</style>

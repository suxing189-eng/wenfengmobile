<template>
  <view class="gray-bj-color" style="height: 100%;">
    <!-- 头部下拉 -->
    <van-dropdown-menu style="margin-bottom: 10rpx;">
      <van-dropdown-item v-model="dropdownValue" @change="dropdownChange" :title="year" :options="option" ref="datetime"></van-dropdown-item>
    </van-dropdown-menu>
    <!-- 列表展示 -->
    <van-cell value-class='van-table' title="回款合计" size="large" :value="yearTotalBackMoney">
      
    </van-cell>
    <van-cell>
      <template #title>
        <view class="flex-between">
          <view class="title">一月</view>
          <view class="content">{{ infoData.monthText_01 }}</view>
        </view>
      </template>
    </van-cell>
    <van-cell>
      <template #title>
        <view class="flex-between">
          <view class="title">二月</view>
          <view class="content">{{ infoData.monthText_02 }}</view>
        </view>
      </template>
    </van-cell>
    <van-cell>
      <template #title>
        <view class="flex-between">
          <view class="title">三月</view>
          <view class="content">{{ infoData.monthText_03 }}</view>
        </view>
      </template>
    </van-cell>
    <van-cell>
      <template #title>
        <view class="flex-between">
          <view class="title">四月</view>
          <view class="content">{{ infoData.monthText_04 }}</view>
        </view>
      </template>
    </van-cell>
    <van-cell>
      <template #title>
        <view class="flex-between">
          <view class="title">五月</view>
          <view class="content">{{ infoData.monthText_05 }}</view>
        </view>
      </template>
    </van-cell>
    <van-cell>
      <template #title>
        <view class="flex-between">
          <view class="title">六月</view>
          <view class="content">{{ infoData.monthText_06 }}</view>
        </view>
      </template>
    </van-cell>
    <van-cell>
      <template #title>
        <view class="flex-between">
          <view class="title">七月</view>
          <view class="content">{{ infoData.monthText_07 }}</view>
        </view>
      </template>
    </van-cell>
    <van-cell>
      <template #title>
        <view class="flex-between">
          <view class="title">八月</view>
          <view class="content">{{ infoData.monthText_08 }}</view>
        </view>
      </template>
    </van-cell>
    <van-cell>
      <template #title>
        <view class="flex-between">
          <view class="title">九月</view>
          <view class="content">{{ infoData.monthText_09 }}</view>
        </view>
      </template>
    </van-cell>
    <van-cell>
      <template #title>
        <view class="flex-between">
          <view class="title">十月</view>
          <view class="content">{{ infoData.monthText_10 }}</view>
        </view>
      </template>
    </van-cell>
    <van-cell>
      <template #title>
        <view class="flex-between">
          <view class="title">十一月</view>
          <view class="content">{{ infoData.monthText_11 }}</view>
        </view>
      </template>
    </van-cell>
    <van-cell>
      <template #title>
        <view class="flex-between">
          <view class="title">十二月</view>
          <view class="content">{{ infoData.monthText_12 }}</view>
        </view>
      </template>
    </van-cell>
  </view>
</template>

<script>
import { planPayRecord } from '@/api/index.js';
export default {
  data() {
    return {
      // 参数
      year: '2024年',
      queryYear: '',
      option: [],
      dropdownValue: 0,
      // 数据
      infoData: {},
      yearTotalBackMoney: 0
    };
  },
  onLoad() {
    this.year = new Date().getFullYear() + '年';
    this.queryYear = new Date().getFullYear() + '';
    // 计算显示时间
    let nowYear = new Date().getFullYear();
    this.option = [];
    for (let i = 0; i < 10; i++) {
      this.option.push({ text: nowYear + '年', value: i });
      nowYear--;
    }
    this.getData();
  },
  methods: {
    // 获取数据
    async getData() {
      try {
        let { data, yearTotalBackMoney } = await planPayRecord({ queryYear: this.queryYear });
        this.infoData = data;
        this.yearTotalBackMoney = yearTotalBackMoney;
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 选择回调
    dropdownChange(value) {
      let selectYear = this.option.filter(item => {
        return item.value === value;
      });
      this.year = selectYear[0].text;
      this.dropdownValue = value;
      this.queryYear = selectYear[0].text.slice(0, selectYear[0].text.indexOf('年'));
      this.getData();
    }
  }
};
</script>

<style scoped lang="scss">
.flex-between {
  .title {
    text-align: center;
    flex: 0 0 200rpx;
    border-right: 1px solid #f5f6f8;
  }
  .content {
    text-align: right;
    flex: 1;
  }
}
.van-table {
  font-weight: bold;
  color: #000;
  font-size: 32rpx;
}
</style>

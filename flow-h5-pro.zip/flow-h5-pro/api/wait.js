import request from "@/utils/request.js"

// 退出登录
export function doExit(data) {
  return request({
    url: 'AccAdmin/doExit',
    method: 'post',
    data: data
  })
}

export function AccAdminTodo(data) {
  return request({
    url: 'AccAdmin/todo',
    method: 'post',
    data: data
  })
}

// 查询待我审批
export function todoCount(data) {
  return request({
    url: 'Todo/count',
    method: 'post',
    data: data
  })
}

// 审批
export function todoList(data) {
  return request({
    url: 'Todo/list',
    method: 'post',
    data: data
  })
}

// 审批记录流程数据
export function executeHistory(data) {
  return request({
    url: 'FlwInstance/execute-history',
    method: 'post',
    data: data
  })
}

// 审批同意接口
export function examineAgree(data) {
  return request({
    url: '/FlwInstance/agree',
    method: 'post',
    data: data
  })
}

// 审批终止流程
export function examineTerminate(data) {
  return request({
    url: '/FlwInstance/terminate',
    method: 'post',
    data: data
  })
}

// 审批拒绝流程
export function examinerReject(data) {
  return request({
    url: '/FlwInstance/reject',
    method: 'post',
    data: data
  })
}

// 审批撤回流程
export function examinerRevoke(data) {
  return request({
    url: '/FlwInstance/revoke',
    method: 'post',
    data: data
  })
}

// 获取工程请款详情数据
export function applyBillGetById(data) {
  return request({
    url: '/ApplyBill/getById',
    method: 'post',
    data: data
  })
}

// 工程请款修改审批金额
export function applyBillMoney(data) {
  return request({
    url: '/ApplyBill/updateExamineMoney',
    method: 'post',
    data: data
  })
}

// 获取订货单审批详情数据
export function supplierOrderGetById(data) {
  return request({
    url: '/SupplierOrder/getById',
    method: 'post',
    data: data
  })
}

// 订货单修改审批金额
export function supplierOrderMoney(data) {
  return request({
    url: '/SupplierOrder/updateExamineMoney',
    method: 'post',
    data: data
  })
}

// 业务登记数据
export function businessList(data) {
  return request({
    url: '/Business/getList',
    method: 'post',
    data: data
  })
}

// 业务人员看板数据
export function kanbanList(data) {
  return request({
    url: '/Business/kanban',
    method: 'post',
    data: data
  })
}

// 业务人员详情数据
export function getUserStats(data) {
  return request({
    url: 'Business/getUserStats',
    method: 'post',
    data: data
  })
}

// 我的消息数据列表
export function massageList(data) {
  return request({
    url: '/message/getList',
    method: 'post',
    data: data
  })
}

// 我的消息数据数量
export function messageCount(data) {
  return request({
    url: '/message/count',
    method: 'post',
    data: data
  })
}

// 我的消息详情信息
export function messageDetail(data) {
  return request({
    url: '/message/getById',
    method: 'post',
    data: data
  })
}

// 客户详情数据
export function customerGetById(data) {
  return request({
    url: '/Customer/getById',
    method: 'post',
    data: data
  })
}

// 供应商详情数据
export function supplierGetById(data) {
  return request({
    url: '/Supplier/getById',
    method: 'post',
    data: data
  })
}

// 工程详情数据
// export function projectGetById(id) {
//   return request({
//     url: '/Project/getById?id=' + id,
//     method: 'post',
//   })
// }

// 提成详情数据
export function commissionGetById(data) {
  return request({
    url: '/ProjectCommission/getById',
    method: 'post',
    data: data
  })
}

// 变更清单详情数据
export function ChangeGetById(data) {
  return request({
    url: '/ChangeList/getById',
    method: 'post',
    data: data
  })
}

// 结算单详情数据
export function statementGetById(data) {
  return request({
    url: '/Statement/getById',
    method: 'post',
    data: data
  })
}

// 经营费用详情数据
export function manageCostGetById(data) {
  return request({
    url: '/ManageCost/getById',
    method: 'post',
    data: data
  })
}

// 行政详情数据
export function ApprovalFormGetById(data) {
  return request({
    url: '/ApprovalForm/getById',
    method: 'post',
    data: data
  })
}

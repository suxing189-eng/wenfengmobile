import request from "@/utils/request.js"

export function login(data) {
  return request({
    url: 'AccAdmin/doLogin',
    method: 'post',
    data: data
  })
}

export function getCfg(data) {
  return request({
    url: 'SpCfg/getCfg',
    method: 'post',
    data: data
  })
}

// 退出页面 项目经理信息
export function cardInfo(data) {
  return request({
    url: 'ProjectManager/cardInfo',
    method: 'post',
    data: data
  })
}

// 用户登录信息
export function getByCurr(data) {
  return request({
    url: 'admin/getByCurr',
    method: 'post',
    data: data
  })
}

// 用户修改名称
export function updateInfo(data) {
  return request({
    url: '/admin/updateInfo',
    method: 'post',
    data: data
  })
}

// 用户修改密码
export function adminPassword(data) {
  return request({
    url: '/AdminPassword/update',
    method: 'post',
    data: data
  })
}

// 用户修改头像
export function updateAvatar(data) {
  return request({
    url: '/admin/updateAvatar',
    method: 'post',
    data: data
  })
}

import request from "@/utils/request.js"

// 获取施工动态
export function projectTrend(data) {
  return request({
    url: 'ProjectTrend/index',
    method: 'post',
    data: data
  })
}

// 待整改提醒
export function patrolRemind(data) {
  return request({
    url: '/ProjectTrend/patrol/remind',
    method: 'post',
    data: data
  })
}

// 获取整改数据详情
export function trendDetail(data) {
  return request({
    url: '/ProjectTrend/getById',
    method: 'post',
    data: data
  })
}

// 整改上传
export function trendSolve(data) {
  return request({
    url: '/ProjectTrend/solve',
    method: 'post',
    data: data
  })
}

// 整改关闭
export function trendSlose(data) {
  return request({
    url: '/ProjectTrend/close',
    method: 'post',
    data: data
  })
}
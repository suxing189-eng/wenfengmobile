import request from "@/utils/request.js"

// 获取首页九宫格数据
export function quickMenu(data) {
  return request({
    url: 'AccAdmin/quickMenu',
    method: 'post',
    data: data
  })
}

// 我的客户列表
export function mineCustomer(data) {
  return request({
    url: 'Customer/mineList',
    method: 'post',
    data: data
  })
}

// 所有客户列表
export function allCustomer(data) {
  return request({
    url: 'Customer/getList',
    method: 'post',
    data: data
  })
}

// 我的工程
export function mineProject(data) {
  return request({
    url: 'Project/mineList',
    method: 'post',
    data: data
  })
}

// 所有工程
export function allProject(data) {
  return request({
    url: 'Project/getList',
    method: 'post',
    data: data
  })
}

// 在建工程
export function buildingList(data) {
  return request({
    url: 'Project/buildingList',
    method: 'post',
    data: data
  })
}

// 应收款工程
export function overdueList(data) {
  return request({
    url: 'Project/overdueList',
    method: 'post',
    data: data
  })
}

// 待验收工程queryState=1 待核算工程queryState=2 待结算工程queryState=3
export function stateList(data) {
  return request({
    url: 'Project/stateList',
    method: 'post',
    data: data
  })
}

// 工程详情
export function projectDetail(data) {
  return request({
    url: 'Project/getById?id=' + data.id,
    method: 'post',
  })
}

// 合同信息
export function contractsList(data) {
  return request({
    url: 'Project/contracts',
    method: 'post',
    data: data
  })
}

// 回款信息
export function plansList(data) {
  return request({
    url: 'Project/plans',
    method: 'post',
    data: data
  })
}

// 请款单
export function applyBillData(data) {
  return request({
    url: 'ApplyBill/getList',
    method: 'post',
    data: data
  })
}

// 材料单
export function supplierOrder(data) {
  return request({
    url: 'SupplierOrder/getList',
    method: 'post',
    data: data
  })
}

// 支出信息
export function paymentList(data) {
  return request({
    url: 'ProjectPayment/getList',
    method: 'post',
    data: data
  })
}

// 字典接口
export function dictList(data) {
  return request({
    url: '/SysDictData/getList',
    method: 'post',
    data: data
  })
}

// 查询施工动态数据
export function ProjectTrendList(data) {
  return request({
    url: '/ProjectTrend/getList',
    method: 'post',
    data: data
  })
}

// 施工日志
export function projectTrendAdd(data) {
  return request({
    url: '/ProjectTrend/add',
    method: 'post',
    data: data
  })
}

// 获取工程人员列表
export function ProjectUserList(data) {
  return request({
    url: '/ProjectUser/getList',
    method: 'post',
    data: data
  })
}

// 删除施工动态
export function ProjectTrendDelete(data) {
  return request({
    url: '/ProjectTrend/delete',
    method: 'post',
    data: data
  })
}

// 查询供应商列表
export function supplierList(data) {
  return request({
    url: 'Supplier/getList',
    method: 'post',
    data: data
  })
}

// 查询请款单
export function applyBillHistory(data) {
  return request({
    url: 'ApplyBill/history',
    method: 'post',
    data: data
  })
}

// 查询材料单
export function supplierOrderHistory(data) {
  return request({
    url: 'SupplierOrder/history',
    method: 'post',
    data: data
  })
}

// 到期回款计划
export function expiredBackList(data) {
  return request({
    url: 'ContractPlan/expiredBackList',
    method: 'post',
    data: data
  })
}

// 外采到期未付
export function expiredPayList(data) {
  return request({
    url: 'ContractPlan/expiredPayList',
    method: 'post',
    data: data
  })
}

// 回款记录数据
export function planPayRecord(data) {
  return request({
    url: 'ContractPlanPay/record',
    method: 'post',
    data: data
  })
}

// 工程付款流水
export function PaymentRecord(data) {
  return request({
    url: 'ProjectPayment/record',
    method: 'post',
    data: data
  })
}

// 外采
export function ContractPlanOverview(data) {
  return request({
    url: 'ContractPlan/overview',
    method: 'post',
    data: data
  })
}

// 提成支付记录
export function ProjectCommission(data) {
  return request({
    url: 'ProjectCommission/getList',
    method: 'post',
    data: data
  })
}

// 考勤打卡
export function ProjectWorker(data) {
  return request({
    url: 'ProjectWorker/getList',
    method: 'post',
    data: data
  })
}

// 工人的打卡详情
export function getClockRecord(data) {
  return request({
    url: 'ProjectWorker/getClockRecord',
    method: 'post',
    data: data
  })
}

// 工人缺卡列表数据
export function absentList(data) {
  return request({
    url: 'ProjectWorker/absentList',
    method: 'post',
    data: data
  })
}

// 月度经营报表
export function monthReport(data) {
  return request({
    url: 'BI/ManageCost/monthReport',
    method: 'post',
    data: data
  })
}

// 经营成本费用
export function manageCostList(data) {
  return request({
    url: 'ManageCost/getList',
    method: 'post',
    data: data
  })
}

// 合同外采详情
export function contractsDetail(data) {
  return request({
    url: '/Project/contracts',
    method: 'post',
    data: data
  })
}

// 业务基本信息
export function businessGetById(data) {
  return request({
    url: '/Business/getById',
    method: 'post',
    data: data
  })
}

// 业务跟进信息
export function followRecordList(data) {
  return request({
    url: '/BusinessFollowRecord/getList',
    method: 'post',
    data: data
  })
}

// 删除跟进信息
export function followRecordDelete(id) {
  return request({
    url: '/BusinessFollowRecord/delete?id=' + id,
    method: 'post',
  })
}

// 新增业务跟进
export function businessFollowRecordAdd(data) {
  return request({
    url: '/BusinessFollowRecord/add',
    method: 'post',
    data: data
  })
}

// 整改数据
export function patrolCase(data) {
  return request({
    url: '/ProjectTrend/patrol/case',
    method: 'post',
    data: data
  })
}

// 获取施工内容
export function getCfg(data) {
  return request({
    url: '/SpCfg/getCfg?cfgName=' + data.cfgName,
    method: 'post',
  })
}

// 利润表
export function profitList(data) {
  return request({
    url: '/BI/profit/report',
    method: 'post',
    data: data
  })
}

// 报价查询
export function offerBomList(data) {
  return request({
    url: '/offerBom/getList',
    method: 'post',
    data: data
  })
}

// 花名册请款人
export function workerRoster(data) {
  return request({
    url: '/workerRoster/choose',
    method: 'post',
    data: data
  })
}

// 打卡名单请款人
export function ProjectWorkerChoose(data) {
  return request({
    url: '/ProjectWorker/choose',
    method: 'post',
    data: data
  })
}

// 查询工程班组
export function teamGroup(data) {
  return request({
    url: '/TeamGroup/getList',
    method: 'post',
    data: data
  })
}

// 添加申请请款单
export function addApplyBill(data) {
  return request({
    url: '/ApplyBill/add',
    method: 'post',
    data: data
  })
}

// 填写请款单是否显示
export function sysCfg(data) {
  return request({
    url: '/SpCfg/sysCfg',
    method: 'post',
    data: data
  })
}

// 甘特图数据
export function ganttList(data) {
  return request({
    url: '/Gantt/getList',
    method: 'post',
    data: data
  })
}

// 甘特图详情数据
export function ganttGetById(data) {
  return request({
    url: '/Gantt/getById',
    method: 'post',
    data: data
  })
}

// 修改甘特图
export function ganttUpdate(data) {
  return request({
    url: '/Gantt/update',
    method: 'post',
    data: data
  })
}

// 合同统计
export function getContractStatistics(data) {
  return request({
    url: '/contract/statistics',
    method: 'post',
    data: data
  })
}

// 供应商送货工程
export function supplierProject(data) {
  return request({
    url: '/Supplier/projectList',
    method: 'post',
    data: data
  })
}

// 供应商送货工程
export function supplierContract(data) {
  return request({
    url: '/Supplier/contractList',
    method: 'post',
    data: data
  })
}

// 请款单详情
export function applyBillDetail(data) {
  return request({
    url: 'ApplyBill/getById',
    method: 'post',
    data: data
  })
}

// 获取请款单流程
export function processTemplate(data) {
  return request({
    url: 'ProcessTemplates/choose',
    method: 'post',
    data: data
  })
}

// 提交请款单
export function applyBIllCommit(data) {
  return request({
    url: 'ApplyBill/commit',
    method: 'post',
    data: data
  })
}

// 删除请款单
export function applyBIllDelete(data) {
  return request({
    url: 'ApplyBill/delete',
    method: 'post',
    data: data
  })
}

// 编辑请款单
export function applyBIllUpdate(data) {
  return request({
    url: 'ApplyBill/update',
    method: 'post',
    data: data
  })
}

// 签单工程
export function customerProjectList(data) {
  return request({
    url: 'Customer/projectList',
    method: 'post',
    data: data
  })
}

// 分享URl
export function getShareUrl(data) {
  return request({
    url: '/ProjectTrend/getShareUrl',
    method: 'post',
    data: data
  })
}

// 补卡
export function repairClock(data) {
  return request({
    url: '/ProjectWorker/repairClock',
    method: 'post',
    data: data
  })
}

// 修改日工价
export function ProjectWorkerUpdate(data) {
  return request({
    url: '/ProjectWorker/updateByNotNull',
    method: 'post',
    data: data
  })
}

// 花名册
export function workerRosterList(data) {
  return request({
    url: '/WorkerRoster/getList',
    method: 'post',
    data: data
  })
}

// 新增花名册
export function workerRosterAdd(data) {
  return request({
    url: '/WorkerRoster/add',
    method: 'post',
    data: data
  })
}

// 编辑花名册
export function workerRosterUpdate(data) {
  return request({
    url: '/WorkerRoster/update',
    method: 'post',
    data: data
  })
}

// 缺工资卡人员
export function absentBankList(data) {
  return request({
    url: '/ProjectWorker/absentBankList',
    method: 'post',
    data: data
  })
}

// 选择工程列表
export function chooseProject(data) {
  return request({
    url: '/Project/choose',
    method: 'post',
    data: data
  })
}

// 巡检节点
export function trendNode(data) {
  return request({
    url: '/TrendNode/getAppList',
    method: 'post',
    data: data
  })
}

// 巡检内容项
export function getOptionList(data) {
  return request({
    url: '/TrendNode/getOptionList',
    method: 'post',
    data: data
  })
}

// 保存巡检项
export function projectTrendSave(data) {
  return request({
    url: '/ProjectTrend/save',
    method: 'post',
    data: data
  })
}

// 证书集合
export function getTypeListCert(data) {
  return request({
    url: '/CertRepo/getTypeList',
    method: 'get',
    data: data
  })
}

// 证书数据
export function getListCert(data) {
  return request({
    url: '/CertRepo/getList',
    method: 'post',
    data: data
  })
}

// 文档侧边栏
export function projectFolder(data) {
  return request({
    url: '/ProjectFolder/getTree',
    method: 'post',
    data: data
  })
}
// 文档数据
export function getListFile(data) {
  return request({
    url: '/ProjectFolderFile/getList',
    method: 'post',
    data: data
  })
}

export default {
  userInfo: state => state.user.userInfo,
  perList: state => state.user.perList,
  handleList: state => state.user.handleList,
}

export default {
  namespaced: true,
  state: {
    // 用户信息
    userInfo: {},
    // 权限
    perList: [],
    // 审批操作的数据
    handleList: []
  },
  mutations: {
    // 用户信息
    USER_INFO(state, userInfo) {
      state.userInfo = userInfo;
    },
    // 权限
    PER_LIST(state, perList) {
      state.perList = perList;
    },
    HANDLE_LIST(state, handleList) {
      state.handleList = handleList;
    },
  },
  actions: {}
}

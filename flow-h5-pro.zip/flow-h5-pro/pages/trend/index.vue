<template>
  <view class="gray-bj-color-trend">
    <van-tabs v-model="active" sticky offset-top="44px" @change="tabChange" title-inactive-color="#666666" title-active-color="#000">
      <van-tab title="每日动态"><everyday-state ref="everyday"></everyday-state></van-tab>
      <van-tab title="待整改">
        <view class="header">
          <van-radio-group v-model="queryParams.queryType" @change="radioChange" direction="horizontal">
            <van-radio name="mine">待我整改</van-radio>
            <van-radio name="all">全部</van-radio>
          </van-radio-group>
        </view>
        <patrol-view class="mt-10" :trendData="trendData"></patrol-view>
        <view class="gray-bj-color" style="height: 92rpx;width: 100%;"></view>
      </van-tab>
      <van-tab title="待验证">
        <view class="header">
          <van-radio-group v-model="queryParams.queryType" @change="radioChange" direction="horizontal">
            <van-radio name="mine">待我验证</van-radio>
            <van-radio name="all">全部</van-radio>
          </van-radio-group>
        </view>
        <patrol-view class="mt-10" :trendData="trendData" @initData="initData"></patrol-view>
        <view style="height: 92rpx;width: 100%;"></view>
      </van-tab>
      <van-tab title="已整改">
        <!-- 列表 上拉加载 -->
        <view class="gray-bj-color">
          <van-list v-model="loading" :finished="finished" :finished-text="finishedText" @load="upwardPull">
            <patrol-view class="mt-10" :trendData="trendData"></patrol-view>
          </van-list>
          <view style="height: 92rpx;width: 100%;"></view>
        </view>
      </van-tab>
    </van-tabs>
  </view>
</template>

<script>
import everydayState from '@/index-pkg/components/everydayState.vue';
import patrolView from '@/index-pkg/components/patrolView.vue';
import { patrolCase } from '@/api/index.js';
export default {
  components: {
    everydayState,
    patrolView
  },
  data() {
    return {
      queryParams: {
        pageNo: 0,
        pageSize: 10,
        trendState: 1,
        queryType: 'mine'
      },
      active: 0,
      // 整改数据
      trendData: [],
      // 下拉状态
      loading: false,
      // 是否已加载完成
      finished: false,
      // 加载完成文字
      finishedText: '没有更多了'
    };
  },
  onShow() {
    this.$nextTick(() => {
      this.$refs.everyday.remind();
    });
    this.getData();
  },
  methods: {
    initData() {
      this.getData();
    },
    // 获取整改数据
    async getData() {
      try {
        let { data, dataCount } = await patrolCase(this.queryParams);
        this.loading = false;
        this.trendData = data;
      } catch (e) {
        //TODO handle the exception
      }
    },
    async getListData() {
      try {
        let { data, dataCount } = await patrolCase(this.queryParams);
        this.loading = false;
        this.trendData = this.trendData.concat(data);
        if (this.queryParams.pageNo * this.queryParams.pageSize > dataCount) {
          this.finished = true;
        }
        if (dataCount === 0) {
          this.finishedText = '';
        } else {
          this.finishedText = '没有更多了...';
        }
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 上拉回调
    upwardPull() {
      this.queryParams.pageNo += 1;
      if (this.queryParams.pageNo * this.queryParams.pageSize > this.trendData.length) {
        return;
      }
      this.getListData();
    },
    // 单选回调
    radioChange() {
      this.getData();
    },
    // tab回调函数
    tabChange(value) {
      if (value === 0) {
        this.$refs.everyday.remind();
      } else {
        if (value === 3) {
          this.trendData = [];
          this.queryParams.pageNo = 1;
          this.queryParams.trendState = value;
          this.getListData();
        } else {
          this.queryParams.trendState = value;
          this.queryParams.pageNo = 1;
          this.trendData = [];
          this.getData();
        }
      }
    }
  }
};
</script>

<style scoped lang="scss">
.header {
  background-color: #fff;
  padding: 26rpx;
  margin-top: 20rpx;
}
::v-deep .van-list__finished-text {
  background-color: #f2f2f2 !important;
}
.van-empty {
  padding: 40rpx 0;
}
::v-deep .van-pull-refresh {
  height: calc(100vh - 160rpx);
  overflow: auto;
}
</style>

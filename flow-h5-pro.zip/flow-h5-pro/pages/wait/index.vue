<template>
  <view class="gray-bj-color">
    <van-pull-refresh v-model="isLoading" @refresh="handleQuery">
      <view class="tab"></view>
      <van-grid clickable :column-num="2" style="background-color: #fff;">
        <!-- <van-grid-item @click="tabExamine" icon="records-o" text="待我审批" :badge="info.examineCount" /> -->
        <van-grid-item @click="tabMessage" icon="chat-o" text="我的消息" :badge="messageCount" />
        <van-grid-item @click="tabTask" icon="todo-list-o" text="待办任务" :badge="info.taskCount ? info.taskCount : ''" />
      </van-grid>
      <!-- 待我审批 -->
      <view class="header-title">
        待我审批
        <text style="margin-left: 5px;">(下拉可以刷新待我审批数量)</text>
      </view>
      <van-grid clickable :column-num="2">
        <van-grid-item v-for="item in examineData" :key="item.bizCode" @click="tabDetail(item.bizCode)">
          <view>
            <view class="count-text">{{ item.count }}</view>
            <view class="content-text">{{ item.bizName }}</view>
          </view>
        </van-grid-item>
      </van-grid>
    </van-pull-refresh>
  </view>
</template>

<script>
import { mapGetters } from 'vuex';
import { AccAdminTodo, messageCount, todoCount } from '@/api/wait.js';
export default {
  data() {
    return {
      // 概览信息
      info: {
        examineCount: 0,
        taskCount: 0
      },
      messageCount: 0,
      isLoading: false,
      // 审批数据
      examineData: []
    };
  },
  computed: {
    ...mapGetters(['userInfo'])
  },
  onShow() {
    this.getData();
    this.getExamine();
  },
  onLoad() {
    // console.log('======================>vuex存储的数据',this.userInfo);
  },
  methods: {
    // 获取页面数据
    async getData() {
      try {
        let { data } = await AccAdminTodo();
        this.info = {
          examineCount: data.examineCount,
          taskCount: data.taskCount
        };
        // 我的消息
        let { data: messageData } = await messageCount();
        this.messageCount = messageData || 0;
        this.isLoading = false;
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 获取数据
    async getExamine() {
      try {
        let { data } = await todoCount({
          bizCodeList: 'EX-ADD-CUSTOMER,EX-ADD-SUPPLIER,EX-ADD-PROJECT,EX-PROJECT-APPLY,EX-PROJECT-ORDER,EX-PROJECT-COMMISSION,EX-PROJECT-STATEMENT,EX-MANAGE-COST'
        });
        this.examineData = data.filter(item => {
          return item.count > 0;
        });
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 刷新页面
    handleQuery() {
      this.getExamine();
      this.getData();
    },
    // 打开待我审批页面
    tabExamine() {
      uni.navigateTo({ url: '/wait-pkg/examine' });
    },
    // 打开待办任务页面
    tabTask() {
      uni.navigateTo({ url: '/wait-pkg/backlogTask' });
    },
    // 打开我的消息页面
    tabMessage() {
      uni.navigateTo({ url: '/wait-pkg/myMessage' });
    },
    // 进入宫格详情
    tabDetail(value) {
      if (value === 'EX-ADD-CUSTOMER') {
        // 客户
        uni.navigateTo({ url: '/wait-pkg/customerExamine' });
      } else if (value === 'EX-ADD-SUPPLIER') {
        // 供应商
        uni.navigateTo({ url: '/wait-pkg/supplierExamine' });
      } else if (value === 'EX-ADD-PROJECT') {
        // 通知签单
        uni.navigateTo({ url: '/wait-pkg/projectEaxmine' });
      } else if (value === 'EX-PROJECT-APPLY') {
        // 工程请款
        uni.navigateTo({ url: '/wait-pkg/projectApplyExamine' });
      } else if (value === 'EX-PROJECT-ORDER') {
        // 材料单
        uni.navigateTo({ url: '/wait-pkg/projectOrderExamine' });
      } else if (value === 'EX-PROJECT-COMMISSION') {
        // 提成支付
        uni.navigateTo({ url: '/wait-pkg/commissionExamine' });
      } else if (value === 'EX-PROJECT-STATEMENT') {
        // 结算单
        uni.navigateTo({ url: '/wait-pkg/statementExamine' });
      } else if (value === 'EX-MANAGE-COST') {
        // 经营成本
        uni.navigateTo({ url: '/wait-pkg/costExamine' });
      } else if (value === 'EX-OA-APPROVAL') {
        // 行政审批
        uni.navigateTo({ url: '/wait-pkg/oaExamine' });
      } else if (value === 'EX-CHANGE-LIST') {
        // 变更清单
        uni.navigateTo({ url: '/wait-pkg/changeExamine' });
      } else {
        return;
      }
    }
  }
};
</script>

<style scoped lang="scss">
::v-deep .van-pull-refresh {
  overflow: auto;
}
.header-title {
  padding: 50rpx 20rpx 20rpx 20rpx;
  color: #8c99a0;
  font-size: 26rpx;
}
.content-text {
  color: #646566;
  text-align: center;
  font-size: 28rpx;
  margin-top: 22rpx;
}

.count-text {
  color: #646566;
  text-align: center;
  font-size: 32rpx;
  font-weight: bold;
}

::v-deep .van-grid-item__content {
  padding: 30rpx 16rpx 10rpx 16rpx;
}
</style>

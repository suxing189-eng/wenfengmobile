<template>
  <view class="box">
    <!-- 登录页面 -->
    <view class="login-text">
      <image style="width: 100px;height: 100px;margin-bottom: 15px;" :src="configuration.logoUrl" mode=""></image>
      <view class="">{{ configuration.appName }}</view>
    </view>
    <van-form @submit="onSubmit">
      <van-field v-model="username" name="用户名" label="用户名" placeholder="用户名" :rules="[{ required: true, message: '请填写用户名' }]"></van-field>
      <van-field v-model="password" type="password" name="密码" label="密码" placeholder="密码" :rules="[{ required: true, message: '请填写密码' }]"></van-field>
      <div style="margin: 16px;">
        <van-button v-if="!subLoading" round block type="info" native-type="submit">登 录</van-button>
        <van-button v-else round block loading type="info" loading-text="登录中..."></van-button>
      </div>
    </van-form>
    <!-- 底部公司名称 -->
    <view class="company">{{ configuration.companyName }}</view>
  </view>
</template>

<script>
import { login, getCfg } from '@/api/login.js';
import { mapMutations } from 'vuex';
import Cookies from 'js-cookie';
export default {
  data() {
    return {
      username: '',
      password: '',
      // 登录中显示
      subLoading: false,
      configuration: {}
    };
  },
  onLoad() {
    this.initData();
    this.getCookie();
  },
  methods: {
    ...mapMutations('user', ['USER_INFO', 'PER_LIST']),
    // 获取登录页配置
    async initData() {
      try {
        let { data } = await getCfg({ cfgName: 'app_cfg' });
        this.configuration = JSON.parse(data);
      } catch (e) {
        //TODO handle the exception
      }
    },
    // 获取cookie
    getCookie() {
      const h5_username = Cookies.get('h5_username');
      const h5_password = Cookies.get('h5_password');
      this.username = h5_username === undefined ? this.username : h5_username;
      this.password = h5_password === undefined ? this.password : h5_password;
    },
    // 表单保存按钮
    async onSubmit(values) {
      try {
        this.subLoading = true;
        Cookies.set('h5_username', this.username, { expires: 30 });
        Cookies.set('h5_password', this.password, { expires: 30 });
        let form = {
          key: this.username,
          password: this.password
        };
        let { data } = await login(form);
        await this.USER_INFO(data.admin);
        await this.PER_LIST(data.perList);
        sessionStorage.setItem('perList', data.perList);
        // 写入token
        if (data.tokenInfo) {
          sessionStorage.removeItem('satoken');
          sessionStorage.setItem('satoken', data.tokenInfo.tokenValue);
          setTimeout(() => {
            this.subLoading = false;
            uni.reLaunch({
              url: '/pages/index/index'
            });
          }, 200);
        }
      } catch (e) {
        this.subLoading = false;
        //TODO handle the exception
      }
    }
    // cookie缓存方法
    // setCookie(name, value, daysToLive) {
    //   let cookie = name + '=' + encodeURIComponent(value);
    //   if (typeof daysToLive === 'number') {
    //     cookie += '; max-age=' + daysToLive * 24 * 60 * 60; // 将天数转换为秒数
    //   }
    //   document.cookie = cookie;
    // },
    // // 读取cookie
    // getCookie(name) {
    //   const cookies = document.cookie.split('; ');
    //   for (let i = 0; i < cookies.length; i++) {
    //     const [cookieName, cookieValue] = cookies[i].split('=');
    //     if (name === cookieName) {
    //       return decodeURIComponent(cookieValue);
    //     }
    //   }
    //   return '';
    // }
  }
};
</script>

<style scoped lang="scss">
@function rpx2em($rpx) {
  @return ($rpx / 16) * 1rem;
}
.login-text {
  font-weight: 600;
  text-align: center;
  font-size: rpx2em(22);
  padding-top: rpx2em(120);
  margin-bottom: rpx2em(40);
}
.box {
  height: 100%;
  position: relative;
  .company {
    width: 100%;
    padding: rpx2em(5);
    position: absolute;
    bottom: rpx2em(30);
    font-size: rpx2em(11);
    text-align: center;
    color: #646566;
  }
}
</style>

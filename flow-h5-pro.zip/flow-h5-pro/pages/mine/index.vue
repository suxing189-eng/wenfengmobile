<template>
  <view class="gray-bj-color" style="height: 100%">
    <!-- 用户信息 -->
    <view style="background-color: #fff;">
      <view class="header-title van-hairline--bottom">
        <text>
          欢迎你，{{ userInfo.nickName }}
          <van-icon @click="openUserInfo" class="icon-set" name="setting" size="22" />
        </text>
      </view>
      <view class="content">
        <view class="portrait"><image style="width: 100%;height: 100%;" :src="userInfo.avatar" mode=""></image></view>
        <view class="text-padding">
          <view class="">手机号：{{ userInfo.phone }}</view>
          <view class="">所属部门：{{ userInfo.deptName }}</view>
          <view class="">最后登录：{{ userInfo.loginTime }}</view>
          <view class="">登录IP：{{ userInfo.loginIp }}</view>
          <view class="">创建时间：{{ userInfo.createTime }}</view>
        </view>
      </view>
    </view>
    <!-- 信息 -->
    <!-- 项目经理 -->
    <view v-if="projectInfo.showCard !== 0 && projectInfo.cardType === 1" class="mt-10" style="background-color: #fff;">
      <van-panel class="">
        <template #header>
          <view class="header">
            <view class="flex-between text-header">
              <view class="">
                <text class="text-name">{{ projectInfo.realName }}</text>
                {{ projectInfo.age }}
              </view>
              <view class="" style="color: red;">{{ `${projectInfo.waitUpgradeCount}个待整改` }}</view>
              <view v-if="projectInfo.orderStatus === '1'" style="color: #00cc00;">可接小单</view>
              <view v-if="projectInfo.orderStatus === '0'" style="color: red;">不可接单</view>
              <view v-if="projectInfo.orderStatus === '2'" style="color: #00cc00;">可接单</view>
            </view>
            <view class="flex-between text-header">
              <view class="" style="color: #666666;">{{ projectInfo.starLevel }}</view>
              <view class="" style="color: #666666;">{{ projectInfo.socialStatus }}</view>
              <view v-if="projectInfo.signStatus === '1'" style="color: #00cc00;">已签约</view>
              <view v-if="projectInfo.signStatus === '0'" style="color: red;">未签约</view>
            </view>
          </view>
        </template>
        <view class="content-box">
          <view class="flex-between text-center">
            <view class="flex-between flex-width-left">
              <view>在建工程数</view>
              <view>{{ `${projectInfo.buildingProjectCount}个` }}</view>
            </view>
            <view class="flex-between flex-width-right">
              <view class="">应收进度款</view>
              <view>{{ projectInfo.totalRemainBackMoney }}</view>
            </view>
          </view>
          <view class="flex-between text-center">
            <view class="flex-between flex-width-left">
              <view>验收单未回</view>
              <view>{{ `${projectInfo.waitingDoneWorkImageCount}个` }}</view>
            </view>
            <view class="flex-between flex-width-right">
              <view class="">物业押金</view>
              <view>{{ projectInfo.totalDepositMoney }}</view>
            </view>
          </view>
          <view class="flex-between text-center">
            <view class="flex-between flex-width-left">
              <view>今年接单数</view>
              <view>{{ `${projectInfo.yearProjectCount || 0}个` }}</view>
            </view>
            <view class="flex-between flex-width-right">
              <view class="">今年接单总额</view>
              <view>{{ projectInfo.yearProjectMoney }}</view>
            </view>
          </view>
          <view class="flex-between text-center">
            <view class="flex-between flex-width-left">
              <view>质量保证金</view>
              <view>{{ projectInfo.bondMoney }}</view>
            </view>
            <view class="flex-between flex-width-right">
              <view class="">累计接单总额</view>
              <view>{{ projectInfo.totalProjectMoney }}</view>
            </view>
          </view>
        </view>
      </van-panel>
    </view>
    <!-- 工程经理 -->
    <view v-if="projectInfo.showCard !== 0 && projectInfo.cardType === 2" class="mt-10" style="background-color: #fff;">
      <van-panel class="">
        <template #header>
          <view class="header">
            <view class="flex-between text-header">
              <view class="">
                <text class="text-name">{{ projectInfo.realName }}</text>
                {{ projectInfo.age }}
              </view>
            </view>
            <view class="flex-between text-header" style="color: #666">
              <view class="">
                本月巡检:
                <text>{{ `${projectInfo.patrolCount}次` }}</text>
              </view>
              <view class="">
                发起整改:
                <text>{{ `${projectInfo.upgradeCount}次` }}</text>
              </view>
              <view class="">
                待我验证:
                <text>{{ `${projectInfo.waitCloseCount}次` }}</text>
              </view>
            </view>
          </view>
        </template>
        <view class="content-box">
          <view class="flex-between text-center">
            <view class="flex-between flex-width-left">
              <view>在建工程数</view>
              <view>{{ `${projectInfo.buildingProjectCount}个` }}</view>
            </view>
            <view class="flex-between flex-width-right">
              <view class="">应收进度款</view>
              <view>{{ projectInfo.totalRemainBackMoney }}</view>
            </view>
          </view>
          <view class="flex-between text-center">
            <view class="flex-between flex-width-left">
              <view>验收单未回</view>
              <view>{{ `${projectInfo.waitingDoneWorkImageCount}个` }}</view>
            </view>
            <view class="flex-between flex-width-right">
              <view class="">物业押金</view>
              <view>{{ projectInfo.totalDepositMoney }}</view>
            </view>
          </view>
        </view>
      </van-panel>
    </view>
    <!-- 退出登录 -->
    <view style="margin: 40rpx 20rpx;"><van-button @click="quitLogin" type="danger" size="normal" round>退出登录</van-button></view>
  </view>
</template>

<script>
import { mapState } from 'vuex';
import { doExit } from '@/api/wait.js';
import { cardInfo } from '@/api/login.js';
export default {
  data() {
    return {
      // 项目经理用户信息
      projectInfo: {
        showCard: 0
      }
    };
  },
  computed: {
    ...mapState('user', ['userInfo'])
  },
  onLoad() {
    this.initData();
  },
  methods: {
    async initData() {
      let { data } = await cardInfo();
      this.projectInfo = data;
    },
    // 打开用户信息
    openUserInfo() {
      uni.navigateTo({ url: '/wait-pkg/userInfo' }); // 客户
    },
    // 退出登录
    async quitLogin() {
      try {
        let { msg } = await doExit();
        this.Toast('已退出登录');
        sessionStorage.removeItem('satoken');
        sessionStorage.removeItem('perList');
        sessionStorage.removeItem('sys_app_bill_state');
        sessionStorage.removeItem('sys_gantt_state');
        uni.navigateTo({ url: '/pages/login/index' });
      } catch (e) {
        //TODO handle the exception
      }
    }
  }
};
</script>

<style scoped lang="scss">
@function rpx2em($rpx) {
  @return ($rpx / 16) * 1rem;
}
.header-title {
  font-size: rpx2em(18);
  font-weight: 600;
  text-align: center;
  padding: rpx2em(20) 0;
  position: relative;
}
.content {
  padding: rpx2em(25) 0;
  display: flex;
  .portrait {
    width: rpx2em(100);
    height: rpx2em(100);
    padding: 0 rpx2em(16);
    image {
      border-radius: 50%;
    }
  }
}
::v-deep .van-button--normal {
  width: 100%;
}
.icon-set {
  position: absolute;
  top: rpx2em(22);
  right: rpx2em(25);
}
.text-header {
  padding: rpx2em(5) 0;
  font-size: rpx2em(13);
}

.text-center {
  padding: rpx2em(8) 0;
  font-size: rpx2em(13);
}
.flex-width-left {
  flex: 0 0 calc(50% - 1rem);
  margin: 0 rpx2em(4);
  padding: rpx2em(4);
  background-color: #eeeeee;
}
.flex-width-right {
  flex: 0 0 calc(50% - 1rem);
  margin: 0 rpx2em(4);
  padding: rpx2em(4);
  line-height: rpx2em(19);

  background-color: #eeeeee;
}
.text-center {
  padding: rpx2em(4) 0;
}
.header {
  padding: rpx2em(9) rpx2em(12) rpx2em(0) rpx2em(12);
}
.text-name {
  font-weight: 600;
  font-size: rpx2em(16);
  margin-right: rpx2em(10);
}
.content-box {
  padding: rpx2em(0) rpx2em(8);
  color: #000;
}
</style>

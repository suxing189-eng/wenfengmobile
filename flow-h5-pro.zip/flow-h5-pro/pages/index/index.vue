<template>
  <view>
    <van-pull-refresh v-model="isLoading" @refresh="onRefresh">
      <view class="gray-bj-color-test">
        <!-- 用户信息 -->
        <user-info></user-info>
        <!-- 待我审批 -->
        <wait-examine ref="examine" :isLoading.sync="isLoading"></wait-examine>
        <!-- 待我整改/待我验证 -->
        <patrol-edit ref="patrol" :isLoading.sync="isLoading"></patrol-edit>
        <!-- 快捷入口 -->
        <entrance-view></entrance-view>
        <!-- 我的巡检 -->
        <my-polling></my-polling>
      </view>
    </van-pull-refresh>
  </view>
</template>

<script>
import { mapState } from 'vuex';
import userInfo from '@/index-pkg/components/userInfo.vue';
import waitExamine from '@/index-pkg/components/waitExamine.vue';
import patrolEdit from '@/index-pkg/components/patrolEdit.vue';
import entranceView from '@/index-pkg/components/entranceView.vue';
import myPolling from '@/index-pkg/components/myPolling.vue';
export default {
  components: {
    userInfo,
    waitExamine,
    patrolEdit,
    entranceView,
    myPolling
  },
  data() {
    return {
      isLoading: false
    };
  },
  onLoad() {},
  onShow() {
    // this.$refs.examine.getExamine();
    // this.$refs.patrol.remind();
  },
  methods: {
    // 下拉刷新
    onRefresh() {
      this.$refs.examine.getExamine();
      this.$refs.patrol.remind();
    }
  }
};
</script>

<style scoped lang="scss">
@function rpx2em($rpx) {
  @return ($rpx / 16) * 1em;
}
.gray-bj-color-test {
  width: 100%;
  overflow: auto;
  height: 100%;
  // height: calc(100% - var(--window-top) - var(--window-bottom));
}
</style>

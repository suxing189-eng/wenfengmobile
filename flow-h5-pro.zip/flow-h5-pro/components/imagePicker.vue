<template>
  <view class="">
    <van-field name="uploader" :label="labelName">
      <template #input>
        <uni-file-picker
          limit="9"
          mode="grid"
          file-mediatype="image"
          @select="selectChange"
          @progress="progress"
          v-model="dataList"
          return-type="array"
          @success="success"
          @delete="onDelete"
          :title="title"
          :list-styles="listStyles"
        ></uni-file-picker>
      </template>
    </van-field>
    <!-- 上传图片的加载弹窗 -->
    <van-dialog v-model="imageShow" style="background-color: #f7f8fa;" :showConfirmButton="false" :show-cancel-button="false">
      <view class="image-progress"><van-circle v-model="currentRate" :rate="100" :speed="0" text="上传中" /></view>
    </van-dialog>

    <!-- 弹出对话框 -->
    <van-popup v-model="showList" closeable :close-on-click-overlay="false">
      <view class="popup-table">
        <!-- <uni-table border>
          <uni-tr v-for="item in imageList" :key="item.id">
            <uni-td width="120">{{ item.name }}</uni-td>
            <uni-td width="60" align="center">{{ item.msg }}</uni-td>
          </uni-tr>
        </uni-table> -->
        <van-cell v-for="(item, index) in imageList" :key="item.uuid" title="">
          <template #label>
            <view style="display: flex;justify-content: space-between;">
              <view class="mr-5 cell-name">{{ item.name }}</view>
              <view class="">{{ item.msg }}</view>
            </view>
          </template>
        </van-cell>
      </view>
      <view class="van-contact-list__bottom">
        <van-button v-if="btnShow" color="#e35f24" :disabled="isDisable" class="share" size="normal" @click="handleSubmit">开始上传</van-button>
        <van-button v-else color="#e35f24" class="share" size="normal" @click="reset">关闭</van-button>
      </view>
    </van-popup>
  </view>
</template>

<script>
export default {
  props: {
    fileValue: {},
    labelName: {},
    title: {
      type: String,
      default: '图片数量不能超过9张'
    }
  },
  data() {
    return {
      // 上传的数据
      uploadData: [],
      // 线条样式
      listStyles: {
        // 是否显示边框
        border: true,
        // 是否显示分隔线
        dividline: true,
        // 线条样式
        borderStyle: {
          width: 1,
          color: 'blue',
          radius: 2
        }
      },
      // 图片上传对话框显示
      imageShow: false,
      // 上传进度条
      currentRate: 0,
      dataList: [],
      // 列表数据
      imageList: [],
      showList: false,
      // 上传的文件
      tempFilePaths: [],
      // 显示按钮 关闭还是上传
      btnShow: true,
      // 保存已经上传好的图片
      oldLidt: [],
      // 上传按钮禁用
      isDisable: false,
    };
  },
  onLoad() {
    this.uploadData = this.fileValue;
  },
  methods: {
    success(e) {
      // console.log('上传成功：', e);
    },
    // 获取上传进度
    progress(e) {
      // console.log('上传进度：', e);
    },
    // 移除图片
    onDelete(e) {
      let fileData = [];
      fileData = this.uploadData.filter(item => {
        return item.reqId != e.tempFile.uuid;
      });
      this.uploadData = fileData;
      this.oldLidt = this.oldLidt.filter(item => {
        return item.uuid != e.tempFile.uuid;
      });
      // console.log(this.uploadData, '============>上传内容');
      this.$emit('update:fileValue', fileData);
    },
    selectChange(e) {
      this.dataList = [];
      this.btnShow = true;
      this.isDisable = false;
      this.showList = true;
      // 为什么会多一个oldList 和多这么多逻辑 就是因为还没上传时 组件自己把图片显示了
      this.dataList = JSON.parse(JSON.stringify(this.oldLidt));
      this.tempFilePaths = e.tempFilePaths;
      this.imageList = [];
      // 将图片追加到列表中
      e.tempFiles.forEach(item => {
        item.msg = '待上传';
        this.imageList.push(item);
      });
    },
    // 关闭按钮
    reset() {
      this.showList = false;
    },
    // 开始上传
    handleSubmit() {
      this.isDisable = true;
      // let tempFilePaths = e.tempFilePaths;
      let count = 0;
      this.tempFilePaths.forEach((item, index) => {
        let upUrl;
        upUrl = window.config.apiUrl + '/upload/image/async?reqId=' + this.imageList[count].uuid;
        count++;
        this.imageShow = true;
        let progress = 0;
        let uploadTask = uni.uploadFile({
          url: upUrl,
          fileType: 'image',
          filePath: item,
          name: 'file',
          header: {
            token: sessionStorage.getItem('satoken')
          },
          success: uploadFileRes => {
            let result = JSON.parse(uploadFileRes.data);
            let fileData = [
              ...this.uploadData,
              {
                url: result.data.url,
                name: result.data.originalFilename,
                extname: result.data.fileName.substring(result.data.fileName.lastIndexOf('.') + 1),
                reqId: result.data.reqId
              }
            ];
            this.imageList.forEach(item => {
              if (item.uuid == result.data.reqId) {
                item.msg = '已上传';
                // 通过判断 reqId和uuid一样 就添加到dataList中 因为上传时要把准备上传的图片清掉 不然不知道是否上传成功
                this.dataList.push(item);
                this.oldLidt.push(item);
              }
            });
            this.uploadData = fileData;
            this.$emit('update:fileValue', fileData);
            // console.log(this.dataList, '上传的数据！！！！！');
          },
          fail: err => {
            this.Toast.fail('选择图片失败');
            // iOS权限拒绝特殊处理
            // if (err.errMsg.includes('auth deny') || err.errMsg.includes('permission')) {
            //   this.showiOSPermissionAlert();
            // }
          }
        });
        uploadTask.onProgressUpdate(res => {
          this.currentRate = res.progress;
          if (res.progress === 100) {
            setTimeout(() => {
              this.imageShow = false;
              this.btnShow = false;
            }, 1300);
          }
        });
      });
    }
  }
};
</script>

<style scoped lang="scss">
@function rpx2em($rpx) {
  @return ($rpx / 16) * 1rem;
}
.image-progress {
  width: 200rpx;
  margin: 40rpx auto;
}
::v-deep .van-popup--center {
  width: 90%;
  z-index: 9999 !important;
}
.popup-table {
  width: 100%;
  margin-top: rpx2em(10);
  min-height: rpx2em(300);
  overflow: auto;
  margin-bottom: rpx2em(44);
}
::v-deep .van-popup__close-icon--top-right {
  top: rpx2em(6);
  right: rpx2em(3);
}
::v-deep .van-cell__label {
  font-size: rpx2em(16) !important;
}
::v-deep .van-cell {
  padding: rpx2em(10) rpx2em(8);
}
.cell-name {
  color: #000;
  width: calc(100vw - 195px);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.van-contact-list__bottom {
  padding: rpx2em(0);
  width: 100%;
  .share {
    width: 100%;
  }
}
::v-deep .van-overlay {
  z-index: 9000 !important;
}
</style>

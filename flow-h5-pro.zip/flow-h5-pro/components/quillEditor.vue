<template>
  <view class="container"><view id="editor" @change="change" contenteditable="true"></view></view>
</template>
<script>
// import { Quill } from '@/node_modules/quill/quill.js';
import '@/node_modules/quill/quill.snow.css';
import Quill from '@/node_modules/quill/quill.js';
export default {
  props: {
    value: {},
    height: {
      type: String,
      default: '400px'
    }
  },
  components: {},
  data() {
    return {
      editor: undefined
    };
  },
  created() {
    this.initData();
  },
  watch: {},
  methods: {
    initData() {
      this.$nextTick(() => {
        this.init();
        setTimeout(() => {
          this.editor.innerHTML = this.value;
        }, 10);
      });
    },
    init() {
      // 配置编辑器
      this.editor = new Quill('#editor', {
        theme: 'snow',
        modules: {
          toolbar: [
            // ['bold', 'italic', 'underline', 'strike'], // 基础格式
            // [{ header: [1, 2, 3, false] }], // 标题
            // [{ color: [] }, { background: [] }], // 颜色选择
            // ['blockquote', 'code-block'], // 引用与代码块
            // [{ list: 'ordered' }, { list: 'bullet' }], // 列表
            // ['link', 'image', 'video'], // 媒体插入
            // ['clean'] // 清除格式
          ]
        },
        placeholder: '请输入...'
      });

      let container = document.getElementsByClassName('container');
      let qlContainen = document.getElementsByClassName('ql-container');
      let editor = document.getElementById('editor');
      // container.style.minHeight = '400px';
      // qlContainen.style.minHeight = '370px';
      editor.style.height = this.height;

      // 默认数据
      const delta = this.editor.clipboard.convert(this.value);
      this.editor.setContents(delta);

      // 自动保存功能
      this.editor.on('text-change', () => {
        const content = this.editor.getContents();
        const htmlContent = this.editor.root.innerHTML;
        this.$emit('update:value', htmlContent);
      });

      // 初始化内容
      // this.editor.setContents([{ insert: '欢迎使用 Quill 编辑器\n', attributes: { header: 2 } }]);
    }
  }
};
</script>

<style scoped lang="scss">
body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
  line-height: 1.5;
  color: #333;
  background-color: #f5f5f5;
  padding: 10px;
  -webkit-text-size-adjust: 100%;
}
.container {
  max-width: 100%;
  margin: 0 auto;
  border-radius: 8px;
  // min-height: 300px;
  // box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  overflow: auto;
}

#editor {
  background-color: #fff;
  height: 300px;
  padding: 10px;
  font-size: 16px;
  outline: none;
  border: 1px solid #eee;
  margin: 4px 0;
}

::v-deep .ql-toolbar.ql-snow {
  padding: 0rpx;
  border: none;
}
.ql-container .ql-editor {
  // min-height: 270px;
}
</style>
